# zip_backup_modules

Plugin modules for `zip_backup.py`. Each module runs before the backup
zip is created and can add files to the zip.

---

## Enabling a module

Add its name to the `"modules"` list in `zip_backup.json`:

```json
"modules": ["git_bundle", "your_module"]
```

Modules run in the order listed.

---

## Creating a module

Create a `.py` file in this folder. Files starting with `_` are ignored.

### Required

```python
NAME        = 'your_module'          # must match the name used in config
DESCRIPTION = 'What this module does'

def run(cfg, backup_dir, dry_run):
    """
    cfg        -- the full config dict from zip_backup.json
    backup_dir -- Path to the backup directory (write your output here)
    dry_run    -- bool: if True, log what would happen but don't create files

    Return a list of Path objects to include in the backup zip.
    Return [] if nothing to add or dry_run is True.
    """
    ...
    return [path_to_file1, path_to_file2]
```

### Module-specific config (optional)

If your module needs configuration, read it from `cfg` under your module name:

```python
# In zip_backup.json:
# "your_module": { "some_option": "value" }

def run(cfg, backup_dir, dry_run):
    mod_cfg = cfg.get('your_module', {})
    option  = mod_cfg.get('some_option', 'default')
```

### Logging

Use the standard `logging` module -- output appears in the backup log:

```python
import logging
logging.info(f'    your_module: doing something')
logging.error(f'    your_module: something failed')
```

Prefix log lines with 4 spaces and your module name for consistent formatting.

### Error handling

Wrap your logic in try/except. The main script catches unhandled exceptions
but a module that raises will be logged as an error and skipped -- it won't
abort the backup. Still, handle your own errors where you can and log
something meaningful.

---

## Bundled modules

### git_bundle

Creates a `git bundle` snapshot of each git repository found directly
under `source_dir`. Bundles are written to `backup_dir` and included
in the zip. Restoring:

```
git clone repo.bundle restored_repo
```

Optional config:

```json
"git_bundle": {
    "git_exe": "C:\\Program Files\\Git\\cmd\\git.exe"
}
```

If `git_exe` is omitted, `git` is assumed to be in PATH.
