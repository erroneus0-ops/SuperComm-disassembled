"""
git_bundle.py -- zip_backup module: git bundle snapshot

Creates a portable git bundle of each git repository found directly
under source_dir. The bundle is a self-contained file that can be
used to restore the full git history without GitHub access.

    git clone repo.bundle restored_repo

Bundles are written to backup_dir and included in the zip.
One bundle per repository, named <repo_folder>.bundle.

Enable in zip_backup.json:
    "modules": ["git_bundle"]

Optional config in zip_backup.json:
    "git_bundle": {
        "git_exe": "git"   (full path to git if not in PATH)
    }
"""

import subprocess
import logging
from pathlib import Path

NAME        = 'git_bundle'
DESCRIPTION = 'Creates a git bundle snapshot of each repository under source_dir'


def _find_git(cfg):
    """Return the git executable path from module config or default."""
    mod_cfg = cfg.get('git_bundle', {})
    return mod_cfg.get('git_exe', 'git')


def run(cfg, backup_dir, dry_run):
    """
    Find all git repos under source_dir and bundle each one.
    Returns list of bundle Path objects written to backup_dir.
    """
    source_dir = Path(cfg['source_dir'])
    git_exe    = _find_git(cfg)
    bundles    = []

    # Find top-level directories that contain a .git folder
    repos = [p for p in source_dir.iterdir()
             if p.is_dir() and (p / '.git').exists()]

    if not repos:
        logging.info(f'    git_bundle: no repositories found under {source_dir}')
        return []

    for repo in repos:
        bundle_path = backup_dir / f'{repo.name}.bundle'
        logging.info(f'    git_bundle: {repo.name} -> {bundle_path.name}')

        if dry_run:
            logging.info(f'    git_bundle: dry run -- would create {bundle_path.name}')
            continue

        try:
            result = subprocess.run(
                [git_exe, 'bundle', 'create', str(bundle_path), '--all'],
                cwd=str(repo),
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                size_kb = bundle_path.stat().st_size // 1024
                logging.info(f'    git_bundle: created {bundle_path.name} ({size_kb:,} KB)')
                bundles.append(bundle_path)
            else:
                logging.error(f'    git_bundle: failed for {repo.name}: {result.stderr.strip()}')
        except FileNotFoundError:
            logging.error(f'    git_bundle: git not found at "{git_exe}"')
            logging.error(f'    git_bundle: set git_exe in zip_backup.json under "git_bundle"')
            break
        except Exception as e:
            logging.error(f'    git_bundle: error for {repo.name}: {e}')

    return bundles
