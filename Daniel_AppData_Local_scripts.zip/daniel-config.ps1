# daniel-config.ps1 -- Personal Windows preferences
# Run once after a fresh install or upgrade to restore preferred settings.
# Requires no elevation for most settings (all HKCU).
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File daniel-config.ps1

$ErrorActionPreference = 'SilentlyContinue'

Write-Host "daniel-config: applying preferences..." -ForegroundColor Cyan

# ── Explorer: file visibility ──────────────────────────────────────────────

$adv = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"

# Show hidden files and folders
Set-ItemProperty -Path $adv -Name "Hidden"         -Value 1
# Show file extensions
Set-ItemProperty -Path $adv -Name "HideFileExt"    -Value 0
# Show protected OS files
Set-ItemProperty -Path $adv -Name "ShowSuperHidden" -Value 1

Write-Host "  hidden files: visible"
Write-Host "  file extensions: visible"
Write-Host "  protected OS files: visible"

# ── Explorer: default folder view (Details) ────────────────────────────────
# Clear accumulated per-folder view memory so the Details default takes effect.
# Windows will rebuild these keys using the default view on next Explorer open.

$bags    = "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags"
$bagsMRU = "HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU"

Remove-Item -Path $bags    -Recurse -ErrorAction SilentlyContinue
Remove-Item -Path $bagsMRU -Recurse -ErrorAction SilentlyContinue

Write-Host "  folder view memory: cleared (Details view will apply)"

# ── Date and time format ───────────────────────────────────────────────────

$intl = "HKCU:\Control Panel\International"

Set-ItemProperty -Path $intl -Name "sTimeFormat" -Value "HH:mm:ss"   # full time with seconds
Set-ItemProperty -Path $intl -Name "sShortTime"  -Value "HH:mm"       # short time no seconds
Set-ItemProperty -Path $intl -Name "sShortDate"  -Value "ddMMMyyyy" # 06/Jul/2026
Set-ItemProperty -Path $intl -Name "sLongDate"   -Value "ddMMMyyyy" # same for long date

Write-Host "  time format:  HH:mm:ss"
Write-Host "  short time:   HH:mm"
Write-Host "  date format:  ddMMMyyyy"

# ── Restart Explorer to apply changes ─────────────────────────────────────

Write-Host ""
Write-Host "Restarting Explorer to apply changes..." -ForegroundColor Cyan
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Start-Process explorer

Write-Host "Done." -ForegroundColor Green
