#!/usr/bin/env python3
"""
zip_backup.py -- Smart backup with incremental zip-file filtering.

Rules:
  Non-zip files:   always included.
  .zip files:      only included if newer than the most recent backup,
                   OR if running a full backup (--full flag).
  Excluded folders: never included in incremental backups.
                   Included in full backups for self-contained restoration.

Usage:
    python zip_backup.py              show this help (no accidental runs)
    python zip_backup.py --run        incremental backup
    python zip_backup.py --full       full backup, include all files
    python zip_backup.py --dry-run    show what would be included, no zip created
    python zip_backup.py --config     force reconfiguration, overwrite zip_backup.json
    python zip_backup.py --help       show this help

Configuration:
    zip_backup.json in the same directory as this script.
    If missing and running interactively, user is prompted to create it.
    If missing and running as a scheduled task, script exits with error.

zip_backup.json format:
{
    "source_dir":       "C:\\DATA\\supercomm",
    "backup_dir":       "C:\\DATA\\git_backup",
    "log_file":         "C:\\DATA\\git_backup\\zip_backup_log.txt",
    "max_backups":      20,
    "prefix":           "git_",
    "excluded_folders": ["screenshots"],
    "modules":          ["git_bundle"]
}

Modules:
    Drop .py files into zip_backup_modules/ next to this script.
    Each module must expose: NAME, DESCRIPTION, run(cfg, backup_dir, dry_run)
    run() returns a list of Path objects to include in the backup zip.
    Enable modules by name in the "modules" config key.
    Bundled module: git_bundle -- creates a git bundle snapshot before backup.
"""

import os
import sys
import json
import zipfile
import logging
import importlib.util
from pathlib import Path
from datetime import datetime

# ── Modules ────────────────────────────────────────────────────────────────────

MODULES_DIR = Path(__file__).parent / 'zip_backup_modules'

def load_modules():
    """Discover and load all modules from zip_backup_modules/ folder."""
    modules = {}
    if not MODULES_DIR.exists():
        return modules
    for f in sorted(MODULES_DIR.glob('*.py')):
        if f.name.startswith('_'):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f.stem, f)
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            name = getattr(mod, 'NAME', f.stem)
            modules[name] = mod
        except Exception as e:
            logging.warning(f'  module load failed: {f.name}: {e}')
    return modules

def run_modules(modules, enabled, cfg, backup_dir, dry_run):
    """Run each enabled module. Returns list of extra files to include in zip."""
    extra_files = []
    for name in enabled:
        mod = modules.get(name)
        if not mod:
            logging.warning(f'  module not found: {name} (skipping)')
            continue
        try:
            logging.info(f'  module: {name}')
            result = mod.run(cfg, Path(backup_dir), dry_run)
            if result:
                extra_files.extend(result)
        except Exception as e:
            logging.error(f'  module failed: {name}: {e}')
    return extra_files

# ── Config ─────────────────────────────────────────────────────────────────────

CONFIG_FILE = Path(__file__).parent / 'zip_backup.json'

# Code-level defaults -- only used if not in JSON
# excluded_folders always includes .git regardless of JSON
DEFAULTS = {
    'source_dir':         '',
    'backup_dir':         '',
    'log_file':           None,
    'max_backups':        20,
    'prefix':             'git_',
    'excluded_folders':   [],
    'suffix_incremental': '_daily',
    'suffix_full':        '_full',
}

def _path_hint(label):
    """Return a platform-appropriate path example for the given label."""
    if sys.platform == 'win32':
        examples = {
            'source': r'C:\DATA\myproject',
            'backup': r'C:\DATA\backups',
            'log':    r'C:\DATA\backups\zip_backup_log.txt',
        }
    else:
        examples = {
            'source': '/home/user/myproject',
            'backup': '/home/user/backups',
            'log':    '/home/user/backups/zip_backup_log.txt',
        }
    return examples.get(label, '')

def load_config():
    force_reconfig = '--config' in sys.argv

    if CONFIG_FILE.exists() and not force_reconfig:
        with open(CONFIG_FILE, encoding='utf-8') as f:
            data = json.load(f)
        cfg = {**DEFAULTS, **data}
        # Always exclude dot-folders (.git, .svn, etc.) regardless of JSON
        cfg['_exclude_dot_folders'] = True
        return cfg

    # Need to configure -- require interactive terminal
    if not sys.stdin.isatty():
        if force_reconfig:
            print('ERROR: --config requires an interactive terminal.', file=sys.stderr)
        else:
            print(f'ERROR: Config file not found: {CONFIG_FILE}', file=sys.stderr)
            print('Run interactively with --config to create it.', file=sys.stderr)
        sys.exit(2)

    # Load existing config as starting point if reconfiguring
    if force_reconfig and CONFIG_FILE.exists():
        print(f'Editing config: {CONFIG_FILE}\n')
        with open(CONFIG_FILE, encoding='utf-8') as f:
            existing = json.load(f)
        cfg = {**DEFAULTS, **existing}
        print('Press Enter to keep the current value shown in [brackets].\n')
    else:
        print(f'Creating config: {CONFIG_FILE}\n')
        cfg = dict(DEFAULTS)
        print('Press Enter to accept the default shown in [brackets].\n')

    def prompt(label, current, hint=''):
        if current:
            display = current
            suffix = ''
        else:
            display = hint
            suffix = ''
        val = input(f'  {label} [{display}]: ').strip()
        return val if val else (current or '')

    # Required fields
    src_label = 'Source folder' if cfg['source_dir'] else 'Source folder  (directory to back up)'
    source = prompt(src_label, cfg['source_dir'], _path_hint('source'))
    if not source:
        print('  Source folder is required. Exiting.')
        sys.exit(1)
    cfg['source_dir'] = source

    bak_label = 'Backup folder' if cfg['backup_dir'] else 'Backup folder  (where to save zip files)'
    backup = prompt(bak_label, cfg['backup_dir'], _path_hint('backup'))
    if not backup:
        print('  Backup folder is required. Exiting.')
        sys.exit(1)
    cfg['backup_dir'] = backup

    # Optional fields
    log_current = cfg.get('log_file') or ''
    log_label = 'Log file' if log_current else 'Log file  (full path, blank=console only)'
    log = prompt(log_label, log_current, _path_hint('log'))
    cfg['log_file'] = log if log else None

    max_b = prompt('Keep           (how many backups to keep)',
                   str(cfg['max_backups']))
    cfg['max_backups'] = int(max_b) if str(max_b).isdigit() else cfg['max_backups']

    cfg['prefix'] = prompt('Filename prefix',
                           cfg['prefix'])

    excl_current = ','.join(e for e in cfg['excluded_folders'] if not e.startswith('.'))
    hint = 'logs,temp,cache'
    raw = input(f'  Folder exclusions (.files and .folders always excluded) [{excl_current or hint}] X to clear: ').strip()
    if raw.lower() == 'x':
        cfg['excluded_folders'] = []
    elif raw:
        cfg['excluded_folders'] = [e.strip() for e in raw.split(',') if e.strip() and not e.strip().startswith('.')]
    else:
        cfg['excluded_folders'] = [e for e in cfg['excluded_folders'] if not e.startswith('.')]
    # Save only user-meaningful keys -- omit suffix unless changed from default
    save_cfg = {
        'source_dir':       cfg['source_dir'],
        'backup_dir':       cfg['backup_dir'],
        'log_file':         cfg['log_file'],
        'max_backups':      cfg['max_backups'],
        'prefix':           cfg['prefix'],
        'excluded_folders': cfg['excluded_folders'],
    }
    # Only save suffix keys if non-default
    if cfg.get('suffix_incremental', '_daily') != '_daily':
        save_cfg['suffix_incremental'] = cfg['suffix_incremental']
    if cfg.get('suffix_full', '_full') != '_full':
        save_cfg['suffix_full'] = cfg['suffix_full']

    print()
    save = input(f'Save to {CONFIG_FILE}? [Y/n]: ').strip().lower()
    if save != 'n':
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(save_cfg, f, indent=4)
        print(f'  saved to {CONFIG_FILE}')

    # Add .git back for runtime use -- no longer needed, dot-folders excluded by loop
    cfg['excluded_folders'] = cfg['excluded_folders']
    return cfg

# ── Setup ──────────────────────────────────────────────────────────────────────

def setup_logging(log_file):
    handlers = [logging.StreamHandler()]
    if log_file:
        from logging.handlers import TimedRotatingFileHandler
        p = Path(log_file)
        p.parent.mkdir(parents=True, exist_ok=True)
        # Rotate weekly, keep 4 weeks of history
        fh = TimedRotatingFileHandler(
            p, when='W0', interval=1, backupCount=4, encoding='utf-8'
        )
        handlers.append(fh)
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s  %(message)s',
        datefmt='%d%b%Y %H:%M:%S',
        handlers=handlers
    )

# ── Helpers ────────────────────────────────────────────────────────────────────

def last_backup_time(backup_dir, prefix):
    zips = sorted(
        Path(backup_dir).glob(f'{prefix}*.zip'),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    return zips[0].stat().st_mtime if zips else None

def should_include(path, last_backup_mtime, full):
    if path.suffix.lower() != '.zip':
        return True, 'included'
    if full:
        return True, 'included (full)'
    if last_backup_mtime is None:
        return True, 'included (first backup)'
    if path.stat().st_mtime > last_backup_mtime:
        return True, 'included (new zip)'
    return False, 'skipped (zip, unchanged)'

def rotate_backups(backup_dir, prefix, max_backups):
    bd = Path(backup_dir)
    zips = sorted(
        list(bd.glob(f'{prefix}*_daily.zip')) +
        list(bd.glob(f'{prefix}*_full.zip')),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    to_delete = zips[max_backups:]
    for z in to_delete:
        logging.info(f'  removing old backup: {z.name}')
        z.unlink()
    return len(to_delete)

# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    # Show help and exit cleanly with no flags or explicit --help
    action_flags = {'--run', '--full', '--dry-run'}
    if '--help' in sys.argv or '-h' in sys.argv or \
       not any(f in sys.argv for f in action_flags | {'--config'}):
        print(__doc__)
        sys.exit(0)

    # --config: configure and exit, no backup
    if '--config' in sys.argv and not any(f in sys.argv for f in action_flags):
        load_config()
        print('Configuration complete. Run with --run, --full, or --dry-run to back up.')
        sys.exit(0)

    cfg = load_config()

    source_dir  = Path(cfg['source_dir'])
    backup_dir  = Path(cfg['backup_dir'])
    log_file    = cfg.get('log_file')
    max_backups = int(cfg.get('max_backups', 20))
    prefix      = cfg.get('prefix', 'git_')
    excluded    = set(cfg.get('excluded_folders', []))
    sfx_incr    = cfg.get('suffix_incremental', '_daily')
    sfx_full    = cfg.get('suffix_full', '_full')
    enabled_mods = cfg.get('modules', [])

    setup_logging(log_file)

    # Load available modules
    modules = load_modules()
    if modules:
        logging.info(f'  modules available: {", ".join(modules.keys())}')
    if enabled_mods:
        logging.info(f'  modules enabled:   {", ".join(enabled_mods)}')

    full    = '--full'    in sys.argv
    dry_run = '--dry-run' in sys.argv

    mode = 'FULL' if full else 'INCREMENTAL'
    logging.info(f'--- zip_backup starting ({mode}{", DRY RUN" if dry_run else ""}) ---')
    logging.info(f'  source:   {source_dir}')
    logging.info(f'  backup:   {backup_dir}')
    logging.info(f'  excluded: {", ".join(sorted(excluded))}')

    backup_dir.mkdir(parents=True, exist_ok=True)

    last_mtime = last_backup_time(backup_dir, prefix)
    if last_mtime:
        last_dt = datetime.fromtimestamp(last_mtime).strftime('%Y-%m-%d %H:%M:%S')
        logging.info(f'  last backup: {last_dt}')
    else:
        logging.info(f'  last backup: none (first run)')

    included = []
    skipped  = []

    top_folders = [p for p in source_dir.iterdir() if p.is_dir()]
    top_files   = [p for p in source_dir.iterdir() if p.is_file()]

    for file in top_files:
        inc, reason = should_include(file, last_mtime, full)
        if inc:
            included.append(file)
        else:
            skipped.append(file)

    for folder in top_folders:
        # Always skip dot-folders (.git, .svn, .idea, etc.) in incremental
        if folder.name.startswith('.') and not full:
            logging.info(f'  folder skipped:  {folder.name} (dot-folder)')
            continue
        # Check user-configured exclusions
        if folder.name in excluded and not full:
            logging.info(f'  folder skipped:  {folder.name} (excluded)')
            continue

        if full:
            for file in folder.rglob('*'):
                if file.is_file():
                    included.append(file)
        else:
            folder_files = [f for f in folder.rglob('*') if f.is_file()]
            if not folder_files:
                continue
            newest_mtime = max(f.stat().st_mtime for f in folder_files)
            if last_mtime is None or newest_mtime > last_mtime:
                for file in folder_files:
                    included.append(file)
                logging.info(f'  folder included: {folder.name}')
            else:
                skipped.extend(folder_files)
                logging.info(f'  folder skipped:  {folder.name} (no changes)')

    logging.info(f'  files to include: {len(included)}  skipped: {len(skipped)}')

    if dry_run:
        logging.info('  dry run -- files that would be included:')
        for f in included:
            logging.info(f'    {f.relative_to(source_dir.parent)}')
        logging.info('--- dry run complete ---')
        return

    if not included:
        logging.info('  nothing to back up.')
        logging.info('--- zip_backup done ---')
        return

    # Run pre-backup modules
    extra_files = run_modules(modules, enabled_mods, cfg, backup_dir, dry_run)
    if extra_files:
        logging.info(f'  module files: {len(extra_files)}')
        included.extend(extra_files)

    now      = datetime.now()
    stamp    = f"{now.year:04d}{now.month:02d}{now.day:02d}_{now.hour:02d}{now.minute:02d}"
    suffix   = sfx_full if full else sfx_incr
    zip_path = backup_dir / f'{prefix}{stamp}{suffix}.zip'

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for file in included:
            arcname = file.relative_to(source_dir.parent)
            zf.write(file, arcname)

    size_kb = zip_path.stat().st_size // 1024
    logging.info(f'  created: {zip_path.name}  ({size_kb:,} KB,  {len(included)} files)')

    deleted = rotate_backups(backup_dir, prefix, max_backups)
    if deleted:
        logging.info(f'  rotated: removed {deleted} old backup(s), kept {max_backups}')

    logging.info('--- zip_backup done ---')


if __name__ == '__main__':
    main()
