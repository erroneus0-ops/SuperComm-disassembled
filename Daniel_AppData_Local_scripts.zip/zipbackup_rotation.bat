@echo off
cd /d D:\git

:: Create archive name with date/time stamp
set STAMP=%DATE:~10,4%%DATE:~4,2%%DATE:~7,2%_%TIME:~0,2%%TIME:~3,2%
set STAMP=%STAMP: =0%
set ZIPFILE=D:\git_backups\git_%STAMP%.zip

:: Create backup directory if it doesn't exist
if not exist D:\git_backups mkdir D:\git_backups

:: Create the zip archive
powershell -Command "Compress-Archive -Path 'D:\git' -DestinationPath '%ZIPFILE%' -Force"

:: Keep only the 20 newest -- delete the rest
powershell -Command "Get-ChildItem 'D:\git_backups\git_*.zip' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 20 | Remove-Item -Force"

echo Backup complete: %ZIPFILE%