@echo off
cd /d D:\git\supercomm
"D:\PortableGit\bin\git.exe" pull --no-rebase >> D:\git\git_pull_log.txt 2>&1
