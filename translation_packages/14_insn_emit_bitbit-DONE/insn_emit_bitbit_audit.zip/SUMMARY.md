# Audit Summary: `insn_emit_bitbit` (translation_packages/14)

## What I read, in order

1. `translation_packages/14_insn_emit_bitbit/brief.md`
2. `translation_packages/14_insn_emit_bitbit/source.c` — diffed against the
   live tarball at `lwtools-4.24/lwasm/insn_bitbit.c` lines 101-147 to
   confirm the package's copy is byte-identical to the real source (it is).
3. `translation_packages/14_insn_emit_bitbit/checklist.md` (pre-filled, then
   completed as part of this session)
4. `cocotools/TRANSLATION_GUIDE.md`
5. `cocotools/DATA_STRUCTURE_AUDIT.md`
6. `cocotools/c_compat.py`
7. `translation_packages/14_insn_emit_bitbit/existing.py`
8. `cocotools/insn_funcs.py` (full file, focused on the `insn_*_bitbit`
   family at the end and the sibling `insn_emit_tfm`/`insn_emit_tfmrtor`
   for emit-function style precedent)
9. `lwtools-4.24/lwlib/lw_expr.c` — to check the exact null-safety semantics
   of `lw_expr_istype`, which turned out to be the one subtlety in this
   function (see below).
10. `lwtools-4.24/lwasm/lwasm.c` — to confirm `lwasm_fetch_expr` really can
    return `NULL` (it does, when no expr was ever saved for that id).

## Pre-translation checklist (all 9 categories)

See the completed `checklist.md` in this directory for the full writeup.
Short version: of the 9 checklist categories, only #1 (integer width) and
#7 (integer promotion) apply at all, and both are the "known safe pattern"
case — no compat-primitive masking needed. The one genuine interaction
risk is a Python-vs-C null-safety gap on `fetch_expr`'s return value
(detailed below), which is not one of the 9 checklist categories itself
but falls under the "interaction risks" section the guide asks for.

## Independent translation vs. `existing.py`

I translated `source.c` independently before opening `existing.py`, per
the brief's ordering. My draft and `existing.py` matched line-for-line
with one difference worth calling out explicitly:

**Difference found:** my first draft wrote `if not e.istype(TYPE_INT):`
at all three `fetch_expr` call sites, mirroring the C's
`if (!lw_expr_istype(e, lw_expr_type_int))` literally. `existing.py`
instead writes `if not (e and e.istype(TYPE_INT)):`.

**Verdict: existing.py is correct; my literal draft was the bug.**

Why: `lw_expr_istype` in `lw_expr.c` (lines 63-71) is explicitly
null-safe —

```c
int lw_expr_istype(lw_expr_t e, int t)
{
    /* NULL expression is never of any type */
    if (!e)
        return 0;
    ...
}
```

`lwasm_fetch_expr` (`lwasm.c`) returns `NULL` whenever the requested expr
id was never saved via `lwasm_save_expr`. C's call site is therefore safe
even if `e` comes back NULL. Python's `Expr.istype` (`lw_expr.py`) is an
ordinary instance method with no such guard — calling `e.istype(...)` on
`None` raises `AttributeError`, a crash C never has here. `existing.py`'s
`e and e.istype(...)` guard reproduces C's null-safety using Python's
short-circuit `and`, and is required for faithful behavior, not just
defensive style. This is exactly the kind of divergence the brief warns
about: it wouldn't show up on any test where all three expr ids happen to
already be populated (which is the normal case for a successfully parsed
bitbit line), but it's a real correctness gap in a literal transliteration.

No other divergences were found. Every other line of `existing.py` —
the bit-number range checks, the postbyte formula, the byte-overflow
check against `dpval`, and the final `emitop`/`emit`/`emitexpr` sequence —
matches the C exactly, including the harmless renaming of the reused C
locals `v1`/`v2` (in the third block) to `vv`/`diff` in Python, which
changes nothing observable.

## Bugs fixed

None needed fixing — `existing.py` was already correct on the one point
of genuine risk (the null-safety guard), and matched the C everywhere
else. No code changes were made to the *logic* of `insn_emit_bitbit`.
The only change to `cocotools/insn_funcs.py` was adding the standard
`FUNCTION:` documentation header (matching the format used by the other
completed packages, e.g. `insn_parse_bitbit`, `insn_emit_tfm`) recording
the checklist results and the interaction risk directly above the
function, for future maintainers.

## Verification method

Built `lwasm` fresh from the project's own published source tarball
(`lwtools-4.24.tar.gz`, `make -j$(nproc)`) rather than relying on the
repository's precompiled binary, and used that from-source build as the
reference implementation for the fidelity harness (`cocotools/test_fidelity.py`,
which shells out to `lwasm --decb` and compares raw bytes).

Manually hand-derived expected output for three valid encodings and
confirmed byte-for-byte against the freshly built `lwasm`:

| Source | Expected | lwasm 4.24 (from-source build) |
|---|---|---|
| `BAND CC,3,5,$10` | `11 30 1D 10` | `11 30 1D 10` ✓ |
| `STBT B,2,6,$20` | `11 37 96 20` | `11 37 96 20` ✓ |
| `BEOR A,0,7,$00` | `11 34 47 00` | `11 34 47 00` ✓ |

Also confirmed the three error paths against the real assembler:
invalid bit number (8), byte overflow (address outside the direct page),
and an unresolved bit-number expression (undefined symbol) all cause
`lwasm` to exit non-zero with no output file — matching cocotools'
`register_error` + early-return behavior in all three cases.

## New tests added (6, in `BEHAVIOR_TESTS_6309`)

1. `bitbit-band-cc-direct-page-6309` — CC register (lint=0), valid bytes.
2. `bitbit-stbt-b-register-6309` — B register (lint=2), valid bytes.
3. `bitbit-beor-a-register-bit-extremes-6309` — A register (lint=1), bit
   numbers 0 and 7 (the valid range's extremes).
4. `bitbit-invalid-bitnumber-6309` — bit number 8 (out of 0-7 range) →
   expected error in both cocotools and lwasm.
5. `bitbit-byte-overflow-6309` — address outside the current direct page
   → expected error, and confirms no partial bytes are emitted.
6. `bitbit-bitnumber-unresolved-6309` — undefined symbol as the bit-number
   operand → expected error, exercising the null-safety-guarded branch.

Together these cover: all three valid registers (CC/A/B, i.e. all values
of `lint`: 0/1/2), both extremes of the valid bit-number range, and all
three error branches in the function (invalid bit number, byte overflow,
unresolved expression).

## Final test counts

```
Fidelity (6809 mode):              170 passed, 0 failed
Behavioral:                         53 passed, 0 failed
Behavioral (6309-only):             16 passed, 0 failed   (was 10; +6 new)
Structural:                         30 passed, 0 failed
Expression-simplify:                 8 passed, 0 failed
Unit:                                4 passed, 0 failed
lw_expr_parse_term unit:            10 passed, 0 failed
-----------------------------------------------------------
Total:                              291 passed, 0 failed
```

All pre-existing tests still pass; no test was modified to make it pass.
