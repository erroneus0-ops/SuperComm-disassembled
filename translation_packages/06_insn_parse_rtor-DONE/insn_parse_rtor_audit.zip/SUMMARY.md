# Translation Audit Summary: `insn_parse_rtor`

Date: 2026-07-17
Package: `translation_packages/06_insn_parse_rtor`
C source: `lwtools-4.24/lwasm/insn_rtor.c` lines 25-56
Python target: `cocotools/insn_funcs.py`

## Reading order

1. `translation_packages/06_insn_parse_rtor/brief.md` (task brief)
2. `translation_packages/06_insn_parse_rtor/source.c` (the C spec)
3. `translation_packages/06_insn_parse_rtor/checklist.md` (pre-filled, mostly empty)
4. `cocotools/TRANSLATION_GUIDE.md` (full checklist + risk catalog)
5. `cocotools/DATA_STRUCTURE_AUDIT.md` (shared struct reference — `line_t`, `asmstate_t`)
6. `cocotools/c_compat.py` (compat primitives — `Ptr`, `c_uint8`, etc.)
7. `translation_packages/06_insn_parse_rtor/existing.py` (prior translation, marked SUSPECT)
8. `cocotools/insn_funcs.py` (full file; located the target function, plus its
   sibling `insn_parse_tfmrtor` and the shared `_skip_to_next_token` helper
   and `lookupreg2`/`lookupreg3` implementations in `cocotools/lwasm_core.py`,
   for cross-reference)
9. `lwtools-4.24/lwasm/lwasm.c` (`lwasm_skip_to_next_token` C implementation,
   to confirm its `PRAGMA_NEWSOURCE` gating)
10. `lwtools-4.24/lwasm/pass1.c` (the caller — to understand what happens to
    the parse function's returned cursor, and to find the `!(cl->err)` guard
    that turned out to matter for this audit)
11. `cocotools/pass1.py` (the caller's Python translation, for the same reason)

## Pre-translation checklist (all 9 categories)

See the fully filled-in `checklist.md` included in this package for the
complete writeup. Summary:

| # | Category | Finding |
|---|----------|---------|
| 1 | Integer width | None needed — postbyte is nibble-range by construction |
| 2 | Division/modulo | None found |
| 3 | `char **p` | Yes — single shared `Ptr`, no aliasing |
| 4 | `goto` | None |
| 5 | char signedness | Low risk — ASCII only |
| 6 | Argument/evaluation order | **Bug found** — see below |
| 7 | Integer promotion | Safe, no masking needed |
| 8 | Bitwise complement | None |
| 9 | Register lookup advancement | Verified: `lookupreg2` doesn't advance `p` on failure |

## Divergence found between `existing.py` and the C source

**One divergence, in the comma check.**

C:
```c
r0 = lwasm_lookupreg2(!CURPRAGMA(l, PRAGMA_6809) ? regs : regs9, p);
lwasm_skip_to_next_token(l, p);
if (r0 < 0 || *(*p)++ != ',')
{
    lwasm_register_error(as, l, E_OPERAND_BAD);
    r0 = r1 = 0;
}
```

`existing.py` (and the identical code already present in
`cocotools/insn_funcs.py` before this audit):
```python
r0 = AsmState.lookupreg2(regs, p)
if curpragma(cl, PRAGMA_NEWSOURCE):
    while p.peek() and p.peek().isspace(): p.advance()
if r0 < 0 or p.peek() != ',':
    as_.register_error(cl, E_OPERAND_BAD); r0 = r1 = 0
else:
    p.advance()
    ...
```

**Verdict: bug in `existing.py`.**

C's `*(*p)++ != ','` is a post-increment dereference embedded directly in
the condition. Because `||` short-circuits:

- If `r0 < 0`, the right-hand operand is never evaluated — `p` is left
  wherever `lookupreg2` + `skip_to_next_token` put it. (`existing.py` gets
  this part right, since it never touches `p` in that branch either.)
- If `r0 >= 0`, the current character is read **and `p` is advanced by
  one, unconditionally** — before the comparison against `','` happens.
  This means C consumes one character even on the "it wasn't a comma"
  error path.

`existing.py` only ever calls `p.advance()` in the success (comma-found)
branch. It never advances `p` when `r0 >= 0` but the next character isn't
a comma. That's a real, verifiable divergence from the C source's pointer
arithmetic.

### Why this divergence doesn't show up in the top-level test harness

I checked whether this actually produces different assembler output or
error counts against real lwasm 4.24, and it does not, for a specific
reason: `pass1.c` (and its Python translation, `pass1.py`) both gate their
post-parse "did you leave unconsumed garbage on the line?" check behind
`!(cl->err)` / `not cl.err`. Every error path inside `insn_parse_rtor`
already calls `register_error()` before returning, so `cl.err` is always
already set by the time that outer check would run — the wrong cursor
position never gets a chance to matter, for this particular call site.

I confirmed this empirically: assembling `TFR A B` (missing comma) with
both the buggy and the fixed translation, against real lwasm, produces an
identical single "Bad operand" error in all three cases. Calling
`insn_parse_rtor` directly (bypassing the full pipeline) shows the actual
difference: the buggy version returns `p.remaining() == " B"` where the
correct (fixed) version returns `"B"`.

Per `TRANSLATION_GUIDE.md`'s own stated purpose — catching divergences
that "look correct... and fail silently on the inputs that matter" — an
divergence being currently unobservable through one call site doesn't
make it acceptable to leave in. It's fixed regardless, and a new
unit-level test category was added specifically because this class of
bug can't be caught by the existing byte/error-count comparison harness.

## Bug fixed

**C:**
```c
if (r0 < 0 || *(*p)++ != ',')
{
	lwasm_register_error(as, l, E_OPERAND_BAD);
	r0 = r1 = 0;
}
else
{
	lwasm_skip_to_next_token(l, p);
	r1 = lwasm_lookupreg2(!CURPRAGMA(l, PRAGMA_6809) ? regs : regs9, p);
	if (r1 < 0)
	{
		lwasm_register_error(as, l, E_OPERAND_BAD);
		r0 = r1 = 0;
	}
}
```

**Old Python (buggy):**
```python
if r0 < 0 or p.peek() != ',':
    as_.register_error(cl, E_OPERAND_BAD); r0 = r1 = 0
else:
    p.advance()
    if curpragma(cl, PRAGMA_NEWSOURCE):
        while p.peek() and p.peek().isspace(): p.advance()
    r1 = AsmState.lookupreg2(regs, p)
    if r1 < 0:
        as_.register_error(cl, E_OPERAND_BAD); r0 = r1 = 0
```

**New Python (fixed):**
```python
if r0 < 0:
    as_.register_error(cl, E_OPERAND_BAD); r0 = r1 = 0
else:
    c = p.peek()
    p.advance()
    if c != ',':
        as_.register_error(cl, E_OPERAND_BAD); r0 = r1 = 0
    else:
        _skip_to_next_token(cl, p)
        r1 = AsmState.lookupreg2(regs, p)
        if r1 < 0:
            as_.register_error(cl, E_OPERAND_BAD); r0 = r1 = 0
```

**Verification method:**
1. Direct unit-level call to `insn_parse_rtor(as_, cl, "A B")` — confirmed
   old code returns `p.remaining() == " B"`, new code returns `"B"`
   (matching a hand-traced execution of the C source).
2. Full fidelity harness (`test_fidelity.py`) re-run after the fix — all
   251 pre-existing tests still pass (no regression).
3. New tests added (below) specifically target this branch and the
   related `r0 < 0` / `r1 < 0` branches.

A secondary, purely cosmetic change was also made: the inlined
`PRAGMA_NEWSOURCE` whitespace-skip loops were replaced with calls to the
shared `_skip_to_next_token(cl, p)` helper already used by
`insn_parse_indexed_aux` elsewhere in the same file. Behavior is
identical (verified by the unchanged test results); this is a
consistency/maintainability cleanup, not a bug fix.

## New tests added

**Behavioral (via the full fidelity harness, compared against real lwasm 4.24):**
- `rtor-exg-cc-dp` — `EXG CC,DP`, a register pair not covered by any
  prior TFR/EXG test in the suite.
- `rtor-bad-first-register` — `TFR Q,X`, exercises the `r0 < 0` branch
  (bogus first register name).
- `rtor-bad-second-register` — `TFR X,Q`, exercises the `r1 < 0` branch
  (valid first register + comma, bogus second register name).
- `rtor-missing-comma` — `TFR A B`, exercises the exact branch containing
  the fixed bug (still just confirms "both single-error identically" at
  this level, per the observability discussion above).

**Unit-level (new test category, direct function calls, bypassing full assembly):**
- `rtor-unit-missing-comma-consumes-char` — operand `"A B"`; asserts
  `insn_parse_rtor` returns `"B"` (not `" B"`) and `errorcount == 1`. This
  is the actual regression test for the fixed bug.
- `rtor-unit-missing-comma-consumes-exactly-one-char` — operand `"A  X"`
  (two spaces); asserts exactly one character is consumed (`" X"`
  remains), not zero and not both.
- `rtor-unit-bad-r0-no-advance` — operand `"Q,X"`; asserts the cursor does
  NOT advance at all when `r0 < 0` (confirms the `||` short-circuit is
  correctly preserved).
- `rtor-unit-success-exact-cursor` — operand `"A,B"`; asserts the cursor
  lands exactly at the end (`""` remaining) on the success path, with
  `errorcount == 0`.

A new `run_unit_tests()` function and `UNIT_TESTS_RTOR` list were added to
`cocotools/test_fidelity.py`, wired into `main()` as a fifth test category
alongside fidelity/behavioral/structural/expression-simplify.

## Final test counts

```
Results: 170 passed, 0 failed out of 170 tests            (fidelity, vs real lwasm 4.24)
Behavioral results: 45 passed, 0 failed out of 45 tests    (was 41; +4 new)
Behavioral (6309-only) results: 4 passed, 0 failed out of 4 tests
Structural results: 28 passed, 0 failed out of 28 tests
Expression-simplify results: 8 passed, 0 failed out of 8 tests
Unit results: 4 passed, 0 failed out of 4 tests            (new category; +4 new)

TOTAL: 259 passed, 0 failed out of 259 tests
```

Exit code: 0. All pre-existing 251 tests continue to pass (no
regressions); 8 new tests added and passing (4 behavioral + 4 unit).

## Files changed

- `cocotools/insn_funcs.py` — `insn_parse_rtor` rewritten to fix the
  comma-check cursor-advancement bug; full checklist docstring added
  above the function per `TRANSLATION_GUIDE.md`'s template.
- `cocotools/test_fidelity.py` — 4 new `BEHAVIOR_TESTS` entries; new
  `UNIT_TESTS_RTOR` list and `run_unit_tests()` function; wired into
  `main()`.
- `translation_packages/06_insn_parse_rtor/checklist.md` — fully filled
  in (was mostly template placeholders).
- `translation_packages/06_insn_parse_rtor/existing.py` — updated to
  reflect the current, corrected state of the translation.
