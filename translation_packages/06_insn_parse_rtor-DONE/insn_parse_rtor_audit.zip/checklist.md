# Pre-Translation Checklist: `insn_parse_rtor`

Metrics: 32 lines, 2 branches, 0 gotos

STATUS: COMPLETE (2026-07-17 audit). All fidelity harness tests pass
(259/259: 170 fidelity + 45 behavioral + 4 behavioral-6309 + 28
structural + 8 expression-simplify + 4 unit).

## 1. Integer width at assignment sites
Check every assignment destination type.
Bit mask operations found (may need `c_uint8` etc.):
  None. `l->pb = (r0 << 4) | r1` is `int` in C; both r0 and r1 are
  nibble-range register table indices (0-15), so the OR result is
  always in 0x00-0xFF -- safe by construction per TRANSLATION_GUIDE's
  "Known Safe Patterns" table, no masking needed.

## 2. Division / modulo
Not found.

## 3. char ** pointer parameters
Found: `char **p`. Mapped to a `Ptr` instance shared for the whole
function body (both `lookupreg2` calls and the manual advance operate
on the same `Ptr`). No aliasing risk -- only one cursor is in play.

## 4. goto statements
  None.

## 5. char signedness
Low risk -- ASCII assembly source only, confirmed no >127 comparisons
in this function.

## 6. Argument evaluation order / mutating-dereference-in-condition
FOUND AND WAS MISTRANSLATED. `if (r0 < 0 || *(*p)++ != ',')` embeds a
post-increment dereference directly in a boolean condition (not
strictly "argument position" as the checklist item's literal wording
suggests, but the same underlying hazard: a side-effecting expression
whose execution is conditional on short-circuit evaluation).
  - `||` short-circuits: if `r0 < 0`, the right operand is **never**
    evaluated, so `p` is untouched.
  - If `r0 >= 0`, `*(*p)++` reads the current character AND advances
    `p` by one, UNCONDITIONALLY -- regardless of whether that character
    turns out to be a comma or not -- and only afterward is the read
    character compared against ','.
  The previous translation (existing.py, and the code already resident
  in cocotools/insn_funcs.py before this audit) wrote the equivalent of
  `if r0 < 0 or p.peek() != ',': error else: p.advance()`, which only
  advances `p` on the comma-found (success) branch. This diverges from
  C whenever `r0 >= 0` but the next character is not a comma: C still
  consumes that character; the old Python translation left `p` sitting
  in front of it.
  FIXED -- see "Mitigations applied" below.

## 7. Integer promotion
Compound expression `(r0 << 4) | r1` -- both operands are small ints
promoted to `int` in C; Python has no promotion/truncation step needed
here since the result never exceeds 0xFF (see item 1).

## 8. Bitwise complement
Not found.

## 9. Register lookup advancement
`lwasm_lookupreg2(regs, p)` advances `p` past the matched register
name on success, and does **not** advance `p` at all on failure (the
scanning loop only calls the advance step inside its match branches).
Verified against the Python `AsmState.lookupreg2` implementation in
`cocotools/lwasm_core.py`, which mirrors this exactly. Confirmed via
the new unit test `rtor-unit-bad-r0-no-advance` (operand `"Q,X"`,
unmatched register, cursor must remain at position 0 afterward).

## Character classification
`lwasm_skip_to_next_token` is gated on `PRAGMA_NEWSOURCE` (only skips
whitespace when that pragma is set); this function calls it verbatim,
matching C, via the shared `_skip_to_next_token(cl, p)` helper already
present in `cocotools/insn_funcs.py` (used by `insn_parse_indexed_aux`
and others) -- the previous translation had inlined an equivalent
pragma check rather than reusing the shared helper; behavior was
already correct, but has now been consolidated onto the shared helper
for consistency with the rest of the module.

## Interaction risks identified
  - The `*(*p)++ != ','` post-increment-in-condition hazard (item 6
    above) -- the real bug found in this audit.
  - This bug is UNOBSERVABLE through the top-level fidelity harness
    (byte-for-byte / error-count comparison against real lwasm 4.24):
    `pass1.py`'s post-parse "unconsumed operand" check
    (`if first and not first.isspace() and not cl.err: ...`) mirrors
    C's `if (*p1 && !isspace(*p1) && !(cl->err))`, and every error path
    inside `insn_parse_rtor` already calls `as_.register_error()` before
    returning -- so `cl.err` is always already set by the time that
    outer check would run, and it never gets a chance to notice the
    wrong cursor position. Verified directly: both the buggy and fixed
    versions produce an identical single "Bad operand" error against
    real lwasm for `TFR A B` (missing comma). The divergence is real
    (different `p.remaining()` return value: `" B"` vs. the correct
    `"B"`) but currently has zero blast radius through the one call
    site pass1.py exposes to it.
  - Despite being currently unobservable, TRANSLATION_GUIDE's own stated
    purpose is to catch exactly this category of "correct for easy
    inputs, silently wrong on inputs that matter" bug -- an unobservable
    divergence today is still a fidelity violation, and remains a risk
    if pass1.py's guard logic, or a future caller of this function,
    ever changes. Fixed regardless of current observability.

## Mitigations applied
  - Rewrote the comma check to reproduce C's post-increment sequencing
    explicitly: read the character, advance `p`, THEN compare -- gated
    behind the same `r0 >= 0` short-circuit C's `||` provides (i.e. the
    read/advance/compare sequence itself is inside the `else` branch
    of `if r0 < 0`, not before it).
  - Switched the inlined `PRAGMA_NEWSOURCE` whitespace-skip to call the
    shared `_skip_to_next_token(cl, p)` helper instead (behavior
    identical; consolidation for consistency/maintainability).
  - Added a new "unit-level" test category to `test_fidelity.py`
    (`UNIT_TESTS_RTOR` / `run_unit_tests()`) that calls
    `insn_parse_rtor` directly and asserts on its exact return value
    (the advanced cursor's remaining text) and `as_.errorcount`, since
    this is the only way to make the previously-invisible divergence
    observable in an automated test at all.
