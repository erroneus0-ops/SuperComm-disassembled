# Pre-Translation Checklist: `lw_expr_parse_term`

Metrics: 63 lines, 9 branches, 1 gotos

## 1. Integer width at assignment sites
Check every assignment destination type.
Bit mask operations found (may need `c_uint8` etc.):
  None. This function only builds Expr tree nodes (via Expr.oper); it
  never computes an integer result itself. The actual ~ computation
  (and its 8-bit COM8 mask) happens later in Expr._compute, not here.

## 2. Division / modulo
Not found.

## 3. char ** pointer parameters
**FOUND** -- pass the same `Ptr` instance through all callers. Do NOT
create new Ptr from `p.remaining()`.
Confirmed: `p` is threaded unchanged through every recursive call
(`_parse_term(p, ctx, compact)`, `_parse_expr(p, ctx, N, compact)`) and
is never rebuilt from `p.remaining()` anywhere in this function.

## 4. goto statements
  - `goto eval_next;`
Classify each: A=exit (return), B=shared code (helper fn), C=alternate parse (call fn).
  Classified as a **self re-entry** (closest to Pattern C): the unary
  '+' branch consumes the '+' and jumps back to the top with no other
  state to preserve, which maps directly onto a plain recursive call
  to `_parse_term(p, ctx, compact)`.

## 5. char signedness
Low risk -- check comparisons of `*p` > 127.
  Confirmed low risk: every comparison in this function is against a
  fixed ASCII punctuation character ('(', ')', ']', '+', '-', '^', '~')
  or handled via `c_isspace`/`==''`. Nothing compares `*p` against
  values > 127.

## 6. Argument evaluation order
Check for `(*p)++` in function argument position.
Python evaluates left-to-right -- verify this matches C behavior.
  None found -- no function call in this function reads and advances
  `*p` within the same argument list.

## 7. Integer promotion
Check compound expressions. Add mask only where C destination type truncates.
  N/A -- no arithmetic on `*p`'s value in this function.

## 8. Bitwise complement
**FOUND** -- use `c_complement8(v)` for 8-bit, `c_uint16(~v)` for 16-bit.
  N/A *at this level*: this function only builds the OPER_COM / OPER_COM8
  tree node (`Expr.oper(OPER_COM8, term)` / `Expr.oper(OPER_COM, term)`);
  it does not itself compute `~value`. The masking already lives in
  `Expr._compute` (`OPER_COM8: return ~vals[0] & 0xFF`), confirmed
  correct and unchanged by this audit.

## 9. Register lookup advancement
**Check** lookupreg2/3 calls share Ptr correctly.
  N/A -- this function has no register-table lookups.

## Character classification

`isspace` found -- use `c_isspace(c)`
  **BUG FOUND AND FIXED.** existing.py used Python's native `c.isspace()`
  instead of the shared `c_isspace()` primitive this checklist item
  explicitly calls for. Python's `str.isspace()` returns `True` for
  several characters C's `isspace()` (C locale) does not -- notably the
  ASCII control characters U+001C-U+001F (file/group/record/unit
  separator) and non-ASCII Unicode space separators (e.g. U+00A0 NBSP).
  Fixed: `c.isspace()` -> `c_isspace(c)`.

## Interaction risks identified

1. **End-of-input sentinel mismatch ('\0' vs '').** `Ptr.peek()` returns
   `''` (empty string) at end of input; it never returns the C NUL
   character `'\0'`. existing.py's top-of-function guard checked
   `c == '\0'`, which can never be true, so the C's
   `if (!**p) return NULL;` was never reached directly through that
   check -- true end-of-input instead fell through every other branch
   in the function and reached `ctx.parse_term(p, ctx)`, asking the
   assembler-supplied atom parser to parse a term out of nothing.
   (In the real assembler this happens to be masked by a redundant
   "not c" guard inside `AsmState._parse_term`, so it produces no
   observable *output-byte* divergence through full-program assembly --
   but it is still a real divergence from the C control flow, provable
   with a bare stub callback that lacks that redundant guard. See
   `UNIT_TESTS_PARSE_TERM` in `test_fidelity.py`.)

2. **`c.isspace()` vs `c_isspace(c)`** -- see "Character classification"
   above. Same masking effect: a stub `parse_term` without its own
   defensive whitespace handling shows the divergence directly (FS
   control character 0x1C wrongly treated as an immediate end-of-term
   by existing.py, when C would fall through to the atom parser).

3. **(Discovered during unit-testing, NOT part of this function -- flagged,
   not fixed here.)** `_skip_ws` (translating `lw_expr_parse_next_tok`,
   a *different* C function not covered by this package's `source.c`)
   has its own pre-existing bug: in its non-compact branch, the loop
   condition `p.peek() in ' \t\r\n'` is vacuously `True` when
   `p.peek()` is `''` (the empty string is a substring of every
   string in Python), so the loop never terminates once input is
   exhausted -- confirmed hanging with `_skip_ws(Ptr(''), False)`.
   This never manifests through today's full-assembly tests because
   `AsmState.parse_expr` calls the *compact* parser
   (`lw_parse_expr_compact`) by default (compact mode skips `_skip_ws`'s
   loop body entirely) and only switches to non-compact under
   `PRAGMA_NEWSOURCE`. Recommend a dedicated translation-audit pass on
   `lw_expr_parse_next_tok` / `_skip_ws` to fix this properly; out of
   scope for `lw_expr_parse_term` itself.

## Mitigations applied

1. Changed the end-of-input check from `c == '\0'` to `c == ''`,
   matching `Ptr`'s actual sentinel value (mirrors the identical, already
   -applied fix in this file's `_parse_expr`).
2. Replaced `c.isspace()` with `c_isspace(c)` (imported from
   `cocotools.c_compat`), matching this checklist's own instruction and
   eliminating the divergence in risk #2.
3. No change made to `_skip_ws` -- documented as a separate, out-of-scope
   finding for a future `lw_expr_parse_next_tok` translation package.
