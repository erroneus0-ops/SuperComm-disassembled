# Audit Summary: `lw_expr_parse_term`

Translation package: `translation_packages/10_lw_expr_parse_term`
Target: `cocotools/lw_expr.py` (`_parse_term`)
C source: `lwtools-4.24/lwlib/lw_expr.c`, function `lw_expr_parse_term`

## What I read, and in what order

1. `translation_packages/10_lw_expr_parse_term/brief.md` (the task brief)
2. `translation_packages/10_lw_expr_parse_term/source.c` — the 63-line C function (the spec)
3. `translation_packages/10_lw_expr_parse_term/checklist.md` — pre-filled risk skeleton
4. `cocotools/TRANSLATION_GUIDE.md` — full checklist categories and risk catalog
5. `cocotools/DATA_STRUCTURE_AUDIT.md` — shared struct reference (`line_t`, `asmstate_t`, `lw_expr_t`, `sectiontab_t`)
6. `cocotools/c_compat.py` — compat primitives (`c_isspace`, `Ptr`, `c_complement8`, etc.)
7. `translation_packages/10_lw_expr_parse_term/existing.py` — current (suspect) translation
8. `cocotools/lw_expr.py` — full file containing the translation target, including the already-translated
   sibling function `_parse_expr` (whose docstring documents three prior fixes, useful context for
   spotting the *same* class of bug recurring in `_parse_term`)
9. `cocotools/test_fidelity.py` — the harness, to learn its existing test conventions
   (`BEHAVIOR_TESTS`, `STRUCTURAL_TESTS`, `UNIT_TESTS_RTOR` / `run_unit_tests`) before adding new tests
   in the same style.

I then wrote an independent translation from `source.c` alone (not copying `existing.py`), and only
afterward diffed it against `existing.py` to find divergences, per the brief's required order.

## Pre-translation checklist (all 9 categories + character classification)

See `package_files/checklist.md` for the full filled-in version. Short form:

| # | Category | Finding |
|---|----------|---------|
| 1 | Integer width | None — function only builds `Expr` tree nodes, never computes a truncated value itself |
| 2 | Division/modulo | Not present |
| 3 | `char **p` | **Found** — `p` (a `Ptr`) is threaded unchanged through every recursive call; never rebuilt from `p.remaining()` |
| 4 | `goto` | **Found** — `goto eval_next;` is a self re-entry (unary `+`); maps onto a direct recursive call |
| 5 | char signedness | Safe — only ASCII punctuation compared |
| 6 | Argument order | Safe — no `(*p)++` in argument position |
| 7 | Integer promotion | Safe — no fixed-width destination in this function |
| 8 | Bitwise complement | N/A *at this level* — `OPER_COM`/`OPER_COM8` tree nodes are only *built* here; the actual `~` + mask happens later in `Expr._compute` (already correct, unchanged) |
| 9 | Register lookup | N/A — no `lookupreg2`/`lookupreg3` calls |
| — | `isspace` | **Found** — checklist explicitly calls for `c_isspace(c)`; existing.py used `c.isspace()` instead (bug — see below) |

## Divergences found between `existing.py` and the C source

Two real bugs, plus one bug discovered in a *different* function while unit-testing this one (flagged, not fixed, per scope).

### Bug 1 — end-of-input sentinel: `c == '\0'` vs `c == ''`

**C code:**
```c
if (!**p || isspace(**p) || **p == ')' || **p == ']')
    return NULL;
```

**Old Python (`existing.py`):**
```python
if c == '\0' or c.isspace() or c in (')', ']'):
    return None
```

**Why it's a bug:** `Ptr.peek()` (the stand-in for `**p`) returns `''` (empty string) at end of input —
it never returns the C NUL character `'\0'`. `c_compat.py`'s own docstring for `Ptr` and the sibling
function `_parse_expr`'s docstring (already fixed, in this same file, for the identical mistake) both
confirm this is the established, correct sentinel. Because `c == '\0'` can never be true, the
`if (!**p) return NULL;` case was never reached through that specific check — true end-of-input instead
fell through every other branch in the function and reached `ctx.parse_term(p, ctx)`, handing the
assembler-supplied atom parser an already-exhausted cursor to parse a term out of nothing.

**New Python:**
```python
if c == '' or c_isspace(c) or c in (')', ']'):
    return None
```

**Verification method:** Direct unit test `parse-term-true-eof-no-stub-call` (and its unary-`+`-then-EOF
variant `parse-term-unary-plus-then-eof-no-stub-call`) calls `_parse_term` directly with a stub
`parse_term` callback that has *no* redundant defensive check of its own, and asserts the stub is never
invoked on truly-empty input. Confirmed by temporarily reverting the fix: both tests then fail with
`stub_called=True` (see "Final test counts" below for the before/after run).

Note: this bug produces **no observable output-byte divergence** through full-program assembly, because
the real assembler's own atom-parser callback (`AsmState._parse_term` in `lwasm_core.py`) happens to carry
its own separate `if not c or c == '\0': return None` guard, which silently absorbs the problem. That
redundant safety net is exactly why 270/270 pre-existing fidelity/behavioral/structural tests already
passed even with this bug present — and exactly why a bare direct-unit test (with a minimal stub lacking
that redundant guard) was needed to prove the divergence at all.

### Bug 2 — `c.isspace()` vs `c_isspace(c)`

**C code:** `isspace(**p)` (C library `isspace()`, C locale).

**Old Python:** `c.isspace()` (Python `str.isspace()`).

**Why it's a bug:** Python's `str.isspace()` returns `True` for characters C's `isspace()` (C locale) does
not treat as whitespace — specifically the ASCII control characters U+001C–U+001F (file/group/record/unit
separator) and non-ASCII Unicode space separators such as U+00A0 (NBSP). Confirmed directly:
`'\x1c'.isspace()` is `True` in Python, but `isspace(0x1C)` is `false` in C's `"C"` locale. The project's
own `checklist.md` explicitly names this exact function's `isspace(**p)` call and specifies the mitigation
(`c_isspace(c)`) — `existing.py` simply didn't apply it.

**New Python:**
```python
if c == '' or c_isspace(c) or c in (')', ']'):
```
(same line as Bug 1's fix — both were fixed together since they're the same `if` statement)

**Verification method:** Direct unit test `parse-term-fs-control-char-reaches-stub` calls `_parse_term`
with input `'\x1c'` and the same stub callback, asserting the stub **is** invoked (matching true C control
flow, which falls through to `parse_term(p, priv)` for this character). Reverting the fix makes this test
fail with `stub_called=False`. A companion regression test, `parse-term-real-space-still-terminates`,
confirms the fix doesn't *under*-correct — genuine whitespace (`' '`) must still terminate the term
without calling the stub.

### Bug 3 — found, NOT fixed (out of scope): infinite loop in `_skip_ws`

While building the direct-unit-test harness for `_parse_term`, I discovered that `_skip_ws` (the
translation of `lw_expr_parse_next_tok`, a **different** C function not included in this package's
`source.c` or `checklist.md`) hangs forever when called with `compact=False` on already-exhausted input:

```python
def _skip_ws(p, compact):
    if not compact:
        while p.peek() not in ('\0',) and p.peek() in ' \t\r\n':
            p.advance()
```

`p.peek() in ' \t\r\n'` is vacuously `True` when `p.peek()` is `''`, because the empty string is a
substring of every Python string. Once `p` reaches true end-of-input inside this loop, the condition
never becomes false, and `p.advance()` just keeps incrementing `p.pos` past the end of the string forever.
Confirmed directly: `_skip_ws(Ptr(''), False)` hangs (had to be killed with `timeout`).

**Why this doesn't affect any existing behavior:** `AsmState.parse_expr` (the only real call path) invokes
`lw_parse_expr_compact` by default and only switches to the non-compact parser under `PRAGMA_NEWSOURCE`.
In compact mode, `_skip_ws`'s entire loop body is skipped (the `if not compact:` guard), so the bug is
currently unreachable in practice unless `PRAGMA_NEWSOURCE` is active.

**Disposition:** Documented in `checklist.md` under "Interaction risks identified" #3 and here, but
**deliberately not fixed** — it belongs to a different C function (`lw_expr_parse_next_tok`) that has its
own source, its own checklist, and its own translation package elsewhere in this project; fixing it here
would go beyond this package's declared scope (`lw_expr_parse_term`, 63 lines, 9 branches, 1 goto) without
its own pre-translation analysis. My own unit tests for `_parse_term` use `compact=True` specifically to
sidestep this pre-existing, unrelated bug (documented inline in `run_parse_term_unit_tests`'s docstring)
— which also happens to match how the real assembler invokes this code path by default. **Recommend this
be picked up as its own translation-audit package** (`lw_expr_parse_next_tok` / `_skip_ws`) before anyone
enables `PRAGMA_NEWSOURCE` support end-to-end.

## Bugs fixed — code diff summary

**File:** `cocotools/lw_expr.py`

Import line:
```diff
-from .c_compat import c_trunc_div, Ptr
+from .c_compat import c_trunc_div, c_isspace, Ptr
```

`_parse_term` top-of-function guard:
```diff
-    if c == '\0' or c.isspace() or c in (')', ']'):
+    if c == '' or c_isspace(c) or c in (')', ']'):
         return None
```

The rest of the function (parentheses, unary `+`/`-`/`^`/`~`, delegation to `ctx.parse_term`) was
independently re-derived from `source.c` and found to already match `existing.py` exactly — no further
changes needed there.

## New tests added (10 total, in `cocotools/test_fidelity.py`, `UNIT_TESTS_PARSE_TERM` / `run_parse_term_unit_tests`)

Calls `cocotools.lw_expr._parse_term` **directly** (not through the public `parse_expr()` entry point),
because `_parse_expr` has its own separate top-of-function guard that also uses `c.isspace()` and would
intercept whitespace/EOF input before it ever reached `_parse_term` — going through `parse_expr()` would
test the wrong function. A minimal stub `parse_term` callback (parses a run of digits, else returns
`None`, with no defensive checks of its own) records whether and when it was invoked, so tests can assert
on both the return value **and** whether the atom-parser delegation happened — the second signal is what
actually exposes Bugs 1 and 2, since the return value alone is `None` either way in most cases.

| Test | What it covers |
|---|---|
| `parse-term-true-eof-no-stub-call` | Bug 1 — true end-of-input must return `None` without calling the atom parser |
| `parse-term-unary-plus-then-eof-no-stub-call` | Bug 1 via the `goto eval_next` self-recursion path |
| `parse-term-fs-control-char-reaches-stub` | Bug 2 — FS control char (0x1C) is not C whitespace; must fall through to the atom parser |
| `parse-term-real-space-still-terminates` | Regression guard — genuine whitespace must still terminate immediately |
| `parse-term-paren-wraps-atom` | Parenthesized-expression branch, matched close paren |
| `parse-term-unmatched-paren-is-syntax-error` | Parenthesized-expression branch, missing close paren → `None` |
| `parse-term-unary-minus-builds-neg-node` | Unary `-` branch builds `OPER_NEG` |
| `parse-term-unary-complement-16bit-builds-com-node` | Unary `~`/`^` branch, 16-bit width → `OPER_COM` |
| `parse-term-unary-complement-8bit-builds-com8-node` | Unary `~`/`^` branch, 8-bit width → `OPER_COM8` |
| `parse-term-unary-caret-alias-for-complement` | Confirms `^` is a full alias for `~` |

This covers all 9 branches the checklist's metrics line claims for this function (EOF/whitespace/`)`/`]`
guard, `(`, unary `+`, unary `-`, unary `^`/`~` × 2 widths, delegation to `ctx.parse_term`).

## Final test counts

Before this audit (baseline, run against unmodified `existing.py`-equivalent code already in
`cocotools/lw_expr.py`):
```
170 fidelity + 53 behavioral + 5 behavioral(6309) + 30 structural + 8 expr-simplify + 4 unit
= 270 passed, 0 failed
```
(All 270 already passed even with both bugs present, confirming they were real-but-currently-masked
divergences rather than something the existing suite happened to catch.)

After this audit (with the fix applied AND the 10 new tests added):
```
170 fidelity + 53 behavioral + 5 behavioral(6309) + 30 structural + 8 expr-simplify + 4 unit
+ 10 lw_expr_parse_term unit = 280 passed, 0 failed
```

Sanity check performed (not part of the delivered suite): temporarily reverted the fix in
`cocotools/lw_expr.py` and re-ran the harness — exactly 3 of the 10 new tests failed
(`parse-term-true-eof-no-stub-call`, `parse-term-unary-plus-then-eof-no-stub-call`,
`parse-term-fs-control-char-reaches-stub`), each failing in precisely the way predicted by the bug
analysis above (`stub_called` mismatched). All other 267 pre-existing tests were unaffected by the
revert, confirming (as expected) that neither bug is currently observable at the full-program level.
Fix was then re-applied and the full 280-test suite re-confirmed green before delivery.
