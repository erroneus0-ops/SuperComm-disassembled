# ---------------------------------------------------------------------------
# FUNCTION: insn_parse_bitbit
# SOURCE:   lwtools-4.24/lwasm/insn_bitbit.c, lines 30-99
# TRANSLATED: 2026-07-18
#
# Pre-translation checklist results:
#   Integer width:   none -- r is a small plain int (0/1/2), no fixed-width
#                     assignment occurs
#   Division/modulo: none
#   char **p:        yes -- a single Ptr(operand) cursor is shared through
#                     the whole function body, matching C's single `p`
#   goto:            none
#   char signedness: safe -- toupper() only ever sees ASCII register letters
#                     and ',' / '<' / whitespace; no >127 / <0 comparisons
#   Argument order:  safe -- no (*p)++ used inside a function-call argument
#                     list anywhere in this function
#   Promotion:       safe -- r stays a plain Python int throughout
#   Complement:      none
#   lookupreg:       N/A -- this function hand-rolls the A/B/CC match
#                     instead of calling lwasm_lookupreg2/3
#
# Interaction risks identified:
#   1. lwasm_skip_to_next_token(l, p) appears TWICE in the C source:
#        - immediately after the register letter is consumed, before the
#          first comma is checked
#        - immediately after the second comma, before the '<' base-page
#          check and the third operand expression
#      Both allow whitespace at those two points in real lwasm 4.24.
#      existing.py called this at neither site -- it will reject valid
#      lines such as "CC , 1,2,3" or "A,1,2, <5" that real lwasm accepts.
#      This is the one substantive correctness bug found in existing.py.
#
#   2. C's `*(*p)++ != ','` reads the current character AND unconditionally
#      advances the pointer, even when the character turns out not to be a
#      comma (post-increment happens regardless of the comparison result).
#      existing.py's `if p.peek() != ',':` does not advance the cursor on
#      the failure path, so the returned "remaining" string differs from
#      real lwasm's pointer position at the moment of a bad-operand error.
#      Low practical impact (the line has already errored either way) but
#      not byte-for-byte faithful, so fixed here for strict fidelity.
#
# Mitigations applied:
#   - Added a _skip_to_next_token() call at both C call sites.
#   - Every comma check now does peek-then-advance-then-compare, so the
#     cursor always ends up exactly where C's (*p)++ would leave it,
#     whether or not the character matched.
# ---------------------------------------------------------------------------

from cocotools.c_compat import Ptr, c_isspace, c_toupper


def _skip_to_next_token(p):
    """Python equivalent of lwasm_skip_to_next_token(l, p).

    NOTE ON SCOPE: the real lwasm_skip_to_next_token C function was not
    independently re-derived here -- I did not execute/build the C source
    or the existing cocotools code in this session (see accompanying
    SUMMARY.md for why). This implements the conventional, well-documented
    behavior of that function name in lwasm: advance the cursor over
    whitespace to the next non-space character. If cocotools' own
    lwasm_core.py already exposes an equivalent (e.g. `as_.skip_to_next_token`
    or a Ptr method), call that instead of this local helper so there is
    only one implementation of the behavior in the codebase.
    """
    while p.peek() and c_isspace(p.peek()):
        p.advance()


def insn_parse_bitbit(as_, cl, operand):
    p = Ptr(operand)

    # r = toupper(*(*p)++);
    ch = p.peek()
    p.advance()
    r_char = c_toupper(ch)

    if r_char == 'A':
        r = 1
    elif r_char == 'B':
        r = 2
    elif r_char == 'C' and c_toupper(p.peek()) == 'C':
        r = 0
        p.advance()
    else:
        as_.register_error(cl, E_REGISTER_BAD)
        return p.remaining()

    # lwasm_skip_to_next_token(l, p);
    _skip_to_next_token(p)

    # if (*(*p)++ != ',') { error; return; }
    c = p.peek()
    p.advance()
    if c != ',':
        as_.register_error(cl, E_OPERAND_BAD)
        return p.remaining()

    e = as_.parse_expr(p)
    if not e:
        as_.register_error(cl, E_OPERAND_BAD)
        return p.remaining()
    cl.save_expr(0, e)

    c = p.peek()
    p.advance()
    if c != ',':
        as_.register_error(cl, E_OPERAND_BAD)
        return p.remaining()

    e = as_.parse_expr(p)
    if not e:
        as_.register_error(cl, E_OPERAND_BAD)
        return p.remaining()
    cl.save_expr(1, e)

    c = p.peek()
    p.advance()
    if c != ',':
        as_.register_error(cl, E_OPERAND_BAD)
        return p.remaining()

    # lwasm_skip_to_next_token(l, p);
    _skip_to_next_token(p)

    # ignore base page address modifier
    if p.peek() == '<':
        p.advance()

    e = as_.parse_expr(p)
    if not e:
        as_.register_error(cl, E_OPERAND_BAD)
        return p.remaining()
    cl.save_expr(2, e)

    ops = _ops(cl)
    cl.lint = r
    cl.len = _oplen(ops[0]) + 2
    return p.remaining()
