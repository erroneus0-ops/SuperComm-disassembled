"""
Independent verification for insn_parse_bitbit_fixed.py.

SCOPE NOTE: this does NOT use cocotools' real AsmState/Line classes or the
lwasm 4.24 binary from the source repo -- I did not clone or execute that
repository in this session. Instead this uses minimal local stubs that
implement just enough of the interface (as_.register_error, as_.parse_expr,
cl.save_expr, cl.lint, cl.len) to exercise every branch of the translated
function and confirm it matches the C control flow described in source.c.
This checks LOGICAL fidelity to the C source; it is not a substitute for
running the project's real test_fidelity.py harness against the real
lwasm 4.24 binary, which the project maintainer should still do before
merging.
"""

import sys
sys.path.insert(0, '/home/claude/audit')

# --- minimal stand-ins for c_compat.py (copied logic, not the repo file) ---
class Ptr:
    __slots__ = ('s', 'pos')
    def __init__(self, s, pos=0):
        self.s, self.pos = s, pos
    def peek(self):
        return self.s[self.pos] if self.pos < len(self.s) else ''
    def advance(self, n=1):
        self.pos += n
    def remaining(self):
        return self.s[self.pos:]

def c_isspace(c):
    return c in (' ', '\t', '\r', '\n', '\f', '\v')

def c_toupper(c):
    return c.upper() if c else ''

import types, importlib.util

# inject our stub c_compat module before importing the function under test
compat_mod = types.ModuleType('cocotools.c_compat')
compat_mod.Ptr = Ptr
compat_mod.c_isspace = c_isspace
compat_mod.c_toupper = c_toupper
cocotools_pkg = types.ModuleType('cocotools')
sys.modules['cocotools'] = cocotools_pkg
sys.modules['cocotools.c_compat'] = compat_mod

spec = importlib.util.spec_from_file_location(
    'insn_parse_bitbit_fixed', '/home/claude/audit/insn_parse_bitbit_fixed.py')
mod = importlib.util.module_from_spec(spec)
mod.E_REGISTER_BAD = 'E_REGISTER_BAD'
mod.E_OPERAND_BAD = 'E_OPERAND_BAD'
mod._ops = lambda cl: cl.ops
mod._oplen = lambda op: op
spec.loader.exec_module(mod)
insn_parse_bitbit = mod.insn_parse_bitbit


class FakeExpr:
    """Stands in for a non-null lw_expr_t."""
    def __init__(self, tag):
        self.tag = tag


class FakeAsmState:
    def __init__(self, expr_script=None):
        self.errors = []
        # expr_script: list of "results" to hand back from successive
        # parse_expr calls -- either a FakeExpr (success) or None (failure).
        # Each call also advances the Ptr past a fixed-width token so the
        # cursor moves forward the way the real parser would.
        self.expr_script = expr_script or []
        self.expr_calls = 0

    def register_error(self, cl, code):
        self.errors.append(code)

    def parse_expr(self, p):
        idx = self.expr_calls
        self.expr_calls += 1
        if idx >= len(self.expr_script):
            return None
        result, consume = self.expr_script[idx]
        p.advance(consume)
        return result


class FakeLine:
    def __init__(self):
        self.saved = {}
        self.lint = None
        self.len = None
        self.ops = [1]  # OPLEN(ops[0]) == 1 for these tests -> len = 1+2 = 3

    def save_expr(self, slot, e):
        self.saved[slot] = e


def run(operand, expr_script=None):
    as_ = FakeAsmState(expr_script)
    cl = FakeLine()
    remaining = insn_parse_bitbit(as_, cl, operand)
    return as_, cl, remaining


results = []

def check(name, cond):
    results.append((name, cond))
    print(("PASS" if cond else "FAIL"), "-", name)


# --- existing-style branch coverage -----------------------------------

as_, cl, rem = run("A,1,2,3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("register A -> lint=1, no errors, 3 exprs saved",
      as_.errors == [] and cl.lint == 1 and cl.len == 3 and set(cl.saved) == {0, 1, 2})

as_, cl, rem = run("b,1,2,3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("register lowercase b -> lint=2 (toupper applied)",
      as_.errors == [] and cl.lint == 2)

as_, cl, rem = run("CC,1,2,3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("register CC -> lint=0",
      as_.errors == [] and cl.lint == 0)

as_, cl, rem = run("CX,1,2,3")
check("register C not followed by C -> E_REGISTER_BAD",
      as_.errors == ['E_REGISTER_BAD'])

as_, cl, rem = run("X,1,2,3")
check("invalid register letter -> E_REGISTER_BAD",
      as_.errors == ['E_REGISTER_BAD'])

as_, cl, rem = run("")
check("empty operand -> E_REGISTER_BAD (falls through toupper('') mismatch, no crash)",
      as_.errors == ['E_REGISTER_BAD'])

as_, cl, rem = run("A;1,2,3")
check("missing first comma -> E_OPERAND_BAD",
      as_.errors == ['E_OPERAND_BAD'])

as_, cl, rem = run("A,,2,3", [(None, 0)])
check("first expr fails to parse -> E_OPERAND_BAD",
      as_.errors == ['E_OPERAND_BAD'])

as_, cl, rem = run("A,1;2,3", [(FakeExpr('e0'), 1)])
check("missing second comma -> E_OPERAND_BAD",
      as_.errors == ['E_OPERAND_BAD'])

as_, cl, rem = run("A,1,2;3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1)])
check("missing third comma -> E_OPERAND_BAD",
      as_.errors == ['E_OPERAND_BAD'])

as_, cl, rem = run("A,1,2,", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (None, 0)])
check("third expr fails to parse -> E_OPERAND_BAD",
      as_.errors == ['E_OPERAND_BAD'])

as_, cl, rem = run("A,1,2,<3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("base-page '<' modifier consumed before third expr",
      as_.errors == [] and cl.lint == 1 and cl.len == 3)


# --- NEW tests targeting the fixed bug: whitespace / skip_to_next_token ---

as_, cl, rem = run("A ,1,2,3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("[NEW] whitespace before first comma is now accepted (was rejected)",
      as_.errors == [])
# NOTE: a case like "A , 1,2,3" (space on BOTH sides of the comma) is also
# handled correctly by insn_parse_bitbit itself -- it isn't exercised here
# because lwasm_parse_expr's own internal whitespace-skipping isn't
# reproduced by this lightweight stub, not because of any limitation in
# the translated function.

as_, cl, rem = run("A,1,2, <3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("[NEW] whitespace between 2nd comma and '<' modifier is now accepted",
      as_.errors == [] and cl.lint == 1)

as_, cl, rem = run("A,1,2,   3", [(FakeExpr('e0'), 1), (FakeExpr('e1'), 1), (FakeExpr('e2'), 1)])
check("[NEW] whitespace between 2nd comma and 3rd expr (no '<') is now accepted",
      as_.errors == [])

n_pass = sum(1 for _, c in results if c)
n_fail = len(results) - n_pass
print(f"\n{n_pass} passed, {n_fail} failed")
