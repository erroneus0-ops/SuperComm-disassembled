# Audit Summary: `insn_parse_rlist`

## What I read, in order

1. `translation_packages/04_insn_parse_rlist/brief.md` (via web_fetch, before cloning)
2. Cloned the repo, then in order:
   1. `translation_packages/04_insn_parse_rlist/source.c` -- the C function
   2. `translation_packages/04_insn_parse_rlist/checklist.md` -- pre-filled checklist
   3. `cocotools/TRANSLATION_GUIDE.md` -- checklist categories and risk catalog
   4. `cocotools/DATA_STRUCTURE_AUDIT.md` -- `line_t`/`asmstate_t` field reference
   5. `cocotools/c_compat.py` -- compat primitives (`Ptr`, `c_uint8`, etc.)
   6. `translation_packages/04_insn_parse_rlist/existing.py` -- current translation
   7. `cocotools/insn_funcs.py` -- full file, to see `existing.py` in its real context
3. Independently re-derived the C function's logic against `existing.py`, line by line
4. `lwtools-4.24/lwasm/lwasm.c` (`lwasm_skip_to_next_token`, `lwasm_lookupreg2`) and
   `lwtools-4.24/lwasm/pass1.c` (how the parse function's return value is consumed) --
   read these because the pre-translation checklist raised questions the top-level
   files didn't answer (see below)
5. `cocotools/pass1.py` -- the Python equivalent of `pass1.c`'s post-parse handling,
   to confirm how a wrong return value would actually surface as a test failure
6. `cocotools/pseudo.py` -- to check whether `PRAGMA newsource` handling was itself
   in scope (it isn't; see "Out of scope" below)

## Pre-translation checklist (all 9 categories)

Filled in as `translation_packages/04_insn_parse_rlist/checklist.md` (included in
this package, replacing the original). Two of the original pre-filled answers were
wrong and are corrected there, with reasoning:

- **#2 Division/modulo**: original said "FOUND"; actually **not found** -- there is
  no `/` or `%` operator anywhere in `source.c`. The only `%` characters are `%s`
  format specifiers inside error-message calls. This looks like a copy-paste leftover
  from another function's checklist.
- **#3 `char **` pointer parameters**: original said "Not found"; actually **found**,
  and this is exactly where the real bug lives (see below). `insn_parse_rlist`
  receives `char **p` and passes it straight through to `insn_parse_imm8` in the
  `'#'` branch -- that's precisely the aliasing pattern TRANSLATION_GUIDE.md #3
  warns about.

All other categories (#1, #4-#9, character classification) were correctly assessed
in the original pre-filled checklist; full reasoning for each is in the updated
`checklist.md`.

## Divergence found between `existing.py` and the C source

**One divergence, with real behavioral impact.**

### The bug

C (`source.c`):
```c
if (**p == '#')
{
    insn_parse_imm8(as, l, p);
    l -> lint = 1;
    return;
}
```
`p` is `char **`, shared with the caller. `insn_parse_imm8` advances `*p` by side
effect; when `insn_parse_rlist` returns, the caller (`pass1.c`) observes the
*advanced* pointer through that same `p`.

Old Python (`existing.py` / `cocotools/insn_funcs.py`):
```python
if p.peek() == '#':
    insn_parse_imm8(as_, cl, operand)
    cl.lint = 1
    return p.remaining()
```
`insn_parse_imm8`'s Python signature takes a plain `str` (`operand`) and builds its
**own, independent** `Ptr` internally (see `insn_parse_imm8`'s definition -- it does
`p = Ptr(operand)` itself). Advancing that internal `Ptr` has no effect on the
outer `p` in `insn_parse_rlist`. The old code then discards `insn_parse_imm8`'s
return value entirely and returns the outer `p.remaining()` -- which is still the
**entire original operand string**, unconsumed.

**Was it a bug in `existing.py`, or correct behavior?** A bug. Verified against
real `lwasm 4.24` (see below): `existing.py`'s behavior does not match the
reference assembler.

### Why it matters (verified against the real assembler)

`cocotools/pass1.py` uses the parse function's return value as the authoritative
post-parse cursor to decide whether there's leftover, unconsumed operand text:

```python
remaining = ie.parse(as_, cl, operand)
...
rem = remaining if isinstance(remaining, str) else ''
if not curpragma(cl, PRAGMA_NEWSOURCE):
    first = rem[0] if rem else ''
    if first and not first.isspace() and not cl.err:
        as_.register_error2(cl, E_OPERAND_BAD, '(%s)', rem)
```

Since the old code returned the *entire unconsumed operand* instead of the
correctly-advanced remainder, any `PSHS`/`PULS`/`PSHU`/`PULU` instruction using the
immediate `#` form triggered a spurious `E_OPERAND_BAD` ("Bad operand") error --
even though the operand was completely valid.

**Reproduction against the real `lwasm 4.24` binary** (`lwtools-4.24/lwasm/lwasm`,
pre-built, used as ground truth throughout):

```
$ cat t1.asm
         ORG $3F00
TEST     PSHS  #$06
         END

$ lwasm --decb --output=t1.bin --6809 t1.asm
(succeeds, rc=0, bytes: ... 34 06 ...)

$ python3 cocotools.py asm t1.asm -o t1_ct.bin      # BEFORE the fix
/tmp/t1.asm:2: Bad operand (#$06)
error: assembly failed: 1 error(s)                   # WRONG -- diverges from lwasm
```

### The fix

C code (for reference): `insn_parse_imm8(as, l, p);` -- shared cursor, no return
value needed since it's `void` and mutates in place.

Old Python:
```python
if p.peek() == '#':
    insn_parse_imm8(as_, cl, operand)
    cl.lint = 1
    return p.remaining()
```

New Python:
```python
if p.peek() == '#':
    remaining = insn_parse_imm8(as_, cl, operand)
    cl.lint = 1
    return remaining
```

**Verification method:**
1. Reproduced the divergence against the real `lwasm 4.24` binary with a minimal
   `PSHS #$06` source file (shown above) -- before the fix, `lwasm` succeeds and
   `cocotools` errors; after the fix, both succeed and produce byte-identical
   output (`34 06`).
2. Ran the full fidelity harness (`cocotools/test_fidelity.py`) before and after --
   no regressions (166/166 -> 170/170 as new tests were added, 0 failures at every
   step).
3. Added new regression tests (below) specifically targeting this branch, then
   deliberately reverted the fix and re-ran the harness to confirm the new tests
   fail without it (they did -- 5 failures: 2 fidelity, 2 behavioral, 1 structural)
   and pass with it restored.

### A second thing investigated and ruled *out* as a bug

While testing the register-list loop under `PRAGMA newsource` (`PSHS A , B , X`
with spaces around the commas), the full-assembly-pipeline test showed a byte
mismatch against `lwasm` (`0x16` expected, `0x02` produced). This looked at first
like a second bug in `insn_parse_rlist`'s whitespace-skipping logic.

Investigation: calling `insn_parse_rlist` **directly** with `cl.pragmas` manually
set to include `PRAGMA_NEWSOURCE` produces the fully correct result (`pb=0x16`),
proving the function's own newsource-aware whitespace-skipping logic is correct.
The discrepancy in the full pipeline traces to `cocotools/pseudo.py`'s
`pseudo_parse_pragma`, which is a stub (`_stub_parse`) that does not actually
implement the `PRAGMA` directive -- so `as_.pragmas` never actually gets
`PRAGMA_NEWSOURCE` set during a real assembly run, regardless of what
`insn_parse_rlist` does. **This is a pre-existing limitation in a different,
unrelated function (`pseudo_parse_pragma`), out of scope for this translation
package**, and is not a divergence in `insn_parse_rlist` itself. Noted here so it
isn't re-discovered as a mystery by whoever picks up the `PRAGMA` translation
package later.

## New test cases added (11 total)

**Fidelity tests** (byte-for-byte vs. real `lwasm`), added to `TESTS`:
- `PSHS #$06` ("pshs-imm8") -- regression test for the exact bug found
- `PSHU #$81` ("pshu-imm8") -- same branch, different instruction/value
- `PSHU S` ("pshu-s") -- S register valid on the user-stack instructions
- `PULS U` ("puls-u") -- U register valid on the system-stack instructions

**Behavioral tests** (error/no-error vs. real `lwasm`), added to `BEHAVIOR_TESTS`:
- `behavior-pshs-immediate-form` -- `PSHS #$06` followed by another instruction
  line, confirming the fix doesn't just avoid an error on the `PSHS` line but also
  that a correctly-formed return value doesn't disturb subsequent line parsing
- `behavior-pshu-immediate-form` -- same shape for `PSHU`
- `error-pshs-register-s-invalid` -- `PSHS S` must error (can't push S onto S-stack)
- `error-pshu-register-u-invalid` -- `PSHU U` must error (can't push U onto U-stack)

**Structural tests** (internal `cl.len`/`cl.pb`/`cl.lint` state), added to
`STRUCTURAL_TESTS`:
- `struct-pshs-imm8` -- `{len: 2, pb: 0x00, lint: 1}`; confirms the immediate path
  doesn't touch `cl.pb` (the register-mask byte is encoded in the operand, not the
  postbyte) and that `cl.lint` correctly signals "1 extra byte" for emit
- `struct-pshu-s` -- `{len: 2, pb: 0x40, lint: 0}`
- `struct-puls-u` -- `{len: 2, pb: 0x40, lint: 0}`; together with `struct-pshu-s`
  this documents/verifies that U and S share bit `0x40` in the postbyte, since only
  one of the two can ever legally appear in a given push/pull context

Each new test was verified to fail (with an informative message, not a crash) when
the fix was reverted, confirming they actually exercise the fixed code path rather
than passing vacuously.

## Final test counts

```
Fidelity tests:          170 passed, 0 failed  (was 166 passed, 0 failed)
Behavioral tests:          41 passed, 0 failed  (was 37 passed, 0 failed)
Behavioral (6309-only):     4 passed, 0 failed  (unchanged)
Structural tests:          23 passed, 0 failed  (was 20 passed, 0 failed)
Expression-simplify tests:  8 passed, 0 failed  (unchanged)

Total: 246 passed, 0 failed
```

## Files changed

- `cocotools/insn_funcs.py` -- one-branch fix in `insn_parse_rlist`'s `'#'` handling
- `cocotools/test_fidelity.py` -- 11 new test cases across the three suites
- `translation_packages/04_insn_parse_rlist/checklist.md` -- corrected checklist
  (items #2 and #3 fixed, all 9 categories + interaction risks/mitigations filled in)
- `translation_packages/04_insn_parse_rlist/existing.py` -- updated to the fixed
  translation, with an inline comment documenting the fix and pointing here
