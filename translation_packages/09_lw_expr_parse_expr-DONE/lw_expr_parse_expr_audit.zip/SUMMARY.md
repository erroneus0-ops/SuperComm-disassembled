# Translation Audit Summary: `lw_expr_parse_expr`

## What I read, and in what order

1. `translation_packages/09_lw_expr_parse_expr/brief.md` (the task itself)
2. Cloned the repo per the brief's instructions
3. `translation_packages/09_lw_expr_parse_expr/source.c` -- the C spec
4. `translation_packages/09_lw_expr_parse_expr/checklist.md` -- pre-filled risk categories
5. `cocotools/TRANSLATION_GUIDE.md` -- full checklist/risk catalog
6. `cocotools/DATA_STRUCTURE_AUDIT.md` -- shared struct reference (not directly relevant to this pure-function translation, but read per the brief's required order)
7. `cocotools/c_compat.py` -- compat primitives
8. `translation_packages/09_lw_expr_parse_expr/existing.py` -- current translation (suspect)
9. `cocotools/lw_expr.py` -- full file containing the translation target, including the actual live copy of `_parse_expr`, `_parse_term`, `_skip_ws`, and `_PARSE_OPERATORS`
10. **The real, full `lwtools-4.24/lwlib/lw_expr.c`** (available in the cloned repo, not just the excerpted `source.c`) -- read to see `lw_expr_parse_next_tok`'s actual definition, since that clarified a question the excerpt alone couldn't answer (whether whitespace-skipping happens per-call or via a module-level `parse_compact` flag).
11. `cocotools/test_fidelity.py` -- to understand the harness structure before adding tests.

I then wrote an independent Python translation from `source.c` (per the
required translation order), compared it branch-by-branch against
`existing.py`, and used the **prebuilt real lwasm 4.24 binary** as the
final arbiter for every case where the C source's intended behavior was
ambiguous from reading alone.

## Pre-translation checklist

Filled in completely in the updated `checklist.md` in this package
directory. Summary of the two categories that actually had findings:

- **#3 (`char **p`)**: `p` is a shared `Ptr`, passed unchanged through
  every recursive call -- verified, no divergence.
- **#4 (`goto`)**: `goto eval_next;` is Pattern B, translated as
  `while True:` -- verified, no divergence in the control-flow shape
  itself (the *content* of the loop body had real bugs -- see below).

All other categories (integer width, division/modulo, char signedness,
argument order, promotion, complement, lookupreg) had no findings for
this specific function.

## Divergences found between `existing.py` and the C source

I found **four** divergences, all confirmed against the real lwasm 4.24
binary (not just reasoned about from the C text). All four were bugs in
`existing.py`.

### 1. Operator table sorted by string length instead of declaration order

**C** (`source.c`): the `operators[]` array is walked in the order it is
declared, and the inner loop breaks at the **first** entry whose string
is a complete prefix of the remaining input.

**existing.py**: sorted `_PARSE_OPERATORS` by descending string length
("longest match first"), explicitly to get conventional longest-match
tokenizing.

**Why this is a bug, not a style choice**: because `<` is declared
before `<=` in the real C table (same for `>`/`>=`, and the single-char
`!` bwor-alias before `!=`), and each short operator is itself a
complete prefix of the longer one, C's first-match-wins loop can never
reach the longer operator -- it commits to the short one, and the
dangling `=` afterward fails to parse as a term. **This means real
lwasm 4.24 cannot parse `<=`, `>=`, or `!=` as their own operators at
all.** I confirmed this directly:

```
$ echo 'RESULT EQU 5<=10' | lwasm ...
ERROR: Bad operand
$ echo 'RESULT EQU 10>=5' | lwasm ...
ERROR: Bad operand
$ echo 'RESULT EQU 5!=6' | lwasm ...
ERROR: Bad operand
```

`existing.py`'s longest-match sort would have accepted all three as
their own operators, silently disagreeing with real lwasm.

**Fix**: `_PARSE_OPERATORS` restored to exact C declaration order;
`_match_operator()` returns the first complete-prefix hit, matching
the C loop exactly.

**Verified by**: `expr-le-operator-unreachable`,
`expr-ge-operator-unreachable`, `expr-ne-operator-unreachable` (all
new tests), plus the control case `expr-ne-altspelling-works` (`<>`
is declared *before* the single-char `<`, so it is never shadowed and
must still work).

### 2. Precedence used to filter candidates *during* the search, not after

**C**: finds a match unconditionally (precedence plays no role in the
search itself), and only *after* a match is fixed does it check whether
that operator's precedence clears the `prec` threshold.

**existing.py**: skipped any candidate operator whose precedence was
`<= prec` *during* the search itself (`if op_prec <= prec: continue`).

**Why this is a bug**: it looks equivalent to "checking precedence
after" in isolation, but it is not, once divergence #1's shadowing is
in play. Consider parsing at `prec=50` (inside the right operand of a
bwand `&`) with remaining input `!=3`. Real C hits the single-char `!`
first (declared before `!=`, prec 50), and since `50 <= 50` returns
immediately without consuming anything -- the *outer* (`prec=0`) call
then consumes `!` itself, leaving a dangling `=3` that cannot parse as
a term, so the **whole expression fails**. `existing.py`'s
precedence-filtered search, however, skips `!` (its prec 50 is `<=`
the *inner* call's prec 50) and finds `!=` instead (prec 55, not
skipped) -- incorrectly recognizing it as a valid NE operator.

I confirmed this exact scenario against real lwasm:

```
$ echo 'RESULT EQU 1&2!=3' | lwasm ...
ERROR: Bad operand
```

`existing.py` would have parsed this as `1 & (2 != 3)` = `1`.

**Fix**: `_match_operator()` performs no precedence filtering at all;
precedence is checked only once, immediately after a match is already
fixed -- mirroring the C source's two separate `if` statements.

**Verified by**: `expr-operator-precedence-interaction` (new test).

### 3. `c == '\0'` can never match `Ptr`'s actual end-of-string sentinel

**C**: `!**p` checks for the true null terminator of the C string.

**existing.py**: checked `c == '\0'`, but `Ptr.peek()` (per its own
docstring in `c_compat.py`) returns `''` (empty string) at end of
input, never the null character `'\0'`. This check could never fire.

**Why it didn't already break everything**: it happened to cancel out
with divergence #4 below -- "no operator matched" incorrectly returning
`term1` was, by coincidence, exactly the right behavior at genuine
end-of-input (which is also a "no operator matched" case once the
dead `c == '\0'` check is factored out). Fixing #4 without also fixing
this would have broken ordinary single-token expressions like a bare
`5`.

**Fix**: changed both end-of-input gates (`c == '\0'`) to `c == ''`.

**Verified by**: `expr-simple-end-of-input` (new regression guard,
added specifically because this fix's correctness *depends on*
divergence #3 and #4 being fixed together).

### 4. Returning `term1` instead of `None`/NULL on real parse failure

**C**: both the "no operator recognized" branch and the "term2 came
back NULL" branch call `lw_expr_destroy(term1); return NULL;` --
i.e. the *entire* expression parse fails, discarding the term that was
already built.

**existing.py**: returned `term1` in both branches, with an explicit
comment acknowledging the divergence ("we keep term1 to be safe").

**Why this is a bug**: real lwasm treats a term followed by
unrecognized trailing input, or a dangling operator with nothing valid
after it, as a hard syntax error -- not a successfully parsed prefix.
Confirmed:

```
$ echo 'RESULT EQU 5+' | lwasm ...      # dangling operator
ERROR: Bad operand
$ echo 'RESULT EQU 5.1' | lwasm ...     # unrecognized trailing char
ERROR: Bad operand
```

**Fix**: both branches now `return None`.

**Verified by**: `expr-dangling-operator` (discriminates old vs. new
code -- fails under the old logic) and
`expr-trailing-unrecognized-char` (still correct under the fix, though
I found during verification that this particular case is *also*
independently caught by a different layer of cocotools even under the
old buggy code, so it doesn't by itself discriminate old vs. new --
noted here for honesty rather than glossed over. The dangling-operator
and precedence-interaction tests are the ones that actually fail
without this fix).

## Every bug fixed: C code / old Python / new Python / verification

All four are detailed above with the C source excerpt, the old
(`existing.py`, prior state) Python, the new Python (now in
`cocotools/lw_expr.py`), and the exact shell command against the real
lwasm 4.24 binary used to verify each one. The new `cocotools/lw_expr.py`
also carries this same information as inline comments and an expanded
function docstring, so the reasoning travels with the code.

## New test cases added (8, in `cocotools/test_fidelity.py` `BEHAVIOR_TESTS`)

| Test | Exercises |
|---|---|
| `expr-le-operator-unreachable` | Divergence #1 (`<=` shadowed by `<`) |
| `expr-ge-operator-unreachable` | Divergence #1 (`>=` shadowed by `>`) |
| `expr-ne-operator-unreachable` | Divergence #1 (`!=` shadowed by `!`) |
| `expr-ne-altspelling-works` | Control case: `<>` is *not* shadowed |
| `expr-trailing-unrecognized-char` | Divergence #4 (unrecognized trailing input) |
| `expr-dangling-operator` | Divergence #4 (operator with no valid right operand) |
| `expr-operator-precedence-interaction` | Divergence #2 (match-then-filter vs. filter-then-match) |
| `expr-simple-end-of-input` | Regression guard for divergence #3 (must not break ordinary parsing) |

Each test asserts that cocotools and the real lwasm 4.24 binary agree
(both error, or both produce identical output bytes) -- not just that
cocotools produces some particular value.

## Final test counts

Before this audit: **262 passed, 0 failed** (170 fidelity + 45
behavioral + 5 behavioral-6309 + 30 structural + 8 expression-simplify +
4 unit) -- none of these pre-existing tests exercised the four
divergences above.

After this audit: **270 passed, 0 failed** (262 pre-existing + 8 new
behavioral tests, all in the "behavioral" category). No pre-existing
test's expected result was changed.

```
Running 170 fidelity tests (6809 mode)...
Results: 170 passed, 0 failed out of 170 tests
Running 53 behavioral tests...
Behavioral results: 53 passed, 0 failed out of 53 tests
Running 5 behavioral (6309-only) tests...
Behavioral (6309-only) results: 5 passed, 0 failed out of 5 tests
Running 30 structural tests...
Structural results: 30 passed, 0 failed out of 30 tests
Running 8 expression-simplify tests...
Expression-simplify results: 8 passed, 0 failed out of 8 tests
Running 4 unit tests...
Unit results: 4 passed, 0 failed out of 4 tests
```

## Note on scope: a related, out-of-scope observation

`_parse_term` (the sibling function `lw_expr_parse_term`, a separate
translation package) contains the same `c == '\0'`-vs-`''` sentinel
mistake as divergence #3. I did not fix it here because it is out of
scope for this package (a different C function), and because tracing
through the call sites showed it is currently unreachable in practice:
`_parse_expr`'s own (now-fixed) gate always intercepts genuine
end-of-input before ever calling `_parse_term` in that state. It should
still be corrected when `lw_expr_parse_term` is audited on its own, for
consistency and in case some other caller reaches it differently.
