# Pre-Translation Checklist: `lw_expr_parse_expr`

Metrics: 102 lines, 9 branches, 1 gotos

STATUS: Complete. Translation verified against real lwasm 4.24 binary and
cocotools/test_fidelity.py (270/270 passing, 8 new tests added).

## 1. Integer width at assignment sites
Bit mask operations found (may need `c_uint8` etc.):
  None. No fixed-width assignments in this function.

## 2. Division / modulo
None found in this function (present elsewhere in lw_expr.c, already
handled for OPER_MOD / OPER_INTDIV).

## 3. char ** pointer parameters
FOUND -- `p` is a `Ptr` instance, passed unchanged through every
recursive call to `_parse_expr` and to `_parse_term`. No new `Ptr` is
ever constructed from `p.remaining()`.

## 4. goto statements
  - `goto eval_next;` -- Pattern B (shared code re-entered repeatedly
    with the same live locals: term1, prec). Translated as `while True:`
    with an explicit loop-continue at the bottom (mirroring the C
    control flow exactly) rather than a helper function, since nothing
    about the loop body needs isolating into its own callable.

## 5. char signedness
Safe. All comparisons are against fixed ASCII terminator/operator
characters; Ptr.peek() never returns anything that requires C's
signed-char semantics to interpret correctly for this function.

## 6. Argument evaluation order
No `(*p)++` (or Python equivalent) appears in function-argument
position anywhere in this function. Safe.

## 7. Integer promotion
No fixed-width destination anywhere in this function -- opern/i in C are
plain `int` loop counters with no assignment into a narrower type.
Safe, no masking needed.

## 8. Bitwise complement
Not found in this function.

## 9. Register lookup advancement
N/A -- this function does not call lookupreg2/3.

## Character classification
`isspace` found -- used via Python's `c.isspace()` (matches C's
`isspace()` for the ASCII whitespace set this function deals with; no
divergence found, left as-is).

## Interaction risks identified

1. **Operator-table shadowing (declaration order, not longest match).**
   The C `operators[]` array is walked in DECLARATION order, and the
   loop commits to the FIRST entry whose string is a complete prefix of
   the remaining input -- not the longest such entry. Because `<` is
   declared before `<=` (same for `>`/`>=`, and the single-char `!`
   bwor-alias before `!=`), and each of those short operators is itself
   a complete-prefix match for input that actually continues into the
   longer operator, the longer operator can **never** be reached.
   Confirmed against the real lwasm 4.24 binary: `<=`, `>=`, and `!=`
   all produce `Bad operand` -- the short operator matches, consumes
   one character, and the dangling `=` fails to parse as a term.

2. **Matching happens before, and independently of, precedence
   filtering.** The C code finds an operator match unconditionally
   (regardless of `prec`), and only afterward checks whether its
   precedence clears the `prec` threshold. Skipping low-precedence
   candidates *during* the search (rather than after) is not equivalent
   once shadowing (risk 1) is in play: at a `prec` between a shadowed
   short operator's precedence and its shadowing target's precedence
   (e.g. `prec=50`, between `!` at 50 and `!=` at 55), a
   precedence-filtered search incorrectly "sees" and accepts `!=`,
   while real lwasm permanently commits to `!` first and bails out via
   the low-precedence return before `!=` is ever considered. Confirmed
   against the real binary with `1&2!=3`, which real lwasm rejects
   entirely as `Bad operand`.

3. **`Ptr.peek()` end-of-input sentinel is `''`, not `'\0'`.** A prior
   version of this translation checked `c == '\0'`, which is never true
   for `Ptr`'s actual end marker. It happened to produce the right
   answer at genuine end-of-input only because it was paired with
   another bug (see mitigation 5) that also (incorrectly) returned
   term1 when no operator matched -- the two bugs canceled out for the
   single most common case (a bare expression with nothing following
   it) but not for any other case.

## Mitigations applied

1/2. `_PARSE_OPERATORS` kept in exact C declaration order (previously
     sorted by descending string length -- removed). Matching is done
     by a dedicated `_match_operator(p)` that returns the first
     complete-prefix hit with **no** precedence filtering; precedence
     is checked only after a match is already fixed, mirroring the two
     separate `if` statements in the C source.

3. End-of-input checks changed from `c == '\0'` to `c == ''` (Ptr's
   actual sentinel) in both gates (initial term1 gate, and the
   `eval_next` loop gate).

4. (Verified correct, no change needed) `if (operators[opern].operprec
   <= prec) return term1;` was already translated correctly as an early
   return with no destroy.

5. `lw_expr_destroy(term1); return NULL;` -- both the "unrecognized
   operator" branch and the "term2 came back NULL" branch destroy term1
   and return NULL in C. The prior translation returned `term1` in both
   branches instead (explicitly flagged in its own comments as a
   deliberate divergence, "to be safe"). This is wrong and observable:
   real lwasm rejects a term followed by unrecognized trailing input
   (e.g. `5@`, `5.1`) and a dangling operator with no valid right
   operand (e.g. `5+`) as complete syntax errors, not as a successful
   partial parse. Both branches now return `None`.
