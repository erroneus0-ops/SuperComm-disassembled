# Audit Summary: `insn_emit_logicmem` (translation_packages/16)

## What I read, in order

1. `translation_packages/16_insn_emit_logicmem/source.c` — diffed against
   `lwtools-4.24/lwasm/insn_logicmem.c` lines 74-95 (byte-identical).
2. `translation_packages/16_insn_emit_logicmem/checklist.md` (pre-filled,
   then completed/corrected as part of this session)
3. `cocotools/TRANSLATION_GUIDE.md` / `cocotools/DATA_STRUCTURE_AUDIT.md` /
   `cocotools/c_compat.py` (re-read from the package-14/15 sessions)
4. `translation_packages/16_insn_emit_logicmem/existing.py`
5. `cocotools/insn_funcs.py` — `insn_emit_logicmem` and
   `_insn_emit_gen_aux` (the shared helper it delegates to)

Package 15 (`insn_parse_logicmem`), audited immediately before this one
in the same session, covers the same C file (`insn_logicmem.c`), so the
full-file read from that session already gave me `insn_emit_logicmem`'s
exact C source ahead of opening this package's own copy — they matched
byte-for-byte.

## Pre-translation checklist

See the completed `checklist.md`. One correction worth calling out: the
pre-filled checklist template flagged category #2 (division/modulo) as
"**FOUND** -- use c_trunc_div()/c_trunc_mod()". There is no `/` or `%`
anywhere in this function's 22 lines. I checked the full `source.c`
top to bottom to be sure before writing "not found" over the template's
claim — this looks like a stale default carried over from a template
that wasn't customized per-function, not a real finding for this
specific package. Worth a note to whoever assembles these checklists,
since a checklist that claims a risk that isn't there is only slightly
better than one that misses a risk that is.

## Independent translation vs. `existing.py`

Translated `source.c` independently first:

```python
def insn_emit_logicmem(as_, cl):
    e = cl.fetch_expr(100)
    if not (e and e.istype(TYPE_INT)):
        as_.register_error(cl, E_IMMEDIATE_UNRESOLVED)
        return
    v = e.intval()
    _insn_emit_gen_aux(as_, cl, v & 0xFF)
```

This matched `existing.py` exactly, character for character. No
divergence found.

Two things worth documenting even though neither was a bug:

**1. Null-safety guard (same pattern as `insn_emit_bitbit`, package 14).**
`lwasm_fetch_expr` can return NULL; C's `lw_expr_istype` handles that
(`if (!e) return 0;`), Python's `Expr.istype` does not. `existing.py`
already has the correct `e and e.istype(TYPE_INT)` guard, not a bare
`e.istype(...)`.

**2. Dead code in the C source, correctly not reproduced.** The
C function has a commented-out range check:

```c
/*	if (v < -128 || v > 255)
	{
		fprintf(stderr, "BYTE: %d\n", v);
		lwasm_register_error(as, l, E_BYTE_OVERFLOW);
		return;
	}
*/
```

This never compiles and never runs in real lwasm 4.24 — it's a
`/* ... */` block comment, not conditionally-compiled code. A translator
who added this check "for extra safety" would be introducing a new
E_BYTE_OVERFLOW error that the real reference assembler never produces,
which is exactly backwards from the fidelity goal. `existing.py`
correctly has no such check. I verified this isn't a case of "should be
active but isn't" by checking whether `v` could ever be genuinely out of
byte range at this point — it can (e.g. a 16-bit immediate expression) —
but real lwasm just masks it with `& 0xff` and moves on regardless,
matching `existing.py`'s behavior.

## Bugs fixed

None — `existing.py` was already correct.

## Verification method

Built lwasm 4.24 from its own source tarball (same build used for
packages 14/15) and hand-derived expected output for all four general
addressing modes a logicmem instruction can use, then confirmed against
the real assembler:

| Source | Expected | lwasm 4.24 (from-source build) |
|---|---|---|
| `AIM #$0F,$20` (direct) | `02 0F 20` | `02 0F 20` ✓ |
| `OIM #$80,$1234` (extended) | `71 80 12 34` | `71 80 12 34` ✓ |
| `EIM #$FF,5,X` (indexed, 5-bit offset) | `65 FF 05` | `65 FF 05` ✓ |
| `TIM #$3C,[10,X]` (indexed, indirect) | `6B 3C 98 0A` | `6B 3C 98 0A` ✓ |

Also confirmed the error path: `AIM #UNDEF,$20` (undefined symbol as the
mask value) causes real lwasm to exit non-zero with no output —
matching `insn_emit_logicmem`'s `E_IMMEDIATE_UNRESOLVED` + early-return
behavior.

Added these five cases to `BEHAVIOR_TESTS_6309` in
`cocotools/test_fidelity.py` (AIM/OIM/EIM/TIM are all 6309-only), which
compares cocotools' actual assembled output against the real lwasm
binary byte-for-byte, not just against my own hand-derivation. All five
pass.

Note: these tests exercise `insn_parse_logicmem` (package 15) and
`insn_emit_logicmem` (this package) together end-to-end, since parsing
has to succeed before emission can run. Between the two packages, this
gives real full-pipeline confidence for the non-NEWSOURCE-dependent
behavior of the whole `insn_*_logicmem` family — the NEWSOURCE-specific
fix from package 15 is separately verified there via an isolated stub
harness, for the reasons documented in that package's SUMMARY.md.

Also noted, for the record: `_insn_emit_gen_aux` (the shared helper this
function delegates to) carries its own pre-existing note flagging gaps
relative to its true C source (`insn_gen.c`) — specifically around the
indexed-addressing branch's cycle-counting and operand-size-warning
behavior. That helper is not part of this package's scope (its own C
source, `insn_gen.c`, was never part of any of the 16 packages), and the
note explicitly says not to guess at fixes without that C to diff
against. I didn't touch it. It doesn't affect the byte-output tests
added here, which all pass, but it's worth flagging again since it's a
dependency of this function's correctness for indexed addressing modes
specifically.

## Final test counts (both packages 15 and 16 together)

```
Fidelity (6809 mode):              170 passed, 0 failed
Behavioral:                         53 passed, 0 failed
Behavioral (6309-only):             21 passed, 0 failed   (was 16; +5 new)
Structural:                         30 passed, 0 failed
Expression-simplify:                 8 passed, 0 failed
Unit:                                4 passed, 0 failed
lw_expr_parse_term unit:            10 passed, 0 failed
-----------------------------------------------------------
Total:                              296 passed, 0 failed
```

Plus the 5-case local stub harness for package 15's NEWSOURCE-specific
fix (not part of the counts above, run separately — see that package's
SUMMARY.md). All pre-existing tests still pass; no test was modified to
make it pass.

## All 16 packages

With this, all 16 translation packages have been audited:

```
01-12: DONE (prior sessions)
13:    insn_parse_bitbit  -- audited by a prior session (found/fixed the
                              same skip_to_next_token bug class)
14:    insn_emit_bitbit   -- audited this session, no bug found
15:    insn_parse_logicmem -- audited this session, 1 bug found and fixed
16:    insn_emit_logicmem -- audited this session, no bug found
```

One open item flagged but intentionally not fixed (out of scope for a
single-function package): `PRAGMA_NEWSOURCE`'s alternate expression
parser (`lw_parse_expr`) does not appear to be implemented anywhere in
`cocotools/`, and `pseudo_parse_pragma` is a stub, so `pragma` directives
in source are currently no-ops. Recommend a dedicated pass over the
"new source format" support if that's meant to be a supported mode
before calling the assembler complete.
