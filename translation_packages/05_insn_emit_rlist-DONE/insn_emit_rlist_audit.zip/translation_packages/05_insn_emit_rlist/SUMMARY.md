# Translation Audit Summary: `insn_emit_rlist`

## Reading order

1. `translation_packages/05_insn_emit_rlist/source.c` (`insn_rlist.c` lines 96-108)
2. `translation_packages/05_insn_emit_rlist/checklist.md` (pre-filled risk categories)
3. `cocotools/TRANSLATION_GUIDE.md`
4. `cocotools/DATA_STRUCTURE_AUDIT.md`
5. `cocotools/c_compat.py`
6. `translation_packages/05_insn_emit_rlist/existing.py` (suspect translation)
7. `cocotools/insn_funcs.py` (translation target, found `insn_emit_rlist` at
   the original line 1368)
8. Followed the trail into `lwtools-4.24/lwasm/cycle.c` to read
   `lwasm_cycle_calc_rlist` (lines 656-670), since `source.c` calls it and
   it turned out to have no Python translation anywhere in the repo yet.

## Pre-translation checklist (all 9 categories)

| # | Category | Finding |
|---|----------|---------|
| 1 | Integer width at assignment sites | None. No fixed-width C types assigned in this function. |
| 2 | Division / modulo | Not found. |
| 3 | `char **p` pointer parameters | Not found -- `insn_emit_rlist` takes `(asmstate_t *as, line_t *l)`, no cursor parameters. |
| 4 | `goto` statements | None. |
| 5 | `char` signedness | Low risk / N/A -- no `char` comparisons in this function. |
| 6 | Argument evaluation order | Safe -- no `(*p)++`-style argument-position side effects; the only calls are `insn_emit_imm8(as, l)`, `lwasm_emitop(l, ...)`, `lwasm_emit(l, l->pb)`, `lwasm_cycle_calc_rlist(l)`, none of which have order-sensitive arguments. |
| 7 | Integer promotion | Safe -- `cycles` in the helper is accumulated as a plain `int` in both C and Python; max value is 8 (four 8-bit regs \* 1 + four 16-bit regs \* 2), never truncated. |
| 8 | Bitwise complement | Not found. |
| 9 | Register lookup advancement | N/A -- this function doesn't parse register names, it only reads the already-encoded `l->pb` bitmask. |

Interaction risks and mitigations are filled in directly in
`checklist.md` in this package (see that file for the full text); summarized
below.

## Divergences found between `existing.py` and the C source

**One divergence, one bug.**

`existing.py`:
```python
def insn_emit_rlist(as_, cl):
    if cl.lint == 1:
        insn_emit_imm8(as_, cl); return
    cl.emitop(_ops(cl)[0])
    cl.emit(cl.pb)
```

C source (`insn_rlist.c` lines 96-108):
```c
EMITFUNC(insn_emit_rlist)
{
	if (l -> lint == 1)
	{
		insn_emit_imm8(as, l);
		return;
	}

	lwasm_emitop(l, instab[l -> insn].ops[0]);
	lwasm_emit(l, l -> pb);

	l -> cycle_adj = lwasm_cycle_calc_rlist(l);
}
```

**Divergence:** `existing.py` is missing the final line,
`l->cycle_adj = lwasm_cycle_calc_rlist(l);`, entirely.

**Verdict: bug in `existing.py`.** This is not a stylistic or intentional
omission -- `cycle_adj` is a real field on `line_t` / `Line` (present in
`DATA_STRUCTURE_AUDIT.md`'s field table, initialized to `0`), and
`lwasm_cycle_calc_rlist` is a real, non-trivial C function
(`cycle.c` lines 656-670) that computes a per-instruction cycle-count
adjustment based on which registers appear in the push/pull list. Dropping
it means every PSHS/PULS/PSHU/PULU instruction with more than the
"default" cycle count would report the wrong cycle count in listing output
(`list.c` uses `cl->cycle_base + cl->cycle_adj` for the displayed and
totaled cycle count) -- while producing byte-identical *object code*. This
is precisely the class of bug the byte-fidelity harness (170 tests) cannot
catch on its own, because it only compares assembled bytes, not internal
line state or listing output. It's also exactly the scenario
`TRANSLATION_GUIDE.md` calls out: a translation that "looks correct,
passes casual review, produces plausible output for easy inputs, and
fails silently on the inputs that matter" -- here, "the inputs that
matter" are any use of the listing/cycle-count feature rather than raw
assembly.

I also independently translated the function directly from `source.c`
before comparing against `existing.py` (per the required translation
order), and confirmed by hand that my from-scratch translation included
the `cycle_adj` line and `existing.py` did not -- there was no ambiguity
about which side was correct once `cycle.c` was read.

No other divergences were found. The `lint == 1` branch and the
`emitop`/`emit` calls in `existing.py` match the C exactly, including
early return, and `insn_resolve_rlist` (a no-op in C, also a no-op /
`pass` in Python) was already correct and untouched.

## Bug fixed

**C code** (the line that was missing):
```c
l -> cycle_adj = lwasm_cycle_calc_rlist(l);
```

**Referenced C helper**, also previously untranslated anywhere in the
repo (`cycle.c` lines 656-670):
```c
int lwasm_cycle_calc_rlist(line_t *cl)
{
	int i, cycles = 0;

	for (i = 0; i < 8; i++)
	{
		if (cl->pb & 1 << i)
			cycles += (i <= 3) ? 1 : 2;
	}

	return cycles;
}
```

**Old Python** (`cocotools/insn_funcs.py`, `insn_emit_rlist`):
```python
def insn_emit_rlist(as_, cl):
    if cl.lint == 1:
        insn_emit_imm8(as_, cl); return
    cl.emitop(_ops(cl)[0])
    cl.emit(cl.pb)
```

**New Python** (`cocotools/insn_funcs.py`):
```python
def _cycle_calc_rlist(cl):
    """lwasm_cycle_calc_rlist(cl): extra ticks for pushed/pulled registers.

    1 cycle for each of the four 8-bit registers (bits 0-3: CC,A,B,DP),
    2 cycles for each of the four 16-bit registers (bits 4-7: X,Y,U/S,PC).
    """
    cycles = 0
    for i in range(8):
        if cl.pb & (1 << i):
            cycles += 1 if i <= 3 else 2
    return cycles

def insn_emit_rlist(as_, cl):
    if cl.lint == 1:
        insn_emit_imm8(as_, cl); return

    cl.emitop(_ops(cl)[0])
    cl.emit(cl.pb)

    cl.cycle_adj = _cycle_calc_rlist(cl)
```

**Verification method:**

`cycle_adj` has no effect on assembled bytes, so byte-comparison against
`lwasm` (the existing 170-test harness) cannot exercise this fix at all --
confirmed by running the full suite both before and after the fix with
identical (170/170, 41/41, 4/4) pass counts. Verification instead required
new *structural* tests that inspect `cl.cycle_adj` directly after
assembling a line in-process (the same mechanism the existing 23
structural tests use for `len`/`pb`/`lint`). I hand-computed the expected
`cycle_adj` for several register combinations directly from the
`lwasm_cycle_calc_rlist` algorithm (bit 0-3 -> 1 cycle each, bit 4-7 -> 2
cycles each) and asserted those values; see below.

## New tests added

Added 5 structural tests to `STRUCTURAL_TESTS` in `cocotools/test_fidelity.py`:

| Test | Source | Asserts | Covers |
|------|--------|---------|--------|
| `struct-pshs-d-cycle-adj` | `PSHS D` | `pb=0x06, cycle_adj=2` | Two 8-bit registers (A,B) -> 1+1 |
| `struct-pshs-pc-cycle-adj` | `PSHS PC` | `pb=0x80, cycle_adj=2` | One 16-bit register (PC) -> 2 |
| `struct-pshs-abx-cycle-adj` | `PSHS A,B,X` | `pb=0x16, cycle_adj=4` | Mix of 8-bit and 16-bit regs -> 1+1+2 |
| `struct-puls-abxpc-cycle-adj` | `PULS A,B,X,PC` | `pb=0x96, cycle_adj=6` | All four bit ranges combined, PULS instead of PSHS -> 1+1+2+2 |
| `struct-pshs-imm8-cycle-adj` | `PSHS #$06` | `pb=0x00, cycle_adj=0` | The `lint == 1` early-return branch -- confirms `cycle_adj` is **not** computed from a stale/wrong `pb` when the imm8 path is taken, and instead reflects the `0` that `cycle_update_count()` sets during `insn_emit_imm8`'s own `emitop()` call |

These 5 specifically target the one branch (`lint != 1`, the "normal"
rlist path) and the one previously-untested field (`cycle_adj`) that the
bug affected, plus the early-return branch as a negative case to confirm
the fix didn't introduce a regression there.

## Final test counts

```
Running 170 fidelity tests (6809 mode)...
Results: 170 passed, 0 failed out of 170 tests

Running 41 behavioral tests...
Behavioral results: 41 passed, 0 failed out of 41 tests

Running 4 behavioral (6309-only) tests...
Behavioral (6309-only) results: 4 passed, 0 failed out of 4 tests

Running 28 structural tests...
Structural results: 28 passed, 0 failed out of 28 tests

Running 8 expression-simplify tests...
Expression-simplify results: 8 passed, 0 failed out of 8 tests
```

**251 passed, 0 failed** (246 pre-existing + 5 new structural tests for
this function). All pre-existing tests continue to pass unmodified.
