# `lw_expr_simplify_l` Translation Audit — Summary

**Package:** `translation_packages/01_lw_expr_simplify_l` (SuperComm-disassembled)
**Function translated:** `lw_expr_simplify_l` / `lw_expr_simplify_go` — lwtools-4.24 `lwlib/lw_expr.c`
**Python location:** `Expr._simplify_l` / `Expr._simplify_go` in `cocotools/lw_expr.py`

## What I did

1. **Read the brief and required materials** in order: `brief.md`, `checklist.md`
   (pre-filled), `TRANSLATION_GUIDE.md`, `DATA_STRUCTURE_AUDIT.md`, `c_compat.py`.

2. **Retrieved the real source.** The brief's linked lwtools.ca URL 404'd, and the
   GitHub repo isn't reachable via the sandboxed `web_fetch` tool for arbitrary
   paths, so I cloned the repo directly with `bash_tool` (both `github.com` and
   `raw.githubusercontent.com` are on the network allowlist) and extracted the
   `lwtools-4.24.tar.gz` already committed in the repo to get the actual C source
   for every helper function this translation depends on
   (`lw_expr_simplify_sortconstfirst`, `lw_expr_simplify_isliketerm`,
   `lw_expr_contains`, etc.) — not just the excerpt in `source.c`.

3. **Found the "existing" translation wasn't where the tracker said it was.**
   `existing.py` claimed the function was "not yet located" in `cocotools/lw_expr.py`,
   but it's actually implemented as `Expr._simplify_l` / `Expr._simplify_go`. I
   audited that real implementation against the true C, rather than trusting the
   stale tracker file.

4. **Built ground truth mechanically, not from memory.** I built lwtools-4.24 from
   source (`make`) to get a real `lwasm` binary for the existing fidelity harness,
   and separately wrote a small standalone C program linked directly against
   `liblw.a` that constructs hand-built `lw_expr_t` trees and calls the real
   `lw_expr_simplify()` on them — giving authoritative before/after output for
   every edge case, in the same postfix notation as `Expr.__repr__`, so results
   could be compared directly.

5. **Found and fixed three real bugs**, all confirmed by running the *unfixed*
   Python against the same ground-truth cases first (to prove each was a real,
   observable divergence, not just a theoretical risk) before fixing.

6. **Added 8 new regression tests** to `cocotools/test_fidelity.py`
   (`EXPRESSION_SIMPLIFY_TESTS`), each backed by the C-probe ground truth, and
   confirmed the full harness — 211 pre-existing tests + 8 new = **219 total** —
   passes with zero regressions.

7. **Rewrote `checklist.md` and `existing.py`** in the translation package to
   accurately document the checklist findings, interaction risks, mitigations,
   and current (corrected, verified) state of the translation.

## Bugs found and fixed

### 1. `OPER_COM` (bitwise complement `~`) was masked to 16 bits — it shouldn't be

`source.c` (lines 183–189):
```c
case lw_expr_oper_com:
    tr = ~(E -> operands -> p -> value);        // NO MASK
    break;
case lw_expr_oper_com8:
    tr = ~(E -> operands -> p -> value) & 0xff;  // masked
    break;
```

Only `COM8` masks. Plain `COM` computes a full, unmasked C `int` complement. A
prior version of the Python translation applied `& 0xFFFF` to *both* — likely
over-generalizing from the constant's own comment ("16-bit complement"), which
actually just describes when the *parser* chooses this operator (16-bit
expression-width mode), not how the operator computes its result.

**Verified against the real C:** `~5` simplifies to `-0x6` (plain negative int).
The unfixed Python instead produced `0xfffa` (65530) — a large *positive* number,
because Python's `&` on a negative int with a positive mask produces a positive
result via two's-complement promotion. This is a large, silent divergence in any
expression using unary `~`.

**Fix:** `_compute()` now returns `~vals[0]` unmasked for `OPER_COM`; `OPER_COM8`
is unchanged (`~vals[0] & 0xFF`).

### 2. `lw_expr_simplify_sortconstfirst` was called by the C but never implemented in Python at all

`grep` confirmed there was no implementation and no call site anywhere in the
codebase, despite `source.c` calling it directly:
```c
if (E -> value == lw_expr_oper_plus || E -> value == lw_expr_oper_times)
    lw_expr_simplify_sortconstfirst(E);
```

Its job: recursively move any literal-int operand of a `PLUS`/`TIMES` node to the
front of that node's operand list. Its absence didn't corrupt final *values* in
the common case (there's normally at most one literal-int operand left by this
point), but it does affect **operand order**, which matters because the very next
step (like-term coefficient extraction) specifically reads only the *first*
operand of a `TIMES` node to find its coefficient — relying on this sort having
already happened.

**Fix:** implemented `_sort_const_first()` faithfully from the real C (including
hand-tracing the linked-list splice algorithm's exact behavior when a list has
*multiple* int operands, to match a subtle "last one found ends up frontmost"
quirk), and call it in the correct position — after the `TIMES` zero-check,
before like-term collection.

### 3. Like-term collection silently dropped factors from multi-factor terms

The prior `_coef_of` / `_base_of` / `_is_like_term` helpers modeled a `TIMES`
node's non-constant part as a *single* "base" expression — the first non-int
operand found. This cannot represent a term with more than one non-constant
factor, e.g. `2*X*Y`.

**Verified against the real (unfixed) Python:** `2*X*Y + 3*X*Y` simplified to
`X*5` — the `Y` factor vanished from the result entirely, with no error. This is
exactly the kind of silent corruption the project brief warns about: a learner
using this to check hand-assembled expressions would have no way to tell their
own arithmetic was right and the tool was wrong.

**Fix:** rewrote `_is_like_term` to match `lw_expr_simplify_isliketerm` exactly —
handling the `TIMES`-vs-`TIMES` case (skip each side's leading run of int
operands, compare the remaining operand lists element-wise) and the
`TIMES`-vs-non-`TIMES` case (requires *exactly* 2 operands on the `TIMES` side)
separately, per the real C. The merge/combine logic was also rewritten to build
a full operand list rather than a single base expression.

**Verified fix against the real C:** `2*X*Y + 3*X*Y` → `5*X*Y`.

### 4. (Structural, lower severity) PLUS collapse logic ran too early, before sort-const-first / like-term collection

A prior version collapsed a `PLUS` node to a single operand or to literal `0`
immediately after integer-term collection — but in `source.c` that collapse is a
separate, *later* block (lines 449–522) that only runs after sort-const-first and
like-term collection. In practice the early exit only fired when 0 or 1
non-constant operands remained (in which case the skipped steps have nothing to
do anyway), so this wasn't independently confirmed to produce a wrong value on
its own — but combined with bug #3 (which needs sort-const-first to have already
run before it can work correctly) it was fragile, and it put the codebase one
future edit away from a real divergence.

**Fix:** reordered the whole tail of `_simplify_go` to match `source.c`'s actual
block sequence: cval-collect `PLUS` (no early return) → cval-collect `TIMES` →
`TIMES` zero-check → sort-const-first → like-term collection → dedicated `PLUS`
collapse block (now the *only* place a `PLUS` node collapses) → `TIMES`
int·(a+b) distribution (moved to be last, as in the real C, instead of sitting
in the middle of the function).

## New regression tests

Added `EXPRESSION_SIMPLIFY_TESTS` to `cocotools/test_fidelity.py` — 8 cases,
each calling `Expr.simplify()` directly on a hand-built expression tree and
comparing the resulting `repr()` against output recorded from the real C probe:

| Test | Expression | Expected result |
|---|---|---|
| `expr-com-unmasked` | `~5` | `-0x6` |
| `expr-com8-masked` | `~5` (8-bit) | `0xfa` |
| `expr-multi-factor-like-terms` | `2*X*Y + 3*X*Y` | `5*X*Y` |
| `expr-cancel-terms` | `X + -1*X` | `0x0` |
| `expr-prune-zero-keep-others` | `X + 0 + Y` | `X + Y` |
| `expr-collapse-single-after-zero` | `0 + X` | `X` |
| `expr-sort-const-first` | `X + 5` | `5 + X` |
| `expr-distribute-three-term` | `3*(X+Y+Z)` | `3*X + 3*Y + 3*Z` |

Run standalone: `python3 cocotools/test_fidelity.py -v` (runs alongside the
existing fidelity/behavioral/structural categories).

## Final verification

```
Results: 166 passed, 0 failed out of 166 tests            (fidelity, vs real lwasm binary)
Behavioral results: 27 passed, 0 failed out of 27 tests
Structural results: 18 passed, 0 failed out of 18 tests
Expression-simplify results: 8 passed, 0 failed out of 8 tests   (new)

Total: 219 passed, 0 failed
```

Zero regressions against the pre-existing 211 tests; all 8 new tests pass and
are independently confirmed against a from-source build of the real lwtools 4.24
C library (not against my own Python's prior behavior, and not from memory/
assumption about what "should" happen).

## Files in this package

| File | What changed |
|---|---|
| `lw_expr.py` | The actual bug fixes (`cocotools/lw_expr.py`) |
| `test_fidelity.py` | New `EXPRESSION_SIMPLIFY_TESTS` category + runner wiring (`cocotools/test_fidelity.py`) |
| `checklist.md` | Completed pre-translation checklist with all findings and verification method (`translation_packages/01_lw_expr_simplify_l/checklist.md`) |
| `existing.py` | Corrected status doc — was stale, now accurately describes the translation's location, bugs fixed, and test coverage (`translation_packages/01_lw_expr_simplify_l/existing.py`) |
| `SUMMARY.md` | This file |
