# SUMMARY: `insn_emit_indexed_aux` translation

## Scope note (read this first)

This session read the brief and the individual package files via
`web_fetch` (read-only). It deliberately did **not** clone the repo or
execute the prebuilt `lwasm` binary or `test_fidelity.py` from it, per a
standing rule against running unverified third-party executables/scripts.
As a consequence, `cocotools/insn_funcs.py` (the actual merge target) and
the real `cocotools/lwasm_core.py` / `lw_expr.py` classes were not
reachable — only files directly linked from `brief.md`'s Reference
section could be fetched (an attempt to fetch `insn_funcs.py` directly,
and a search for it, both came back empty).

Practical effect: the translation below is written to the documented
interface (per `DATA_STRUCTURE_AUDIT.md` and `TRANSLATION_GUIDE.md`) and
is ready to paste into `insn_funcs.py`, but it has been verified against
**stub collaborators that implement the documented semantics**, not
against the real classes or the real `test_fidelity.py` harness. That
last step (running it against the genuine 193-test suite) still needs
to happen, ideally by you, or by a future session with the file
actually available.

## What was read, in order

1. `brief.md` (fetched first, per your request)
2. `translation_packages/08_insn_emit_indexed_aux/source.c` — the C source, the spec
3. `translation_packages/08_insn_emit_indexed_aux/checklist.md` — empty template
4. `translation_packages/08_insn_emit_indexed_aux/existing.py` — empty; function not yet in `insn_funcs.py`
5. `cocotools/c_compat.py` — compat primitives (`c_uint8`, `c_5bit`, etc.)
6. `cocotools/DATA_STRUCTURE_AUDIT.md` — shared struct reference (`line_t` fields, sentinels)
7. `cocotools/TRANSLATION_GUIDE.md` — checklist methodology and known-safe-pattern catalog
8. `cocotools/insn_funcs.py` — **not reachable** (see scope note above)

## Pre-translation checklist

Completed in full; see `checklist.md` in this package. Highlights:

- **Integer width:** the one bitmask in the function (`offs & 0x1f`)
  matches TRANSLATION_GUIDE's documented safe pattern — Python's `&` on
  a negative int uses two's complement exactly like C, confirmed by
  hand-checking `-16 & 0x1f` and `-1 & 0x1f`. No `c_5bit`/`c_uint8`
  wrapper needed.
- **Division/modulo, `char **p`, goto, char signedness, bitwise
  complement, register lookup:** none present in this function.
- **Argument evaluation order:** safe — no combined-argument-list side
  effects (the two `lwasm_emitop` calls are separate statements).

## Divergences found between `existing.py` and the C source

None — `existing.py` was empty (the function has not yet been added to
`insn_funcs.py`). This is a new addition, not a bug fix.

## Interaction risks identified (see checklist.md for full detail)

1. **The C has two independent top-level `if` statements**, not one
   3-way `if/elif/elif`: `if (lint==1) {...}` stands alone, followed
   separately by `if (lint==3) {...} else if (lint==2 ...) {...}`.
   These happen to be mutually exclusive in practice (`lint` holds one
   value at a time), but the translation preserves the exact two-block
   structure rather than collapsing it into one chain, so the Python
   stays an honest mirror of the C if it's ever patched later.
2. **`CURPRAGMA(l, PRAGMA_OPERANDSIZE)`** is translated as a call to a
   `curpragma(l, flag)` helper, assumed to already exist in cocotools
   rather than reimplemented here (per DATA_STRUCTURE_AUDIT's note that
   `pragmas` is inherited per-line from assembler state).
3. **`l.pb` is assumed already resolved** to a concrete byte value by
   the time this emit-phase function runs — matches the C, which has
   no such guard either.
4. **The `W_OPERAND_SIZE` warning path calls the same
   `lwasm_register_error` function** as the hard-error paths, matching
   the C exactly (lwasm registers warnings and errors through one
   function) — flagged so it isn't "corrected" into a separate
   register-warning call later.

## Bugs fixed

None — no existing implementation to have a bug.

## Test cases added (29 assertions across 11 scenarios)

All in `test_insn_emit_indexed_aux.py`, run against stub collaborators
(see scope note):

1. `lint==1`, in-range value → no error, opcode+pb+offset byte emitted, cycle_adj set
2. `lint==1`, out-of-range value → `E_BYTE_OVERFLOW`
3. `lint==1`, boundary values -128/127/128/-129 → correct pass/fail at each edge
4. `lint==3`, offset in -16..15 → postbyte 5-bit-encoded, `lint` cleared to 0, no trailing bytes
5. `lint==3`, offset ≥ 0xFFF0 (sign-extended-as-unsigned view) → same success path
6. `lint==3`, offset outside both allowed ranges → `E_BYTE_OVERFLOW`, `lint` **not** cleared, so a 3-byte trailing expression still gets emitted (matches C control flow)
7. `lint==3`, expression not yet resolved to int type → `E_EXPRESSION_NOT_RESOLVED`
8. `lint==2`, pragma set, pb not excluded, small offset → `W_OPERAND_SIZE` warning, `lint` untouched, 2-byte trailing expression still emitted
9. `lint==2`, pragma set, but `pb == 0x9F` or `pb == 0xAF` (extended-indirect / extended exclusions) → no check performed at all
10. `lint==2`, pragma not set → no check regardless of offset size
11. `lint==0` → neither block runs, no trailing bytes
12. Regression guard: `lint==1` branch's overflow check never touches `l.pb` (confirms the two-independent-`if` structure didn't get accidentally merged)

## Final test counts

**29 passed, 0 failed** — against the stub-collaborator harness described
in the scope note. **Not yet run against the real `test_fidelity.py` /
the real 193-test suite**, since that requires the actual
`cocotools/insn_funcs.py` and its real dependencies, which weren't
reachable this session.

## Recommended next step

Paste `insn_emit_indexed_aux.py`'s function body into
`cocotools/insn_funcs.py` at the appropriate location, import it against
the real `curpragma`/`lw_expr`/`instab`/error-code names (adjusting names
if they differ from what's assumed here), then run the real
`python cocotools/test_fidelity.py` to confirm all 193 existing tests
still pass and this function's behavior matches lwasm 4.24 on real
assembly input.
