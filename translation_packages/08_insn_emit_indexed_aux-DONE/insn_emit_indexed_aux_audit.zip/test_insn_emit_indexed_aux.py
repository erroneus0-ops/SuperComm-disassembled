"""
test_insn_emit_indexed_aux.py

Self-contained fidelity tests for insn_emit_indexed_aux.py.

IMPORTANT SCOPE NOTE: I do not have access to the real cocotools
collaborator implementations (lw_expr, AsmState, the real Line class,
the real instab table, or the real error-code constants) because
cocotools/insn_funcs.py could not be fetched (only files explicitly
linked from brief.md's Reference section were reachable). These tests
therefore use minimal stand-in stubs that implement exactly the
documented behavior from DATA_STRUCTURE_AUDIT.md and TRANSLATION_GUIDE.md
(l.lint/l.pb/l.insn semantics, error-code registration, etc).

These are NOT a replacement for running the project's real
`test_fidelity.py` against the real cocotools classes -- that step
still needs to happen once this function is merged into
cocotools/insn_funcs.py, with the real collaborators instead of these
stubs. What these tests verify is the *branch logic* of the translation
in isolation: given the documented semantics of each collaborator, does
insn_emit_indexed_aux make the same decisions the C source makes.
"""

import importlib.util
import sys
import types


# ---------------------------------------------------------------------------
# Minimal stub collaborators (see module docstring -- these stand in for
# real cocotools/lwasm_core.py, lw_expr.py, etc, which weren't reachable)
# ---------------------------------------------------------------------------

E_BYTE_OVERFLOW = "E_BYTE_OVERFLOW"
E_EXPRESSION_NOT_RESOLVED = "E_EXPRESSION_NOT_RESOLVED"
W_OPERAND_SIZE = "W_OPERAND_SIZE"
PRAGMA_OPERANDSIZE = 0x01
lw_expr_type_int = "int"


class Expr:
    """Stub for lw_expr_t. resolved=False models an expression that
    hasn't settled to a plain integer yet (mirrors lw_expr_istype
    returning false for a non-int-typed node in the real expr tree)."""

    def __init__(self, value, resolved=True):
        self.value = value
        self.resolved = resolved


def lw_expr_intval(e):
    return e.value


def lw_expr_istype(e, t):
    assert t == lw_expr_type_int
    return e.resolved


class Line:
    """Stub for line_t / Line, fields per DATA_STRUCTURE_AUDIT.md."""

    def __init__(self, lint, pb, insn=0, pragmas=0):
        self.lint = lint
        self.pb = pb
        self.insn = insn
        self.pragmas = pragmas
        self.cycle_adj = 0
        self.output = bytearray()
        self._exprs = []
        self.errors = []

    def push_expr(self, e):
        self._exprs.append(e)


class AsmState:
    def __init__(self):
        self.errorcount = 0
        self.warningcount = 0


class InsnEntry:
    def __init__(self, op0):
        self.ops = [op0]


# global fakes the function under test expects as module-level names
instab = {0: InsnEntry(0x86), 1: InsnEntry(0xA0)}


def lwasm_fetch_expr(l, n):
    return l._exprs[n]


def lwasm_register_error(as_, l, code):
    l.errors.append(code)
    if code == W_OPERAND_SIZE:
        as_.warningcount += 1
    else:
        as_.errorcount += 1


def lwasm_emitop(l, byte):
    l.output.append(byte & 0xFF)


def lwasm_emitexpr(l, e, width):
    v = e.value & ((1 << (8 * width)) - 1)
    l.output.extend(v.to_bytes(width, "big"))


def curpragma(l, flag):
    return bool(l.pragmas & flag)


# ---------------------------------------------------------------------------
# Load insn_emit_indexed_aux.py and inject the stub collaborators as its
# module globals (the translated function references them as free
# module-level names, matching the C file's use of file-scope helpers).
# ---------------------------------------------------------------------------

def load_function_under_test():
    spec = importlib.util.spec_from_file_location(
        "insn_emit_indexed_aux_mod", "/home/claude/work/insn_emit_indexed_aux.py"
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    injected = dict(
        lwasm_fetch_expr=lwasm_fetch_expr,
        lw_expr_intval=lw_expr_intval,
        lw_expr_istype=lw_expr_istype,
        lw_expr_type_int=lw_expr_type_int,
        lwasm_register_error=lwasm_register_error,
        lwasm_emitop=lwasm_emitop,
        lwasm_emitexpr=lwasm_emitexpr,
        curpragma=curpragma,
        instab=instab,
        E_BYTE_OVERFLOW=E_BYTE_OVERFLOW,
        E_EXPRESSION_NOT_RESOLVED=E_EXPRESSION_NOT_RESOLVED,
        W_OPERAND_SIZE=W_OPERAND_SIZE,
        PRAGMA_OPERANDSIZE=PRAGMA_OPERANDSIZE,
    )
    mod.__dict__.update(injected)

    def lwasm_cycle_calc_ind(l):
        return 42  # arbitrary sentinel -- just verifying it gets called & stored

    mod.__dict__["lwasm_cycle_calc_ind"] = lwasm_cycle_calc_ind

    return mod.insn_emit_indexed_aux


insn_emit_indexed_aux = load_function_under_test()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

results = []


def check(name, cond):
    results.append((name, cond))
    print(("PASS" if cond else "FAIL"), "-", name)


# 1. lint==1, in-range 8-bit value -> no error
as_ = AsmState()
l = Line(lint=1, pb=0x84, insn=0)
l.push_expr(Expr(100))
insn_emit_indexed_aux(as_, l)
check("lint==1 in-range: no error", l.errors == [])
# lint==1 branch never clears l.lint -- it stays 1 (>0), so the trailing
# `if l.lint > 0` block fires and appends the 1-byte offset after opcode+pb.
check("lint==1 in-range: opcode+pb+1byte-offset emitted", list(l.output) == [0x86, 0x84, 100])
check("lint==1 in-range: cycle_adj set", l.cycle_adj == 42)

# 2. lint==1, out-of-range value -> E_BYTE_OVERFLOW
as_ = AsmState()
l = Line(lint=1, pb=0x84, insn=0)
l.push_expr(Expr(200))
insn_emit_indexed_aux(as_, l)
check("lint==1 out-of-range: E_BYTE_OVERFLOW", l.errors == [E_BYTE_OVERFLOW])

# 2b. lint==1, boundary values -128 and 127 exactly -> no error
as_ = AsmState()
l = Line(lint=1, pb=0x84, insn=0)
l.push_expr(Expr(-128))
insn_emit_indexed_aux(as_, l)
check("lint==1 boundary -128: no error", l.errors == [])

as_ = AsmState()
l = Line(lint=1, pb=0x84, insn=0)
l.push_expr(Expr(127))
insn_emit_indexed_aux(as_, l)
check("lint==1 boundary 127: no error", l.errors == [])

as_ = AsmState()
l = Line(lint=1, pb=0x84, insn=0)
l.push_expr(Expr(128))
insn_emit_indexed_aux(as_, l)
check("lint==1 boundary 128: E_BYTE_OVERFLOW", l.errors == [E_BYTE_OVERFLOW])

as_ = AsmState()
l = Line(lint=1, pb=0x84, insn=0)
l.push_expr(Expr(-129))
insn_emit_indexed_aux(as_, l)
check("lint==1 boundary -129: E_BYTE_OVERFLOW", l.errors == [E_BYTE_OVERFLOW])

# 3. lint==3, offs in -16..15 (5-bit direct) -> pb updated, lint cleared
as_ = AsmState()
l = Line(lint=3, pb=0x00, insn=0)
l.push_expr(Expr(-5))
insn_emit_indexed_aux(as_, l)
check("lint==3 -5: pb encodes 5-bit offset", (l.pb & 0x1F) == (-5 & 0x1F))
check("lint==3 -5: lint cleared to 0", l.lint == 0)
check("lint==3 -5: no error", l.errors == [])
# emitexpr should NOT run since lint was zeroed before the final `if l.lint > 0`
check("lint==3 -5: no trailing expr bytes", list(l.output) == [0x86, l.pb])

# 4. lint==3, offs >= 0xFFF0 (sign-extended-as-unsigned view of -16..-1)
as_ = AsmState()
l = Line(lint=3, pb=0x00, insn=0)
l.push_expr(Expr(0xFFFB))  # equivalent to -5 in 16-bit unsigned form
insn_emit_indexed_aux(as_, l)
check("lint==3 0xFFFB: pb encodes correctly", (l.pb & 0x1F) == (0xFFFB & 0x1F))
check("lint==3 0xFFFB: lint cleared", l.lint == 0)
check("lint==3 0xFFFB: no error", l.errors == [])

# 5. lint==3, offs out of both allowed ranges -> E_BYTE_OVERFLOW, lint untouched
as_ = AsmState()
l = Line(lint=3, pb=0x00, insn=0)
l.push_expr(Expr(1000))
insn_emit_indexed_aux(as_, l)
check("lint==3 out-of-range: E_BYTE_OVERFLOW", l.errors == [E_BYTE_OVERFLOW])
check("lint==3 out-of-range: lint NOT cleared (stays 3)", l.lint == 3)
# lint stayed 3 (>0) so the trailing emitexpr(l, e, 3) block should still fire
check("lint==3 out-of-range: trailing 3-byte expr emitted", len(l.output) == 2 + 3)

# 6. lint==3, expression not yet resolved to int type -> E_EXPRESSION_NOT_RESOLVED
as_ = AsmState()
l = Line(lint=3, pb=0x00, insn=0)
l.push_expr(Expr(0, resolved=False))
insn_emit_indexed_aux(as_, l)
check("lint==3 unresolved: E_EXPRESSION_NOT_RESOLVED", l.errors == [E_EXPRESSION_NOT_RESOLVED])
check("lint==3 unresolved: lint untouched", l.lint == 3)

# 7. lint==2, PRAGMA_OPERANDSIZE set, pb not in exclusion set, offs in 8-bit range -> warning
as_ = AsmState()
l = Line(lint=2, pb=0x89, insn=1, pragmas=PRAGMA_OPERANDSIZE)
l.push_expr(Expr(50))
insn_emit_indexed_aux(as_, l)
check("lint==2 warn-eligible small offset: W_OPERAND_SIZE", l.errors == [W_OPERAND_SIZE])
check("lint==2 warn path: lint untouched (still 2)", l.lint == 2)
# lint stayed 2 (>0), so trailing 2-byte expr should still be emitted
check("lint==2 warn path: trailing 2-byte expr emitted", len(l.output) == 2 + 2)

# 8. lint==2, PRAGMA_OPERANDSIZE set, but pb IS 0x9f (extended indirect) -> no check at all
as_ = AsmState()
l = Line(lint=2, pb=0x9F, insn=1, pragmas=PRAGMA_OPERANDSIZE)
l.push_expr(Expr(50))
insn_emit_indexed_aux(as_, l)
check("lint==2 excluded pb=0x9F: no warning", l.errors == [])

# 8b. same but pb == 0xAF
as_ = AsmState()
l = Line(lint=2, pb=0xAF, insn=1, pragmas=PRAGMA_OPERANDSIZE)
l.push_expr(Expr(50))
insn_emit_indexed_aux(as_, l)
check("lint==2 excluded pb=0xAF: no warning", l.errors == [])

# 9. lint==2, pragma NOT set -> no check performed regardless of offset size
as_ = AsmState()
l = Line(lint=2, pb=0x89, insn=1, pragmas=0)
l.push_expr(Expr(50))
insn_emit_indexed_aux(as_, l)
check("lint==2 no pragma: no warning", l.errors == [])

# 10. lint==0 (no offset bytes at all) -> neither block runs, no trailing expr emit
as_ = AsmState()
l = Line(lint=0, pb=0x84, insn=0)
insn_emit_indexed_aux(as_, l)
check("lint==0: no error", l.errors == [])
check("lint==0: only opcode+pb emitted, no trailing bytes", list(l.output) == [0x86, 0x84])

# 11. Two-independent-if check: lint==1 branch runs its size check even though
#     it never touches pb/lint -- confirm it does NOT fall into the lint==3
#     path's pb-encoding side effect (regression guard for interaction risk #1)
as_ = AsmState()
l = Line(lint=1, pb=0x77, insn=0)
l.push_expr(Expr(10))
insn_emit_indexed_aux(as_, l)
check("lint==1: pb left untouched by indexed-offset encoding", l.pb == 0x77)


print()
failed = [name for name, ok in results if not ok]
print(f"{len(results) - len(failed)} passed, {len(failed)} failed")
if failed:
    print("FAILED:", failed)
    sys.exit(1)
