# Pre-Translation Checklist: `insn_emit_indexed_aux`

Metrics: 64 lines, 10 branches, 0 gotos

## 1. Integer width at assignment sites
Check every assignment destination type.
Bit mask operations found (may need `c_uint8` etc.):
  - `l -> pb |= offs & 0x1f;`

**Finding:** `offs & 0x1f` matches the "Known Safe Pattern" documented in
TRANSLATION_GUIDE.md ("`v & 0x1F` (5-bit mask) -- Python `&` uses two's
complement on negatives -- matches C"). `offs` may be negative (e.g. -16),
and Python's `&` on a negative int operates on the two's-complement
representation exactly like C's `&` on a signed int, so `-16 & 0x1f == 0x10`
in both languages. No `c_uint8`/`c_5bit` wrapper needed -- confirmed by
hand-checking `-16 & 0x1f` and `-1 & 0x1f` in both languages.

No other assignment in this function targets a fixed-width C type; `i`,
`offs` are plain `int` used only for comparison and the one masked
assignment above.

## 2. Division / modulo
Not found.

## 3. char ** pointer parameters
Not found.

## 4. goto statements
  None. (0 gotos, matches function metrics.)

## 5. char signedness
Low risk. Not applicable -- function does no character classification.

## 6. Argument evaluation order
Checked `(*p)++`-style patterns in call position: none present. The two
`lwasm_emitop()` calls are separate statements (not combined into one
call's argument list), so Python's guaranteed left-to-right evaluation
introduces no divergence -- each call fully completes before the next
begins, in both languages.

## 7. Integer promotion
Checked compound expressions:
  - `offs & 0x1f` -- safe pattern, see #1.
  - `offs >= -16 && offs <= 15) || offs >= 0xFFF0` -- both operands are
    plain `int` on both sides (no fixed-width C type is declared for
    `offs` itself), so no truncation mask is needed at the comparison.
    This is a magic-constant range check (a 16-bit sign-extended view of
    -16..-1 expressed as unsigned 0xFFF0..0xFFFF), translated verbatim.
  - Same pattern for the 8-bit warning check (`0xFF80`).

## 8. Bitwise complement
Not found.

## 9. Register lookup advancement
N/A.

## Character classification
N/A -- no character/string parsing in this function.

## Interaction risks identified

1. **Two independent top-level `if` statements, not one `if/elif` chain.**
   The C source is:
   ```c
   if (l->lint == 1) { ... }          // independent check

   if (l->lint == 3) { ... }          // second, separate if
   else if (l->lint == 2 && ...) { ... }
   ```
   The `lint == 1` block is NOT part of the same conditional chain as the
   `lint == 3` / `lint == 2` pair -- it's syntactically a separate `if`.
   Because `lint` can only hold one value at a time these are mutually
   exclusive in practice, but a translator skimming the function could
   misread this as a 3-way `if/elif/elif` and accidentally merge the first
   block into the chain (harmless here given mutual exclusivity, but it
   would misrepresent the source and could bite a future maintainer if
   the C is ever patched to allow lint==1 to coexist with a later check).
   **Mitigation:** preserve the exact two-statement structure in Python
   (a standalone `if l.lint == 1:` followed by a separate `if/elif`).

2. **`CURPRAGMA` macro semantics.** `CURPRAGMA(l, PRAGMA_OPERANDSIZE)`
   reads a pragma flag that DATA_STRUCTURE_AUDIT.md documents as
   inherited per-line from assembler state (`l.pragmas`, itself
   initialized from `as_.pragmas`). Translation assumes a helper
   `curpragma(l, flag)` already exists elsewhere in cocotools (per
   TRANSLATION_GUIDE's own references to `CURPRAGMA` as pre-existing
   macro-equivalent machinery) and is imported rather than reimplemented
   here, to avoid duplicating pragma-resolution logic in two places.

3. **`l.pb` assumed already a concrete byte value, not the `-1`
   "undetermined" sentinel.** DATA_STRUCTURE_AUDIT.md's field-usage map
   lists `pb` as "written by parse, read by resolve/emit" -- by the time
   `insn_emit_indexed_aux` runs (an emit-phase function), the postbyte
   must already be resolved. The function does not itself guard against
   `pb == -1`; this matches the C, which also performs no such guard.

4. **`W_OPERAND_SIZE` branch calls the same `lwasm_register_error`
   function used for the hard-error cases**, even though it is
   conceptually a warning. This is faithful to the C source (single
   function registers both errors and warnings by code), not a bug --
   flagging here so a future reader doesn't "fix" it into a separate
   `register_warning` call that doesn't match lwasm's actual behavior.

## Mitigations applied

- Preserved the two-independent-`if` structure exactly (risk #1).
- Imported (not reimplemented) `curpragma` for the `CURPRAGMA` macro
  (risk #2).
- No sentinel guard added for `l.pb` (risk #3) -- matches C.
- Single `lwasm_register_error` call used for both the error and the
  warning code paths, matching C exactly (risk #4).
- No `c_uint8`/`c_5bit` wrapper added around `offs & 0x1f` -- confirmed
  safe per TRANSLATION_GUIDE's documented safe-pattern list (item #1).
