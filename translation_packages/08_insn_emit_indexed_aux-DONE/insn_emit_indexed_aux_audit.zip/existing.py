# Current Python translation of insn_emit_indexed_aux
# cocotools/insn_funcs.py
#
# Updated 2026-07-18: translation drafted this session. See
# insn_emit_indexed_aux.py and SUMMARY.md in this package for the full
# function body, checklist, and test results. Not yet merged into the
# real cocotools/insn_funcs.py (that file wasn't reachable this session
# -- see SUMMARY.md scope note) and not yet run against the real
# test_fidelity.py harness.

# ---------------------------------------------------------------------------
# FUNCTION: insn_emit_indexed_aux
# SOURCE:   lwtools-4.24/lwasm/insn_indexed.c lines 766-829
# TRANSLATED: 2026-07-18
#
# See insn_emit_indexed_aux.py in this package for the full docstring,
# checklist summary, and assumed-collaborator interface.
# ---------------------------------------------------------------------------


def insn_emit_indexed_aux(as_, l):
    if l.lint == 1:
        e = lwasm_fetch_expr(l, 0)
        i = lw_expr_intval(e)
        if i < -128 or i > 127:
            lwasm_register_error(as_, l, E_BYTE_OVERFLOW)

    # exclude expr,W since that can only be 16 bits
    if l.lint == 3:
        e = lwasm_fetch_expr(l, 0)
        if lw_expr_istype(e, lw_expr_type_int):
            offs = lw_expr_intval(e)
            if (offs >= -16 and offs <= 15) or offs >= 0xFFF0:
                l.pb |= offs & 0x1f
                l.lint = 0
            else:
                lwasm_register_error(as_, l, E_BYTE_OVERFLOW)
        else:
            lwasm_register_error(as_, l, E_EXPRESSION_NOT_RESOLVED)
    # note that extended indirect (post byte 0x9f) can only be 16 bits
    elif l.lint == 2 and curpragma(l, PRAGMA_OPERANDSIZE) and (
        l.pb != 0xAF and l.pb != 0xB0 and l.pb != 0x9f
    ):
        e = lwasm_fetch_expr(l, 0)
        if lw_expr_istype(e, lw_expr_type_int):
            offs = lw_expr_intval(e)
            if (offs >= -128 and offs <= 127) or offs >= 0xFF80:
                lwasm_register_error(as_, l, W_OPERAND_SIZE)

    lwasm_emitop(l, instab[l.insn].ops[0])
    lwasm_emitop(l, l.pb)

    l.cycle_adj = lwasm_cycle_calc_ind(l)

    if l.lint > 0:
        e = lwasm_fetch_expr(l, 0)
        lwasm_emitexpr(l, e, l.lint)
