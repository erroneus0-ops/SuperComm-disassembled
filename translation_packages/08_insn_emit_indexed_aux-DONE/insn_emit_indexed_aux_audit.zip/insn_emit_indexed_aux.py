# ---------------------------------------------------------------------------
# FUNCTION: insn_emit_indexed_aux
# SOURCE:   lwtools-4.24/lwasm/insn_indexed.c lines 766-829
# TRANSLATED: 2026-07-18
#
# Pre-translation checklist results:
#   - Integer width: `offs & 0x1f` is a documented safe pattern
#     (two's-complement `&` behaves identically in C and Python on
#     negative operands) -- no c_uint8/c_5bit wrapper needed.
#   - Division/modulo: none.
#   - char **p: N/A.
#   - goto: none (0 in this function).
#   - char signedness: N/A.
#   - Argument order: safe -- no combined-argument-list side effects.
#   - Promotion: safe -- no fixed-width C destination types beyond `pb`.
#   - Complement: none.
#   - lookupreg: N/A.
#
# Interaction risks:
#   1. The C source has `if (lint==1) {...}` as a SEPARATE top-level
#      statement from the `if (lint==3) {...} else if (lint==2 ...)`
#      chain that follows -- not one 3-way elif. Preserved exactly.
#   2. CURPRAGMA(l, PRAGMA_OPERANDSIZE) assumed provided by existing
#      cocotools pragma-resolution code (curpragma helper), not
#      reimplemented here.
#   3. l.pb is assumed already resolved to a concrete postbyte value
#      by this point (emit phase) -- matches C, which has no guard.
#   4. The W_OPERAND_SIZE warning path calls the same error-registration
#      function as the hard-error paths, faithfully matching the C
#      (lwasm registers warnings and errors through one function).
#
# Mitigations applied: see checklist.md item-by-item; no numeric
# truncation wrapper was needed anywhere in this function.
# ---------------------------------------------------------------------------


def insn_emit_indexed_aux(as_, l):
    """Emit the machine code for an already-parsed indexed-addressing
    instruction operand, resolving any deferred offset-size checks that
    could not be settled until symbol values were known.

    Faithful translation of lwtools-4.24 lwasm/insn_indexed.c lines
    766-829 (`insn_emit_indexed_aux`). Same bytes, same errors, same
    internal state as the C original -- see brief.md for why fidelity
    (not idiomatic style) is the requirement for this codebase.

    Expected collaborators (assumed to already exist elsewhere in
    cocotools, consistent with DATA_STRUCTURE_AUDIT.md / TRANSLATION_GUIDE.md):
      lwasm_fetch_expr(l, n)      -- fetch the nth saved expression for line l
      lw_expr_intval(e)           -- resolve expression e to a plain int
      lw_expr_istype(e, t)        -- check expression e's resolved type
      lw_expr_type_int             -- the "resolved integer" type tag
      lwasm_register_error(as_, l, code) -- register an error/warning by code
      lwasm_emitop(l, byte)        -- append one byte to l's output
      lwasm_emitexpr(l, e, width)  -- append a width-byte expression value
      lwasm_cycle_calc_ind(l)      -- compute indexed-mode cycle adjustment
      curpragma(l, flag)           -- CURPRAGMA(l, flag) equivalent
      instab                       -- global instruction table
      E_BYTE_OVERFLOW, E_EXPRESSION_NOT_RESOLVED, W_OPERAND_SIZE -- error codes
      PRAGMA_OPERANDSIZE            -- pragma flag constant
    """
    # NOTE: this is a separate `if`, not part of the if/elif chain below --
    # see checklist.md interaction risk #1.
    if l.lint == 1:
        e = lwasm_fetch_expr(l, 0)
        i = lw_expr_intval(e)
        if i < -128 or i > 127:
            lwasm_register_error(as_, l, E_BYTE_OVERFLOW)

    # exclude expr,W since that can only be 16 bits
    if l.lint == 3:
        e = lwasm_fetch_expr(l, 0)
        if lw_expr_istype(e, lw_expr_type_int):
            offs = lw_expr_intval(e)
            if (offs >= -16 and offs <= 15) or offs >= 0xFFF0:
                l.pb |= offs & 0x1f
                l.lint = 0
            else:
                lwasm_register_error(as_, l, E_BYTE_OVERFLOW)
        else:
            lwasm_register_error(as_, l, E_EXPRESSION_NOT_RESOLVED)
    # note that extended indirect (post byte 0x9f) can only be 16 bits
    elif l.lint == 2 and curpragma(l, PRAGMA_OPERANDSIZE) and (
        l.pb != 0xAF and l.pb != 0xB0 and l.pb != 0x9f
    ):
        e = lwasm_fetch_expr(l, 0)
        if lw_expr_istype(e, lw_expr_type_int):
            offs = lw_expr_intval(e)
            if (offs >= -128 and offs <= 127) or offs >= 0xFF80:
                lwasm_register_error(as_, l, W_OPERAND_SIZE)

    lwasm_emitop(l, instab[l.insn].ops[0])
    lwasm_emitop(l, l.pb)

    l.cycle_adj = lwasm_cycle_calc_ind(l)

    if l.lint > 0:
        e = lwasm_fetch_expr(l, 0)
        lwasm_emitexpr(l, e, l.lint)
