# SUMMARY: `insn_emit_indexed_aux` translation

## Session history (important for context)

This ran in two passes. In the first pass, `cocotools/insn_funcs.py`
wasn't reachable (only files linked directly from `brief.md` were), so
that pass produced a translation verified against guessed stub
collaborators (free functions like `lwasm_fetch_expr(l, 0)`). You then
pasted the real `insn_funcs.py` in chat. **Everything below is the
revised, second-pass work against the real file** — the first pass's
zip should be considered superseded; the interface it assumed
(`lwasm_fetch_expr`, `lw_expr_intval`, etc. as free functions) does not
match the real codebase (which uses methods: `cl.fetch_expr(0)`,
`e.intval()`, `as_.register_error(cl, code)`, etc.).

## What was read, in order

1. `brief.md`
2. `source.c` (`insn_indexed.c` lines 766-829 — the spec for this package)
3. `checklist.md` (empty template)
4. `existing.py` (empty — function not yet in `insn_funcs.py`)
5. `c_compat.py`
6. `DATA_STRUCTURE_AUDIT.md`
7. `TRANSLATION_GUIDE.md`
8. `cocotools/insn_funcs.py` — **pasted directly by you** in this
   conversation (all attempts to fetch it via URL failed — see below).

## Note on repo access

I still could not reach `cocotools/insn_funcs.py` through my own tools
this session: the raw file URL isn't fetchable until it's appeared in a
prior search/fetch result, it hasn't been indexed by web search, and
GitHub's tree/blob pages block automated access via robots.txt. Thank
you for pasting it directly — that's what made the real analysis below
possible. I did not clone the repository or execute anything from it.

## The actual finding: this logic already existed, duplicated and buggy

The real `insn_funcs.py` turned out to already contain **two** hand-rolled
partial reimplementations of the exact logic `insn_emit_indexed_aux`
encodes — they just hadn't been checked against the C source line by
line before. Once I had the real file, comparing it against `source.c`
directly (rather than against my own guessed interface) surfaced real
bugs, which is exactly the "existing.py is SUSPECT, the C is the truth"
process the project's `TRANSLATION_GUIDE.md` describes.

### `insn_emit_indexed` (the LEA-style emit function) — 4 bugs found

Old body:
```python
def insn_emit_indexed(as_, cl):
    ops = _ops(cl)
    cl.emitop(ops[0])
    e = cl.fetch_expr(0)
    if cl.lint == 3:
        if e and e.istype(TYPE_INT):
            offs = e.intval()
            if (offs >= -16 and offs <= 15) or offs >= 0xFFF0:
                cl.pb = (cl.pb & 0xE0) | (offs & 0x1F)
                cl.lint = 0
            else:
                cl.as_.register_error(cl, E_BYTE_OVERFLOW)
    cl.emit(cl.pb)
    if cl.lint == 1 and e:
        cl.emitexpr(e, 1)
    elif cl.lint == 2 and e:
        cl.emitexpr(e, 2)
```

Bugs, each checked against `source.c` lines 766-829:

1. **No `lint==1` byte-overflow check at all.** The C's first block
   (`if (l->lint == 1) { ... if (i < -128 || i > 127) register_error(...) }`)
   has no counterpart here — an out-of-range 8-bit indexed offset
   assembles silently with no error.
2. **Missing `else` on the lint==3 int-type check.** C registers
   `E_EXPRESSION_NOT_RESOLVED` when the expression hasn't resolved to an
   int; this version does nothing in that case *and* leaves `cl.lint`
   at `3`, which then matches neither the trailing `if cl.lint==1` nor
   `elif cl.lint==2` — so the offset bytes are **silently dropped from
   the output entirely**, with zero error indication. Confirmed by test
   (`test_insn_emit_indexed_aux_v2.py`, "insn_emit_indexed (fixed):
   E_EXPRESSION_NOT_RESOLVED now raised" — this test fails against the
   *old* body and passes against the *new* one).
3. **No `W_OPERAND_SIZE` warning path** (`lint==2` +
   `PRAGMA_OPERANDSIZE` + postbyte exclusion) at all.
4. **`cl.cycle_adj` never assigned.**

New body: delegates to the new `insn_emit_indexed_aux(as_, cl)`, which
fixes all four.

### `_insn_emit_gen_aux`'s `cl.lint2 == 1` branch — related gaps, NOT fixed

This function has a *different* subset of the same gaps (no
`W_OPERAND_SIZE` check, no `cycle_adj`), but it is **not** the same
call site: it emits `ops[cl.lint2]` (mode-selected DIR/IDX/EXT opcode)
rather than the fixed `ops[0]` that `insn_emit_indexed_aux` and
`insn_emit_indexed` both use. That means it's the Python counterpart of
a *different* C function (presumably in `insn_gen.c`, not
`insn_indexed.c`), which wasn't supplied in this package. I flagged this
in the code (see the new docstring note on `_insn_emit_gen_aux`) but did
**not** modify it — fixing it faithfully needs `insn_gen.c`'s actual
source, the same way this package needed `insn_indexed.c`'s.

## Missing dependency: `lwasm_cycle_calc_ind`

`l->cycle_adj = lwasm_cycle_calc_ind(l)` has no translated counterpart
anywhere in the file (there's an analogous `_cycle_calc_rlist` for a
different instruction family, but nothing for indexed mode). This is
presumably in `cycle.c`, which wasn't part of this package. Rather than
guess at a real per-mode cycle table, I added a stub `_cycle_calc_ind`
that returns `0` — this is a **strict improvement over the current
silent behavior** (cl.cycle_adj is currently never assigned at all by
either call site, so it already silently defaults to 0), not a
regression, and it's marked with a `TODO` for a future package once
`cycle.c` is available.

## Pre-translation checklist

Completed in full in `checklist.md`, including the corrected real
interface mapping (C call → actual cocotools call) discovered once
`insn_funcs.py` became available. Key correction from the first pass:
`emitop` and `emit` are two *different* methods in this codebase
(`emitop` for the instruction opcode, `emit` for a single raw byte) —
my first-pass guess had them as one function.

## Interaction risks identified

1. The C's two independent top-level `if` statements (`if lint==1`
   stands alone; `if lint==3 / elif lint==2` is separate) — preserved
   exactly, not collapsed into one elif chain.
2. `_cycle_calc_ind` gap — see above.
3. The pre-existing duplication/bugs in `insn_emit_indexed` — see above.

## Test cases (35 assertions, real interface, all passing)

`test_insn_emit_indexed_aux_v2.py`, run against the real `insn_funcs.py`
plus minimal stand-ins for its dependencies (`lw_expr.py`,
`lwasm_types.py`, `lwasm_core.py`, `instab.py` — these four support
files weren't part of what you pasted, so they're stubs built strictly
to the interface `insn_funcs.py` itself demonstrates, e.g. `e.istype()`,
`e.intval()`, `as_.register_error()`, `curpragma()`).

Covers all `insn_emit_indexed_aux` branches (lint 0/1/2/3, boundary
values, both PRAGMA_OPERANDSIZE-warning exclusions, unresolved
expressions) plus three targeted regression tests against
`insn_emit_indexed` confirming the three previously-silent bugs are
now caught:
- out-of-range 8-bit offset now raises `E_BYTE_OVERFLOW`
- unresolved lint==3 expression now raises `E_EXPRESSION_NOT_RESOLVED`
  (previously silently dropped bytes with no error)
- `cycle_adj` is now assigned (via the stub)

**Result: 35 passed, 0 failed.**

## Still not done (honest scope boundary)

- Not run against the real `test_fidelity.py` / the real 193-test suite
  — that needs the actual `lw_expr.py`, `lwasm_types.py`,
  `lwasm_core.py`, `instab.py`, which weren't pasted this session.
- `_insn_emit_gen_aux`'s analogous gaps flagged but not fixed (needs
  `insn_gen.c`).
- `_cycle_calc_ind` is a `0`-returning stub, not a real cycle-count
  translation (needs `cycle.c`).

## Recommended next step

Replace your local `cocotools/insn_funcs.py` with
`insn_funcs.py` in this package (or apply `insn_funcs_patch.py`'s diff
by hand if you'd rather review it inline), then run your real
`python cocotools/test_fidelity.py` to confirm all 193 existing tests
still pass and that the `insn_emit_indexed` bug fixes don't regress
anything elsewhere.
