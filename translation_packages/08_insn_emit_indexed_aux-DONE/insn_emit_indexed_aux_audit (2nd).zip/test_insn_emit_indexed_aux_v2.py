"""
test_insn_emit_indexed_aux_v2.py

Tests against the REAL cocotools/insn_funcs.py interface (methods on
Line/AsmState/Expr), using minimal stand-ins for the surrounding classes
(lw_expr.py, lwasm_types.py, lwasm_core.py, instab.py in this same
directory) that were not part of what could be fetched -- only
insn_funcs.py itself was pasted in by the user.

Run with: PYTHONPATH=/home/claude/work/v2 python3 test_insn_emit_indexed_aux_v2.py
"""

import sys
sys.path.insert(0, "/home/claude/work/v2")

from cocotools.insn_funcs import (
    insn_emit_indexed_aux,
    insn_emit_indexed,
    E_BYTE_OVERFLOW,
    E_EXPRESSION_NOT_RESOLVED,
    W_OPERAND_SIZE,
    PRAGMA_OPERANDSIZE,
)
from cocotools.lw_expr import Expr
from cocotools.lwasm_core import AsmState


class Line:
    """Stand-in for the real Line class -- only the fields/methods
    insn_emit_indexed_aux and insn_emit_indexed touch."""

    def __init__(self, lint, pb, insn=0, pragmas=0, as_=None):
        self.lint = lint
        self.pb = pb
        self.insn = insn
        self.pragmas = pragmas
        self.as_ = as_
        self.cycle_adj = 0
        self.output = bytearray()
        self._exprs = {}
        self.errors = []

    def save_expr(self, slot, e):
        self._exprs[slot] = e

    def fetch_expr(self, slot):
        return self._exprs[slot]

    def emitop(self, byte):
        self.output.append(byte & 0xFF)

    def emit(self, byte):
        self.output.append(byte & 0xFF)

    def emitexpr(self, e, width):
        v = e.intval() & ((1 << (8 * width)) - 1)
        self.output.extend(v.to_bytes(width, "big"))


results = []


def check(name, cond):
    results.append((name, cond))
    print(("PASS" if cond else "FAIL"), "-", name)


def make(lint, pb, insn=0, pragmas=0):
    as_ = AsmState()
    cl = Line(lint=lint, pb=pb, insn=insn, pragmas=pragmas, as_=as_)
    return as_, cl


# ---------------------------------------------------------------------
# insn_emit_indexed_aux direct tests
# ---------------------------------------------------------------------

# 1. lint==1, in-range 8-bit offset -> no error; trailing 1-byte offset
#    emitted since lint stays 1 (>0) after this branch.
as_, cl = make(lint=1, pb=0x88, insn=0)
cl.save_expr(0, Expr(100))
insn_emit_indexed_aux(as_, cl)
check("lint==1 in-range: no error", cl.errors == [])
check("lint==1 in-range: opcode+pb+offset byte", list(cl.output) == [0x86, 0x88, 100])
check("lint==1 in-range: cycle_adj set (stub=0)", cl.cycle_adj == 0)

# 2. lint==1, out-of-range -> E_BYTE_OVERFLOW (still emits trailing byte,
#    matching C -- the error doesn't suppress the emit, exactly like the
#    lint==3 out-of-range case doesn't suppress it either)
as_, cl = make(lint=1, pb=0x88, insn=0)
cl.save_expr(0, Expr(200))
insn_emit_indexed_aux(as_, cl)
check("lint==1 out-of-range: E_BYTE_OVERFLOW", cl.errors == [E_BYTE_OVERFLOW])

# 2b. boundary values
for v, expect_err in [(-128, False), (127, False), (128, True), (-129, True)]:
    as_, cl = make(lint=1, pb=0x88, insn=0)
    cl.save_expr(0, Expr(v))
    insn_emit_indexed_aux(as_, cl)
    got_err = cl.errors == [E_BYTE_OVERFLOW]
    check(f"lint==1 boundary {v}: {'error' if expect_err else 'no error'}",
          got_err == expect_err)

# 3. lint==3, offset in -16..15 -> pb OR'd with 5-bit value, lint cleared,
#    no trailing bytes (lint==0 after this branch fires).
as_, cl = make(lint=3, pb=0x40, insn=0)  # pb = (rn<<5) per real parse fn, rn=2 here
cl.save_expr(0, Expr(-5))
insn_emit_indexed_aux(as_, cl)
check("lint==3 -5: pb OR'd correctly", cl.pb == (0x40 | (-5 & 0x1F)))
check("lint==3 -5: lint cleared to 0", cl.lint == 0)
check("lint==3 -5: no error", cl.errors == [])
check("lint==3 -5: no trailing bytes", list(cl.output) == [0x86, cl.pb])

# 4. lint==3, offs >= 0xFFF0 (sign-extended-as-unsigned view of -16..-1)
as_, cl = make(lint=3, pb=0x40, insn=0)
cl.save_expr(0, Expr(0xFFFB))  # equivalent to -5 in 16-bit unsigned form
insn_emit_indexed_aux(as_, cl)
check("lint==3 0xFFFB: pb OR'd correctly", cl.pb == (0x40 | (0xFFFB & 0x1F)))
check("lint==3 0xFFFB: lint cleared", cl.lint == 0)
check("lint==3 0xFFFB: no error", cl.errors == [])

# 5. lint==3, offset outside both allowed ranges -> E_BYTE_OVERFLOW,
#    lint NOT cleared (stays 3), so trailing 3-byte expr still emitted.
as_, cl = make(lint=3, pb=0x40, insn=0)
cl.save_expr(0, Expr(1000))
insn_emit_indexed_aux(as_, cl)
check("lint==3 out-of-range: E_BYTE_OVERFLOW", cl.errors == [E_BYTE_OVERFLOW])
check("lint==3 out-of-range: lint stays 3", cl.lint == 3)
check("lint==3 out-of-range: trailing 3-byte expr emitted", len(cl.output) == 2 + 3)
check("lint==3 out-of-range: pb NOT modified", cl.pb == 0x40)

# 6. lint==3, expression not resolved to int -> E_EXPRESSION_NOT_RESOLVED,
#    lint untouched, and -- since lint stays 3, matching neither of the
#    later `if lint>0` branch's width logic explicitly -- the trailing
#    `if cl.lint > 0: emitexpr(e, cl.lint)` DOES still fire with width=3.
#    (this differs from the old buggy insn_emit_indexed, which silently
#    dropped the bytes here -- see divergence #2 in SUMMARY.md)
as_, cl = make(lint=3, pb=0x40, insn=0)
cl.save_expr(0, Expr(0, resolved=False))
insn_emit_indexed_aux(as_, cl)
check("lint==3 unresolved: E_EXPRESSION_NOT_RESOLVED", cl.errors == [E_EXPRESSION_NOT_RESOLVED])
check("lint==3 unresolved: lint untouched (stays 3)", cl.lint == 3)
check("lint==3 unresolved: pb untouched", cl.pb == 0x40)

# 7. lint==2, PRAGMA_OPERANDSIZE set, pb not excluded, small offset -> warning
as_, cl = make(lint=2, pb=0x89, insn=1, pragmas=PRAGMA_OPERANDSIZE)
cl.save_expr(0, Expr(50))
insn_emit_indexed_aux(as_, cl)
check("lint==2 warn-eligible: W_OPERAND_SIZE", cl.errors == [W_OPERAND_SIZE])
check("lint==2 warn path: lint untouched (still 2)", cl.lint == 2)
check("lint==2 warn path: trailing 2-byte expr emitted", len(cl.output) == 2 + 2)

# 8. lint==2, pragma set, but pb is one of the excluded values -> no check
for excluded_pb in (0xAF, 0xB0, 0x9F):
    as_, cl = make(lint=2, pb=excluded_pb, insn=1, pragmas=PRAGMA_OPERANDSIZE)
    cl.save_expr(0, Expr(50))
    insn_emit_indexed_aux(as_, cl)
    check(f"lint==2 excluded pb={hex(excluded_pb)}: no warning", cl.errors == [])

# 9. lint==2, pragma NOT set -> no check regardless of offset size
as_, cl = make(lint=2, pb=0x89, insn=1, pragmas=0)
cl.save_expr(0, Expr(50))
insn_emit_indexed_aux(as_, cl)
check("lint==2 no pragma: no warning", cl.errors == [])

# 10. lint==0 -> neither block runs, only opcode+pb emitted
as_, cl = make(lint=0, pb=0x84, insn=0)
insn_emit_indexed_aux(as_, cl)
check("lint==0: no error", cl.errors == [])
check("lint==0: only opcode+pb emitted", list(cl.output) == [0x86, 0x84])

# 11. Regression guard: lint==1's check doesn't touch pb (two-independent-if
#     structure preserved, not merged into the lint==3 pb-encoding path)
as_, cl = make(lint=1, pb=0x77, insn=0)
cl.save_expr(0, Expr(10))
insn_emit_indexed_aux(as_, cl)
check("lint==1: pb left untouched", cl.pb == 0x77)

# ---------------------------------------------------------------------
# insn_emit_indexed (LEA-style wrapper) -- confirm it now delegates and
# gets the SAME fixed behavior, notably the previously-missing checks.
# ---------------------------------------------------------------------

# The old buggy version silently dropped bytes here (no E_EXPRESSION_NOT_RESOLVED,
# cl.lint stayed 3, matched neither trailing branch. New version must
# raise the error via the shared aux function.
as_, cl = make(lint=3, pb=0x40, insn=2)  # insn=2 -> ops=[0x30] (LEAX-style)
cl.save_expr(0, Expr(0, resolved=False))
insn_emit_indexed(as_, cl)
check("insn_emit_indexed (fixed): E_EXPRESSION_NOT_RESOLVED now raised",
      cl.errors == [E_EXPRESSION_NOT_RESOLVED])

# The old buggy version never checked lint==1 overflow at all.
as_, cl = make(lint=1, pb=0x88, insn=2)
cl.save_expr(0, Expr(200))
insn_emit_indexed(as_, cl)
check("insn_emit_indexed (fixed): lint==1 overflow now caught",
      cl.errors == [E_BYTE_OVERFLOW])

# The old buggy version never set cycle_adj.
as_, cl = make(lint=0, pb=0x84, insn=2)
insn_emit_indexed(as_, cl)
check("insn_emit_indexed (fixed): cycle_adj now assigned (stub=0)",
      cl.cycle_adj == 0)


print()
failed = [name for name, ok in results if not ok]
print(f"{len(results) - len(failed)} passed, {len(failed)} failed")
if failed:
    print("FAILED:", failed)
    sys.exit(1)
