"""Minimal stand-in for cocotools/lwasm_core.py -- only what insn_funcs.py's
indexed-addressing functions need to run under test."""


def curpragma(cl, flag):
    """Stand-in for CURPRAGMA(l, flag): check cl's pragma bits, falling
    back to the owning AsmState's pragmas (matching
    DATA_STRUCTURE_AUDIT.md's note that line pragmas are inherited from
    assembler state)."""
    p = getattr(cl, "pragmas", 0)
    if p & flag:
        return True
    as_ = getattr(cl, "as_", None)
    if as_ is not None:
        return bool(getattr(as_, "pragmas", 0) & flag)
    return False


class AsmState:
    """Stand-in for asmstate_t / AsmState. Only register_error is used by
    the functions under test in this session; lookupreg2/lookupreg3 are
    stubbed as staticmethods purely so the module imports cleanly (they
    aren't exercised by insn_emit_indexed_aux)."""

    def __init__(self):
        self.errorcount = 0
        self.warningcount = 0
        self.pragmas = 0

    def register_error(self, cl, code):
        cl.errors.append(code)
        if code == "W_OPERAND_SIZE":
            self.warningcount += 1
        else:
            self.errorcount += 1

    def register_error2(self, cl, code, fmt, arg):
        self.register_error(cl, code)

    def parse_expr(self, p):
        raise NotImplementedError("not needed for this test session")

    def reduce_expr(self, e):
        pass

    @staticmethod
    def lookupreg2(regs, p):
        raise NotImplementedError("not needed for this test session")

    @staticmethod
    def lookupreg3(regs, p):
        raise NotImplementedError("not needed for this test session")
