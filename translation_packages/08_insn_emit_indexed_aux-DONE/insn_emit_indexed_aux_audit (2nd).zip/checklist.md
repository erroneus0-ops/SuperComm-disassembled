# Pre-Translation Checklist: `insn_emit_indexed_aux`  (REVISED after seeing real insn_funcs.py)

Metrics: 64 lines, 10 branches, 0 gotos

## 1. Integer width at assignment sites
`l -> pb |= offs & 0x1f;` -- confirmed safe pattern (two's-complement `&`
matches C on negatives), no wrapper needed. See v1 checklist for the
hand-check. Note: in the real codebase, `cl.pb` at the point this runs
(lint==3 path) already holds `(rn << 5)` with bits 0-4 zero (set at
parse time in `insn_parse_indexed_aux`, rn<=3 branch, which explicitly
defers the 5-bit merge to emit time -- see that function's own comment:
"the 5-bit offset itself gets merged into cl.pb later, at emit time").
So `cl.pb |= offs & 0x1f` and the sibling codebase's `cl.pb = (cl.pb &
0xE0) | (offs & 0x1F)` are behaviorally identical given that invariant --
translated as the OR form to stay a literal mirror of the C.

## 2-9. (unchanged from v1 checklist -- none found: no division/modulo,
no char**, no goto, no char signedness issue, safe argument order, safe
promotion, no bitwise complement, no register-lookup advancement here.)

## Real interface (corrected from v1 draft, which had guessed wrong)

The v1 draft in this package assumed free-function helpers
(`lwasm_fetch_expr(l, 0)`, `lw_expr_intval(e)`, etc.) because
`cocotools/insn_funcs.py` wasn't reachable yet. Now that it is, the
actual conventions are:

| C call | Real cocotools call |
|---|---|
| `lwasm_fetch_expr(l, 0)` | `cl.fetch_expr(0)` |
| `lw_expr_intval(e)` | `e.intval()` |
| `lw_expr_istype(e, lw_expr_type_int)` | `e.istype(TYPE_INT)` |
| `lwasm_register_error(as, l, CODE)` | `as_.register_error(cl, CODE)` |
| `lwasm_emitop(l, instab[l->insn].ops[0])` | `cl.emitop(_ops(cl)[0])` |
| `lwasm_emitop(l, l->pb)` | `cl.emit(cl.pb)` -- **not** `emitop` a second time; this codebase reserves `emitop` for the instruction opcode (which may be 1 or 2 bytes) and `emit` for a single raw byte. Confirmed by every other emit function in the file (`insn_emit_indexed`, `_insn_emit_gen_aux`, `insn_emit_rtor`, `insn_emit_rlist` all follow this split). |
| `lwasm_emitexpr(l, e, l->lint)` | `cl.emitexpr(e, cl.lint)` |
| `CURPRAGMA(l, PRAGMA_OPERANDSIZE)` | `curpragma(cl, PRAGMA_OPERANDSIZE)` (already imported at module top) |
| `instab[l->insn].ops[0]` | `_ops(cl)[0]` (existing module helper) |
| `lwasm_cycle_calc_ind(l)` | **no equivalent exists yet in this file.** See "Missing dependency" below. |

Error code names (`E_BYTE_OVERFLOW`, `E_EXPRESSION_NOT_RESOLVED`,
`W_OPERAND_SIZE`) and `PRAGMA_OPERANDSIZE` are already imported at the
top of `insn_funcs.py` -- no new imports needed.

## Missing dependency: `lwasm_cycle_calc_ind`

The C function's `l->cycle_adj = lwasm_cycle_calc_ind(l);` has no
translated counterpart in `insn_funcs.py`. The file does have an
analogous helper for a different instruction family
(`_cycle_calc_rlist`, for PSHS/PULS/etc.), but nothing for indexed mode.
This is a separate C function (presumably in `cycle.c`, by analogy with
`_cycle_calc_rlist`'s source comment pointing at `cycle.c` lines 656-670)
that was not provided as part of this translation package -- only
`insn_indexed.c` lines 766-829 (`insn_emit_indexed_aux` itself) were
supplied.

**Decision:** rather than guessing at `lwasm_cycle_calc_ind`'s real
per-addressing-mode cycle table (which would risk silently wrong cycle
counts -- exactly the kind of invisible-but-wrong output this project
exists to prevent), this translation adds a clearly-marked stub
`_cycle_calc_ind(cl)` that returns `0`. This is a **strict improvement
over the current state**, not a regression: `cl.cycle_adj` is currently
never assigned at all by either of the two existing call sites for this
logic (`insn_emit_indexed`, `_insn_emit_gen_aux`), so it silently stays
at its `DATA_STRUCTURE_AUDIT.md`-documented default of `0`. The new stub
produces the identical `0` result explicitly and traceably, with a
`# TODO` marking it as needing its own translation pass once
`cycle.c`'s `lwasm_cycle_calc_ind` is available to translate faithfully.
This does **not** claim to fix cycle-accurate timing -- only to avoid
silently discarding the assignment the C source performs.

## Divergences found in the EXISTING codebase (not just existing.py --
see SUMMARY.md for full detail; this is the checklist-relevant summary)

Two existing functions in `insn_funcs.py` -- `insn_emit_indexed` and
`_insn_emit_gen_aux`'s `cl.lint2 == 1` branch -- already contain
hand-rolled reimplementations of a subset of this exact logic (same
postbyte-resolution role, working over the same `cl.lint`/`cl.pb`
fields). Comparing them line-by-line against `insn_emit_indexed_aux`'s
C source surfaced real bugs in `insn_emit_indexed` specifically (see
SUMMARY.md "Divergences" section for the full list and reasoning):

1. Missing the `lint==1` 8-bit-offset overflow check entirely --
   an out-of-range 8-bit indexed offset assembles silently with no
   error.
2. Missing the `E_EXPRESSION_NOT_RESOLVED` error for the `lint==3`
   unresolved-expression case -- worse, the missing `else` means when
   this happens `cl.lint` stays `3`, which then matches neither of the
   two trailing `if cl.lint == 1` / `elif cl.lint == 2` checks, so the
   expression's bytes are **silently dropped from the output entirely**
   with zero error indication.
3. Missing the `W_OPERAND_SIZE` warning path (`lint==2` +
   `PRAGMA_OPERANDSIZE` + postbyte exclusion) completely.
4. `cl.cycle_adj` is never assigned.

`_insn_emit_gen_aux`'s indexed branch (`cl.lint2 == 1`) has a
*different* subset of the same gaps (no `W_OPERAND_SIZE` check, no
`cycle_adj`), but it is **not** the same call site as
`insn_emit_indexed_aux` -- it emits `ops[cl.lint2]` (mode-selected
opcode: DIR/IDX/EXT) rather than the fixed `ops[0]` that
`insn_emit_indexed_aux` and `insn_emit_indexed` both use. That
opcode-selection difference means `_insn_emit_gen_aux` is the Python
counterpart of a *different* C function (presumably in `insn_gen.c`,
which was not supplied in this package), not of `insn_indexed.c`'s
`insn_emit_indexed_aux`. Flagging its gaps here for visibility, but
**not** modifying it in this session -- fixing it faithfully needs
`insn_gen.c`'s actual C source as its own translation package, the same
way this package needed `insn_indexed.c`.

## Mitigations applied

- New `insn_emit_indexed_aux(as_, cl)` added, translated against the
  real interface table above.
- `insn_emit_indexed` (the LEA-style emit function, which shares the
  identical `ops[0]`-then-postbyte role) rewritten to delegate to the
  new function instead of carrying its own divergent partial copy of
  the same logic. This fixes divergences 1-4 above for that call site.
- `_insn_emit_gen_aux` left untouched -- flagged, not fixed, pending its
  own C source (see above).
- `_cycle_calc_ind` stub added with an explicit TODO, returning `0`
  (matching current silently-defaulted behavior, not introducing a new
  wrong nonzero value).
