# Current Python translation of insn_emit_indexed_aux
# cocotools/insn_funcs.py
#
# Updated 2026-07-18 (second pass, against the real insn_funcs.py you
# pasted in chat). See SUMMARY.md for the full story: this function
# already existed in disguise, duplicated across insn_emit_indexed and
# _insn_emit_gen_aux, with real bugs in the former. This translation
# adds the shared insn_emit_indexed_aux and rewrites insn_emit_indexed
# to delegate to it. See insn_funcs.py / insn_funcs_patch.py in this
# package for the exact code to merge.

def insn_emit_indexed_aux(as_, cl):
    if cl.lint == 1:
        e = cl.fetch_expr(0)
        i = e.intval()
        if i < -128 or i > 127:
            as_.register_error(cl, E_BYTE_OVERFLOW)

    # exclude expr,W since that can only be 16 bits
    if cl.lint == 3:
        e = cl.fetch_expr(0)
        if e.istype(TYPE_INT):
            offs = e.intval()
            if (offs >= -16 and offs <= 15) or offs >= 0xFFF0:
                cl.pb |= offs & 0x1f
                cl.lint = 0
            else:
                as_.register_error(cl, E_BYTE_OVERFLOW)
        else:
            as_.register_error(cl, E_EXPRESSION_NOT_RESOLVED)
    # note that extended indirect (post byte 0x9f) can only be 16 bits
    elif cl.lint == 2 and curpragma(cl, PRAGMA_OPERANDSIZE) and (
        cl.pb != 0xAF and cl.pb != 0xB0 and cl.pb != 0x9f
    ):
        e = cl.fetch_expr(0)
        if e.istype(TYPE_INT):
            offs = e.intval()
            if (offs >= -128 and offs <= 127) or offs >= 0xFF80:
                as_.register_error(cl, W_OPERAND_SIZE)

    ops = _ops(cl)
    cl.emitop(ops[0])
    cl.emit(cl.pb)

    cl.cycle_adj = _cycle_calc_ind(cl)

    if cl.lint > 0:
        e = cl.fetch_expr(0)
        cl.emitexpr(e, cl.lint)


def insn_emit_indexed(as_, cl):
    # was a hand-rolled partial duplicate with real bugs -- see SUMMARY.md
    insn_emit_indexed_aux(as_, cl)
