"""Minimal stand-in for cocotools/instab.py."""


class _Entry:
    def __init__(self, ops):
        self.ops = ops


INSTAB = {
    0: _Entry([0x86, -1, 0xB6, 0x86]),   # pretend LDA-like: DIR,IDX,EXT,IMM
    1: _Entry([0xA6, 0xA6, 0xB6, -1]),   # pretend indexed-capable entry
    2: _Entry([0x30]),                    # LEAX-style: single fixed opcode
}
