"""Minimal stand-in for cocotools/lw_expr.py -- only what insn_funcs.py's
indexed-addressing functions need to run under test. Not a claim about
the real module's full behavior."""

TYPE_INT = "int"
OPER_PLUS = "+"
OPER_MINUS = "-"


class Expr:
    """Stand-in for lw_expr_t. resolved=False models an expression that
    hasn't settled to a plain integer yet."""

    def __init__(self, value=0, resolved=True):
        self.value = value
        self.resolved = resolved

    def istype(self, t):
        assert t == TYPE_INT
        return self.resolved

    def intval(self):
        return self.value

    def copy(self):
        return Expr(self.value, self.resolved)

    @staticmethod
    def int(v):
        return Expr(v, True)

    @staticmethod
    def special(fn, cl):
        return Expr(0, False)

    @staticmethod
    def oper(op, a, b):
        return Expr(0, False)


class Ptr:
    """Stand-in for the mutable string-cursor Ptr class."""

    __slots__ = ('s', 'pos')

    def __init__(self, s, pos=0):
        self.s = s
        self.pos = pos

    def peek(self):
        return self.s[self.pos] if self.pos < len(self.s) else ''

    def advance(self, n=1):
        self.pos += n

    def remaining(self):
        return self.s[self.pos:]
