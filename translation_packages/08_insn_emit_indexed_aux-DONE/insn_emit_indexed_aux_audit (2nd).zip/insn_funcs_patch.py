# Patch for cocotools/insn_funcs.py
#
# Three changes, all localized to the "Indexed addressing mode" section:
#
#   1. NEW: insn_emit_indexed_aux(as_, cl) -- faithful translation of
#      lwtools-4.24/lwasm/insn_indexed.c lines 766-829.
#   2. NEW: _cycle_calc_ind(cl) -- stub (see checklist.md "Missing
#      dependency"); returns 0, matching the value cl.cycle_adj already
#      silently holds today, with a TODO for the real translation once
#      cycle.c is available.
#   3. CHANGED: insn_emit_indexed(as_, cl) -- was a hand-rolled partial
#      reimplementation of the same logic as insn_emit_indexed_aux, with
#      real bugs relative to the C source (see SUMMARY.md). Rewritten to
#      delegate to the new function instead.
#
# _insn_emit_gen_aux is NOT touched by this patch -- see checklist.md /
# SUMMARY.md for why (different C source file, not supplied this
# session).
#
# ===========================================================================
# CHANGE 1 + 2: insert both new functions immediately before the existing
# `def insn_parse_indexed(as_, cl, operand):` function (i.e. right after
# _insn_resolve_indexed_aux, before the LEA-style parse/resolve/emit trio).
# ===========================================================================

# ---------------------------------------------------------------------------
# FUNCTION: _cycle_calc_ind
# SOURCE:   presumably lwtools-4.24/lwasm/cycle.c (lwasm_cycle_calc_ind) --
#           NOT supplied as part of this translation package. Only
#           insn_indexed.c lines 766-829 (insn_emit_indexed_aux itself)
#           were provided.
#
# STUB -- returns 0 unconditionally. This is not a guess at the real
# per-addressing-mode cycle penalty table; it is a deliberate placeholder
# that reproduces cl.cycle_adj's current *actual* behavior (every
# existing call site that should set this field currently never assigns
# it at all, so it silently stays at the DATA_STRUCTURE_AUDIT.md-
# documented zero-init). Wiring insn_emit_indexed_aux's cycle_adj
# assignment through this stub means the assignment now happens
# explicitly and traceably (searchable, with a TODO) instead of being
# silently absent -- without introducing a fabricated nonzero cycle
# value that could be wrong in a way that's hard to notice.
#
# TODO: replace with a faithful translation once lwtools-4.24/lwasm/
# cycle.c's lwasm_cycle_calc_ind is available as its own translation
# package (same process as this one: checklist, independent translation,
# comparison, tests).
# ---------------------------------------------------------------------------
def _cycle_calc_ind(cl):
    return 0


# ---------------------------------------------------------------------------
# FUNCTION: insn_emit_indexed_aux
# SOURCE:   lwtools-4.24/lwasm/insn_indexed.c lines 766-829
# TRANSLATED: 2026-07-18
#
# Pre-translation checklist results: see checklist.md in this package for
# the full write-up. Summary:
#   Integer width: `offs & 0x1f` is a documented safe pattern (two's
#     complement `&` matches C on negative operands) -- no wrapper needed.
#   Division/modulo, char**, goto, char signedness, promotion,
#     complement, register-lookup: none present in this function.
#   Argument order: safe.
#
# Interaction risks:
#   1. Two independent top-level `if` statements in the C (`if lint==1`
#      stands alone; `if lint==3 / elif lint==2` is a separate pair) --
#      preserved exactly rather than collapsed into one elif chain.
#   2. `l->cycle_adj = lwasm_cycle_calc_ind(l)` has no translated
#      counterpart yet -- see _cycle_calc_ind's own header above.
#   3. This exact logic already existed, duplicated and buggy, in
#      insn_emit_indexed (see that function's updated body below, and
#      SUMMARY.md for the full divergence list). This translation
#      replaces that duplication rather than adding a third copy.
# ---------------------------------------------------------------------------
def insn_emit_indexed_aux(as_, cl):
    """Emit machine code for an indexed-addressing operand whose postbyte
    and/or offset size may still need a final resolution/validation step
    at emit time. Faithful translation of insn_indexed.c lines 766-829 --
    same bytes, same errors, same internal state as lwasm 4.24."""

    if cl.lint == 1:
        e = cl.fetch_expr(0)
        i = e.intval()
        if i < -128 or i > 127:
            as_.register_error(cl, E_BYTE_OVERFLOW)

    # exclude expr,W since that can only be 16 bits
    if cl.lint == 3:
        e = cl.fetch_expr(0)
        if e.istype(TYPE_INT):
            offs = e.intval()
            if (offs >= -16 and offs <= 15) or offs >= 0xFFF0:
                cl.pb |= offs & 0x1f
                cl.lint = 0
            else:
                as_.register_error(cl, E_BYTE_OVERFLOW)
        else:
            as_.register_error(cl, E_EXPRESSION_NOT_RESOLVED)
    # note that extended indirect (post byte 0x9f) can only be 16 bits
    elif cl.lint == 2 and curpragma(cl, PRAGMA_OPERANDSIZE) and (
        cl.pb != 0xAF and cl.pb != 0xB0 and cl.pb != 0x9f
    ):
        e = cl.fetch_expr(0)
        if e.istype(TYPE_INT):
            offs = e.intval()
            if (offs >= -128 and offs <= 127) or offs >= 0xFF80:
                as_.register_error(cl, W_OPERAND_SIZE)

    ops = _ops(cl)
    cl.emitop(ops[0])
    cl.emit(cl.pb)

    cl.cycle_adj = _cycle_calc_ind(cl)

    if cl.lint > 0:
        e = cl.fetch_expr(0)
        cl.emitexpr(e, cl.lint)


# ===========================================================================
# CHANGE 3: replace the existing insn_emit_indexed body.
#
# BEFORE (existing, buggy -- kept here for the record / diff clarity):
#
#     def insn_emit_indexed(as_, cl):
#         ops = _ops(cl)
#         cl.emitop(ops[0])
#         e = cl.fetch_expr(0)
#         if cl.lint == 3:
#             if e and e.istype(TYPE_INT):
#                 offs = e.intval()
#                 if (offs >= -16 and offs <= 15) or offs >= 0xFFF0:
#                     cl.pb = (cl.pb & 0xE0) | (offs & 0x1F)
#                     cl.lint = 0
#                 else:
#                     cl.as_.register_error(cl, E_BYTE_OVERFLOW)
#         cl.emit(cl.pb)
#         if cl.lint == 1 and e:
#             cl.emitexpr(e, 1)
#         elif cl.lint == 2 and e:
#             cl.emitexpr(e, 2)
#
# Bugs in the above, relative to insn_indexed.c lines 766-829 (see
# SUMMARY.md for full reasoning):
#   - No lint==1 byte-overflow check at all (E_BYTE_OVERFLOW never fires
#     for an out-of-range 8-bit offset -- silently wrong bytes, no error).
#   - No `else` on `if e and e.istype(TYPE_INT)` in the lint==3 branch --
#     when the expression isn't resolved to an int, C registers
#     E_EXPRESSION_NOT_RESOLVED; this version does nothing AND leaves
#     cl.lint at 3, which then matches neither of the trailing
#     `if cl.lint==1` / `elif cl.lint==2` checks below -- so the offset
#     bytes are silently dropped from the output entirely, with no error
#     raised at all.
#   - No W_OPERAND_SIZE warning path for lint==2 (missing entirely).
#   - cl.cycle_adj is never assigned.
#
# AFTER (this patch):
# ===========================================================================
def insn_emit_indexed(as_, cl):
    """
    RESOLVEFUNC-paired EMITFUNC for LEA-style pure indexed-addressing
    instructions. This is exactly the C role of insn_emit_indexed_aux
    (same ops[0]-then-postbyte structure, same lint/pb fields) --
    delegates directly rather than carrying its own copy of the logic.
    """
    insn_emit_indexed_aux(as_, cl)
