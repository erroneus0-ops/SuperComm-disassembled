# Pre-Translation Checklist: `insn_parse_tfm`

Metrics: 92 lines, 17 branches, 0 gotos

## 1. Integer width at assignment sites
Bit mask operations found (may need `c_uint8` etc.):
  None. `pb = (r0 << 4) | r1` stays within 0-255 by construction: r0/r1 are
  string-table indices bounded by strlen(reglist)=16, so max value is
  (15<<4)|15 = 0xFF. No mask needed.

## 2. Division / modulo
None found in this function (the "FOUND" note in the original draft of
this checklist was incorrect for `insn_parse_tfm` specifically -- there is
no `/` or `%` operator anywhere in `insn_tfm.c` lines 27-118).

## 3. char ** pointer parameters
**FOUND.** The function receives `char **p`, a single mutable cursor
advanced via `(*p)++` at four sites (both register-char reads, and the
comma). Mapped to one shared `Ptr` instance for the whole function --
no aliasing risk since there is only one such parameter here.

## 4. goto statements
  None.

## 5. char signedness
Low risk -- operands are ASCII assembly source, values 0-127 throughout.

## 6. Argument evaluation order
No `(*p)++` appears in function-call argument position in this function
(the only calls are `strchr`, `lwasm_register_error[2]`, and
`lwasm_skip_to_next_token`, none of which take `(*p)++` as an argument
alongside another use of `*p`). Not applicable.

## 7. Integer promotion
Safe -- `tfm`, `r0`, `r1` are all plain `int` in C with no destination
truncation; Python's arbitrary-precision ints need no masking here.

## 8. Bitwise complement
Not found.

## 9. Register lookup advancement
N/A -- this function does its own `strchr`-based lookup (`reglist`), it
does not call `lwasm_lookupreg2`/`lwasm_lookupreg3`.

## Character classification
`toupper` found -- used via `_tfm_reg`'s `c.upper()` (equivalent to
`c_toupper`/`c.upper()` for single ASCII chars).
`isspace` found -- used via `p.peek().isspace()` for the trailing-garbage
check, and via `c_isspace`-equivalent logic inside `_skip_to_next_token`.

## Interaction risks identified
1. **`lwasm_skip_to_next_token(l, p)` called twice in the C source**
   (after the optional +/- on r0, and after the comma), and **both calls
   were missing** from the Python translation found in this package
   (`existing.py`, and the corresponding body in `cocotools/insn_funcs.py`
   prior to this audit). This function is a no-op unless
   `PRAGMA_NEWSOURCE` is set, which is why default-mode tests never
   caught it -- it only manifests for sources written in "new syntax"
   mode with whitespace around the TFM comma.
2. **`strchr` matching the C string's own NUL terminator** when the
   operand has been fully consumed. In the real C function this leads
   into an out-of-bounds read one line later and is undefined behavior
   in `insn_tfm.c` itself -- there is no defined lwasm 4.24 behavior to
   reproduce. Documented, not "fixed" (nothing well-defined to match).

## Mitigations applied
1. Added the two missing `_skip_to_next_token(cl, p)` calls at the
   corresponding points in `insn_parse_tfm` (`cocotools/insn_funcs.py`).
2. No mitigation for the strchr/NUL-terminator UB case -- left as the
   pre-existing, safe, well-defined choice (treat "no characters left"
   as an immediate `E_REGISTER_BAD`).
