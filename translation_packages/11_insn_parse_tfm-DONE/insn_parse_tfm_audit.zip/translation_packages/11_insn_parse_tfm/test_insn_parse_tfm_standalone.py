"""
Standalone structural tests for insn_parse_tfm.

These tests exercise cocotools.insn_funcs.insn_parse_tfm directly, in pure
Python, against the AsmState/Line objects it expects. They do NOT shell out
to the prebuilt lwasm binary bundled in this repo -- I don't execute
downloaded/prebuilt third-party binaries, so these tests instead check
internal state (cl.pb, cl.lint, cl.len, error codes) against values derived
by hand-tracing lwtools-4.24/lwasm/insn_tfm.c line by line.

If you want byte-for-byte confirmation against the real lwasm 4.24 binary,
run `python cocotools/test_fidelity.py` yourself locally -- I've left that
harness untouched.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from cocotools.lwasm_core import AsmState, Line
from cocotools.lwasm_types import PRAGMA_NEWSOURCE, E_REGISTER_BAD, E_UNKNOWN_OPERATION, E_OPERAND_BAD
from cocotools.insn_funcs import insn_parse_tfm

TFM_INSN_INDEX = None


def _find_tfm_insn_index():
    from cocotools.instab import INSTAB
    for i, entry in enumerate(INSTAB):
        if entry.ops == [0x1138, 0x1139, 0x113a, 0x113b]:
            return i
    raise RuntimeError("could not locate 'tfm' entry in INSTAB")


def make_line(as_, newsource=False):
    cl = Line(as_)
    cl.insn = _find_tfm_insn_index()
    if newsource:
        cl.pragmas |= PRAGMA_NEWSOURCE
    return cl


def run(operand, newsource=False):
    as_ = AsmState()
    cl = make_line(as_, newsource=newsource)
    insn_parse_tfm(as_, cl, operand)
    return as_, cl


def expect(cond, msg):
    if not cond:
        raise AssertionError(msg)
    print(f"  ok: {msg}")


def test_basic_postinc_postinc():
    # TFM D+,X+  -> tfm = 1|4 = 5 -> ops[0] = 0x1138
    as_, cl = run("D+,X+")
    expect(cl.pb == (0 << 4 | 1), f"pb == 0x01, got {cl.pb:#x}")
    expect(cl.lint == 0x1138, f"lint == ops[0]=0x1138, got {cl.lint:#x}")
    expect(cl.len == 3, f"len == OPLEN(0x1138)+1 == 3, got {cl.len}")
    expect(as_.errorcount == 0, "no errors for valid D+,X+")


def test_basic_postdec_postdec():
    # TFM X-,Y-  -> tfm = 2|8 = 10 -> ops[1] = 0x1139
    as_, cl = run("X-,Y-")
    expect(cl.pb == (1 << 4 | 2), f"pb == 0x12, got {cl.pb:#x}")
    expect(cl.lint == 0x1139, f"lint == ops[1]=0x1139, got {cl.lint:#x}")


def test_r0_postinc_only():
    # TFM D+,X -> tfm = 1 -> ops[2] = 0x113a
    as_, cl = run("D+,X")
    expect(cl.lint == 0x113a, f"lint == ops[2]=0x113a, got {cl.lint:#x}")


def test_r1_postinc_only():
    # TFM D,X+ -> tfm = 4 -> ops[3] = 0x113b
    as_, cl = run("D,X+")
    expect(cl.lint == 0x113b, f"lint == ops[3]=0x113b, got {cl.lint:#x}")


def test_bad_register_first():
    # 'Q' is not in reglist at all -> strchr returns NULL -> E_REGISTER_BAD, early return
    as_, cl = run("Q,X+")
    expect(as_.errorcount == 1, f"one error registered, got {as_.errorcount}")
    expect(cl.err is not None and cl.err.code == E_REGISTER_BAD,
           "error code is E_REGISTER_BAD")


def test_missing_comma():
    as_, cl = run("D+X+")
    expect(cl.err is not None and cl.err.code == E_UNKNOWN_OPERATION,
           "missing comma -> E_UNKNOWN_OPERATION")


def test_trailing_garbage():
    as_, cl = run("D,X+Q")
    expect(cl.err is not None and cl.err.code == E_OPERAND_BAD,
           "trailing non-space garbage -> E_OPERAND_BAD")


def test_only_valid_dxyus_registers_no_secondary_error():
    # A and B are in reglist (matched by strchr) but index > 4 -> register_error2
    # fires but does NOT return -- execution still falls through to compute
    # pb/lint/len (this is the C fall-through behavior; existing.py already
    # matched it correctly).
    as_, cl = run("A+,B+")
    expect(as_.errorcount == 1, "A/B registers still produce a register error")
    expect(cl.lint == 0x1138, "but tfm still resolves to ops[0] (fall-through, matches C)")


def test_newsource_whitespace_before_comma_now_parses():
    # Regression test for the bug found during this audit: the C source
    # calls lwasm_skip_to_next_token(l, p) after the optional +/- on r0,
    # before checking for the comma. Under PRAGMA_NEWSOURCE this means
    # whitespace before the comma is legal. The version of insn_parse_tfm
    # found in this package (existing.py) omitted this call entirely.
    as_, cl = run("D+ ,X+", newsource=True)
    expect(as_.errorcount == 0,
           "PRAGMA_NEWSOURCE: whitespace before comma must not error "
           "(would have raised E_UNKNOWN_OPERATION before the fix)")
    expect(cl.lint == 0x1138, "parse still resolves correctly after skipping whitespace")


def test_newsource_whitespace_after_comma_now_parses():
    as_, cl = run("D+, X+", newsource=True)
    expect(as_.errorcount == 0,
           "PRAGMA_NEWSOURCE: whitespace after comma must not error "
           "(would have misparsed the space as the r1 register before the fix)")
    expect(cl.lint == 0x1138, "parse still resolves correctly after skipping whitespace")


def test_default_pragma_whitespace_before_comma_still_errors():
    # Sanity check: _skip_to_next_token is a no-op without PRAGMA_NEWSOURCE,
    # so default-mode (6809/6309, non-newsource) sources must still reject
    # whitespace before the comma, exactly like lwasm's default parser.
    as_, cl = run("D+ ,X+", newsource=False)
    expect(cl.err is not None and cl.err.code == E_UNKNOWN_OPERATION,
           "default pragma: whitespace before comma is still a hard error")


ALL_TESTS = [
    test_basic_postinc_postinc,
    test_basic_postdec_postdec,
    test_r0_postinc_only,
    test_r1_postinc_only,
    test_bad_register_first,
    test_missing_comma,
    test_trailing_garbage,
    test_only_valid_dxyus_registers_no_secondary_error,
    test_newsource_whitespace_before_comma_now_parses,
    test_newsource_whitespace_after_comma_now_parses,
    test_default_pragma_whitespace_before_comma_still_errors,
]

if __name__ == '__main__':
    passed = 0
    failed = 0
    for t in ALL_TESTS:
        print(f"{t.__name__}:")
        try:
            t()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"  FAIL: {e}")
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
