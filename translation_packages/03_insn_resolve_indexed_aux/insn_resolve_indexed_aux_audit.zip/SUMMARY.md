# Audit Summary: `insn_resolve_indexed_aux`

## 0. A note on the package itself

Before any translation work started, `source.c` in this package was
mislabeled -- it contained the body of `insn_parse_gen_aux`
(`insn_gen.c` lines 39-190), not `insn_resolve_indexed_aux`. This was
caught by cross-checking the function name that actually appears in the
file body against `lwtools-4.24/lwasm/insn_gen.c` and
`lwtools-4.24/lwasm/insn_indexed.c` before writing any translation, and
flagged back rather than silently translating the wrong function. The
package was subsequently corrected upstream; `source.c` now contains
`insn_indexed.c` lines 480-750 (271 lines), verified below to be an
exact copy of the real source.

## 1. What I read, and in what order

1. `translation_packages/03_insn_resolve_indexed_aux/brief.md`
2. `translation_packages/03_insn_resolve_indexed_aux/source.c` (first the
   mislabeled version, then the corrected version -- diffed the
   corrected version against `lwtools-4.24/lwasm/insn_indexed.c` lines
   480-750 directly; exact match, no drift)
3. `translation_packages/03_insn_resolve_indexed_aux/checklist.md`
4. `cocotools/TRANSLATION_GUIDE.md`
5. `cocotools/DATA_STRUCTURE_AUDIT.md`
6. `cocotools/c_compat.py`
7. `translation_packages/03_insn_resolve_indexed_aux/existing.py` (stale
   -- said "not yet located"; the real state was found by grepping
   `cocotools/insn_funcs.py` directly, see below)
8. `cocotools/insn_funcs.py` -- found `_insn_resolve_indexed_aux` already
   present (lines 860-1025), added 2026-07-17 as glue for package 02,
   with a header comment explicitly requesting the independent audit
   this package performs
9. Supporting reads during the audit itself: `cocotools/lwasm_core.py`
   (`curpragma`, `fetch_expr`, `reduce_expr`, `AsmState.__init__`),
   `cocotools/lw_expr.py` (`Expr.copy`/`istype`/`intval`), the real
   `insn_resolve_indexed` wrapper and `do_pass4_aux` in
   `lwtools-4.24/lwasm/insn_indexed.c` / `pass4.c`, and
   `lwtools-4.24/lwasm/main.c` (default pragma initialization)

## 2. Pre-translation checklist

Completed in `checklist.md` (all 9 categories). Summary:

| # | Category | Finding |
|---|----------|---------|
| 1 | Integer width | `pb`/`v` bitmask operations throughout; all fit safely in Python's arbitrary-precision ints without truncation, since every stored value stays within the 0-255 postbyte range by construction (same as the "Known Safe Patterns" table in TRANSLATION_GUIDE.md) |
| 2 | Division/modulo | Not found |
| 3 | `char **p` | Not found (no operand text parsing in this function) |
| 4 | `goto` | One: `goto do16bit`, Pattern B (shared code block). Translated by duplicating the target code inline at both the label site and the jump site -- correct because the shared block is straight-line code with no side effects in between the two entry points |
| 5 | char signedness | N/A -- no character comparisons |
| 6 | Argument evaluation order | N/A -- no `(*p)++`-style argument expressions |
| 7 | Integer promotion | Checked; no destination is a fixed-width C type narrower than what Python already handles safely |
| 8 | Bitwise complement | Not found |
| 9 | Register lookup advancement | N/A |

Interaction risks and mitigations: see `checklist.md` (filled in as part
of this audit).

## 3. Independent translation vs. `existing.py`

Per the required order, I read `source.c` and worked out the branch
structure independently (all six decision points: the two "which size"
ladders -- one under speculative `e2` resolution, one under final `e`
resolution -- the regfield==5/6 PCR pretendmax heuristic, and the
force/no-force tail) before comparing against the code already sitting
in `cocotools/insn_funcs.py`.

**Divergences found: zero, inside this function.** Every branch,
condition, and assignment in `_insn_resolve_indexed_aux`
(`cocotools/insn_funcs.py` lines 860-1025) matches `source.c` line for
line, including a subtle asymmetry that would be easy to translate
wrong: the zero-offset condition in the *speculative* `e2`-is-int branch
checks `v == 0 && !CURPRAGMA(...) && regfield <= 4` (no `f0`/bit-6
check), while the same condition in the *final* `e`-is-int branch adds
`&& (l->pb & 0x40) == 0`. This asymmetry exists verbatim in the C and is
preserved correctly in both places in the Python.

Since I found no line-level divergence, I did not need to adjudicate
"bug in existing.py vs. correct behavior" cases for this function's own
logic. I instead ran the fidelity harness and stress-tested the
function's real-world entry points (see next section), which is where
an actual bug turned up -- not inside this function, but in a shared
default that controls *when* the function gets called with `force=1`.

## 4. The bug found and fixed (outside this function, discovered via this function)

### Discovery

I hand-derived expected bytes for forward-referenced indexed operands
and cross-checked them against the actual `lwasm` 4.24 binary
(`/home/claude/supercomm/lwtools-4.24/lwasm/lwasm`), specifically
picking forward-reference values that are small enough to fit a
*compact* postbyte encoding once known, so that "decided too early,
locked at worst case" and "decided once the value is known, picked the
smallest encoding" would produce visibly different bytes:

```
LDA FWD,X
RTS
FWD EQU 5
```

- **cocotools (before fix):** `A6 05 39` -- compact 5-bit postbyte
- **lwasm 4.24 (reference):** `A6 89 00 05 39` -- 16-bit postbyte form

Same divergence with `FWD EQU 100` (fits 8-bit, still locked to 16-bit
by real lwasm) and with the 6309 W-register form (`LDA FWD,W`).

### Root cause

`_insn_resolve_indexed_aux` is only ever invoked by the
`insn_resolve_indexed` wrapper when `l->lint == -1`, and that wrapper
never calls it again afterward:

```c
RESOLVEFUNC(insn_resolve_indexed)
{
	if (l -> lint == -1)
		insn_resolve_indexed_aux(as, l, force, 0);
	...
```

(`lwtools-4.24/lwasm/insn_indexed.c`, confirmed identically translated
in `cocotools/insn_funcs.py`'s `insn_resolve_indexed`.) So whatever this
function decides the *first* time it successfully runs is final for the
rest of assembly -- it is never asked to reconsider.

Real lwasm's `main.c` sets a pragma on by default, before command-line
parsing, specifically to control this:

```c
// enable the "forward reference maximum size" pragma; old available
// can be obtained with --pragma=noforwardrefmax
asmstate.pragmas = PRAGMA_FORWARDREFMAX;
```

`cocotools/pass1.py` already has the matching logic to *act* on this
pragma -- immediately after parsing an operand, if the pragma is set, it
force-resolves with `force=1`:

```python
# PRAGMA_FORWARDREFMAX: force resolution
if curpragma(cl, PRAGMA_FORWARDREFMAX) and ie.resolve:
    ie.resolve(as_, cl, 1)
```

For an indexed operand whose value isn't known yet at this point (a
genuine forward reference), `force=1` drives
`_insn_resolve_indexed_aux` straight into its final `else` clause --
the one this package's checklist flagged as Pattern B goto handling --
which locks `l->lint = 2` (16-bit) unconditionally. That's the correct,
faithful behavior of the function *given* `force=1`. The bug was that
`cocotools/lwasm_core.py`'s `AsmState.__init__` never set
`PRAGMA_FORWARDREFMAX` in the first place:

```python
self.pragmas       = PRAGMA_6809  # default to 6809 mode
```

So `curpragma(cl, PRAGMA_FORWARDREFMAX)` was always `False`, the
force=1 call in pass1.py never fired for ordinary assembly, `l->lint`
stayed `-1` through pass 1, and by the time a later pass finally
resolved `FWD`'s value, the function correctly (for a `force=0`,
already-known-value call) picked the smallest encoding that fits --
which is the right answer to a different question than the one real
lwasm actually asks by default.

### Fix

`cocotools/lwasm_core.py`, `AsmState.__init__`:

```python
# old:
self.pragmas       = PRAGMA_6809  # default to 6809 mode

# new:
self.pragmas       = PRAGMA_6809 | PRAGMA_FORWARDREFMAX  # default to 6809 mode
```

(plus adding `PRAGMA_FORWARDREFMAX` to that file's existing
`from .lwasm_types import (...)` block.)

This is a one-bit default-value fix, not a change to any parsing or
resolution logic. `PRAGMA_FORWARDREFMAX` was already fully wired up
everywhere it needs to be (`cocotools/pass1.py`) -- it was simply never
turned on.

### Verification

- Re-ran the four probe cases above (X, plus 8-bit-value X, plus a
  genuinely-undefined-symbol case, plus a PCR forward reference) against
  the real `lwasm` binary after the fix: all four now match byte-for-byte
  (see section 5 for the PCR and undefined-symbol cases specifically).
- Ran the full pre-existing fidelity harness before and after the fix:
  **230/230 passed both times** -- the fix causes no regression in any
  previously-passing test (166 fidelity + 33 behavioral + 3 behavioral-6309
  + 20 structural + 8 expression-simplify).
- `PRAGMA_FORWARDREFMAX` is referenced in exactly one place in
  `cocotools/*.py` outside its definition and this fix
  (`cocotools/pass1.py`'s single force=1 call site), so the fix's blast
  radius is fully understood and was not touched blindly.

## 5. New tests added

5 new tests, all passing against the real `lwasm` 4.24 binary:

**`BEHAVIOR_TESTS` (4 new, 6809 mode):**

1. `indexed-fwdref-locks-16bit-not-5bit` -- `LDA FWD,X` / `FWD EQU 5`.
   Forward-referenced value that *would* fit a compact 5-bit postbyte if
   resolved fresh; must instead lock to 16-bit. Direct regression test
   for the bug above. Expected: `A6 89 00 05 39`.
2. `indexed-fwdref-locks-16bit-not-8bit` -- same mechanism, value 100
   (fits 8-bit if resolved fresh). Expected: `A6 89 00 64 39`.
3. `indexed-undefined-symbol-forced` -- `LDA UNDEF,X` where `UNDEF` is
   never defined anywhere. Exercises the function's final
   `if (!force) return;` / `goto do16bit` tail with `force=1` reaching a
   value that never resolves at all -- must error exactly as lwasm does
   (both tools report an undefined-symbol error; verified this is a
   real error in cocotools, not a silently-empty one, by running
   `cocotools.py asm` directly and checking stderr: `Undefined symbol
   UNDEF`), not silently succeed or crash.
4. `indexed-pcr-forward-heuristic` -- `LDA FAR,PCR` where `FAR` is 40
   `NOP`s away, still unresolved on the first attempt. Exercises the
   `regfield == 5` branch's `as->pretendmax` fudge-factor heuristic
   inside the speculative (`e2`) resolution path -- the pre-existing
   `indexed-pcr-relative` test's target is already a resolved literal at
   parse time and never reaches this heuristic at all.

**`BEHAVIOR_TESTS_6309` (1 new, 6309 mode):**

5. `indexed-w-fwdref-locks-16bit-6309` -- `LDA FWD,W` / `FWD EQU 5`.
   Same forward-reference lock, through the `regfield == 4` (W) branch,
   which has its own opcode pair (`0xAF`/`0xB0`) distinct from `0x89`.
   Also confirms the lock doesn't fall back to W's zero-offset opcode
   instead, since W has no compact non-zero encoding at all. Expected:
   `A6 AF 00 05 39`.

## 6. Final test counts

```
Running 166 fidelity tests (6809 mode)...
Results: 166 passed, 0 failed out of 166 tests

Running 37 behavioral tests...
Behavioral results: 37 passed, 0 failed out of 37 tests

Running 4 behavioral (6309-only) tests...
Behavioral (6309-only) results: 4 passed, 0 failed out of 4 tests

Running 20 structural tests...
Structural results: 20 passed, 0 failed out of 20 tests

Running 8 expression-simplify tests...
Expression-simplify results: 8 passed, 0 failed out of 8 tests
```

**Total: 235 passed, 0 failed.** (230 pre-existing + 5 new; all
pre-existing tests still pass, confirming no regression.)

## 7. Files changed

- `cocotools/lwasm_core.py` -- added `PRAGMA_FORWARDREFMAX` to the
  import list and to `AsmState.__init__`'s default `self.pragmas` value
  (the actual bug fix; see section 4)
- `cocotools/test_fidelity.py` -- added 5 new test cases (section 5)
- `translation_packages/03_insn_resolve_indexed_aux/checklist.md` --
  filled in Interaction risks / Mitigations applied
- `translation_packages/03_insn_resolve_indexed_aux/existing.py` --
  corrected from stale "not yet located" placeholder to reflect the
  actual current, audited state of the translation

`cocotools/insn_funcs.py` (the function under audit) was **not
modified** -- it was already a faithful translation and needed no
changes.

## 8. One thing intentionally left alone

The test harness's `assemble_cocotools` helper (`test_fidelity.py`)
only captures the subprocess's `stdout` for its returned error string,
but `cocotools.py`'s CLI prints errors to `stderr`. This makes the
`err` value reported for cocotools failures look empty in ad hoc
debugging even when a real, correct error occurred and was correctly
detected by the pass/fail logic (which only checks whether output bytes
are `None`, not the error text). This is a cosmetic gap in the harness's
verbose-mode diagnostics, not a correctness issue -- confirmed by
running `cocotools.py asm` directly and observing the real stderr
message (`Undefined symbol UNDEF`). Left unfixed as out of scope for
this package; noting it here so it isn't rediscovered as a surprise.
