# Translation Audit Summary: `insn_emit_rtor`

Package: `translation_packages/07_insn_emit_rtor`
C source: `lwtools-4.24/lwasm/insn_rtor.c` (lines 58-62)
Python target: `cocotools/insn_funcs.py`

## What I read, in order

1. `translation_packages/07_insn_emit_rtor/source.c`
2. `translation_packages/07_insn_emit_rtor/checklist.md`
3. `cocotools/TRANSLATION_GUIDE.md`
4. `cocotools/DATA_STRUCTURE_AUDIT.md`
5. `cocotools/c_compat.py`
6. `translation_packages/07_insn_emit_rtor/existing.py`
7. `cocotools/insn_funcs.py` (full file, focusing on `_ops`, `insn_parse_rtor`,
   `insn_resolve_rtor`, `insn_emit_rtor`, and neighboring rtor-family code)
8. `cocotools/lwasm_core.py` (`Line.emit` / `Line.emitop`, to confirm the
   two functions this C function calls are themselves faithful, since
   `insn_emit_rtor` is nothing but two calls into them)
9. `cocotools/instab.py` (to find every instruction that shares the `rr`
   emit function, and their opcode widths)

## Pre-translation checklist

Completed in full at `translation_packages/07_insn_emit_rtor/checklist.md`
(updated version included in this package). Summary: all 9 categories are
either "none" or "N/A" for this specific function -- it has no
assignments, no arithmetic, no branches, no pointer cursor, and no
`goto`. The one non-trivial interaction risk identified is that
`instab[l->insn].ops[0]` (the opcode passed to `lwasm_emitop`) is a
two-byte value for the 6309-only rtor-family instructions (ADCR, ADDR,
ANDR, CMPR, EORR, ORR, SBCR, SUBR — opcodes `0x1030`-`0x1037`), which
drives a branch inside `lwasm_emitop` itself. That branch lives outside
this function's own source but is a real code path this function
triggers, and it had no test coverage through `insn_emit_rtor`
specifically before this audit.

## C function

```c
EMITFUNC(insn_emit_rtor)
{
	lwasm_emitop(l, instab[l -> insn].ops[0]);
	lwasm_emit(l, l -> pb);
}
```

Two unconditional calls: emit the instruction's base opcode (from the
instruction table), then emit the postbyte (`l->pb`, the packed
register-pair nibble computed earlier by `insn_parse_rtor`). No
assignments, no branches, no loops.

## Independent translation

Written from the C source alone, before looking at `existing.py`:

```python
def insn_emit_rtor(as_, cl):
    cl.emitop(_ops(cl)[0])
    cl.emit(cl.pb)
```

`_ops(cl)[0]` is the established Python idiom in this file for
`instab[l->insn].ops[0]` (see `_ops()`'s definition and its use in
`insn_parse_rtor`, `insn_parse_inh`, etc.), and `cl.emitop`/`cl.emit`
are the established methods standing in for `lwasm_emitop`/`lwasm_emit`.

## Divergences found between existing.py and the C source

**None.** The translation already present in both
`translation_packages/07_insn_emit_rtor/existing.py` and
`cocotools/insn_funcs.py` (line 1356) is:

```python
def insn_emit_rtor(as_, cl):
    cl.emitop(_ops(cl)[0])
    cl.emit(cl.pb)
```

This is identical, statement-for-statement, to the independent
translation above. There is no bug to fix in `insn_emit_rtor` itself.

I also verified the two functions it calls are faithful to their C
counterparts, since a correct-looking `insn_emit_rtor` could still
produce wrong output if `Line.emitop`/`Line.emit` were wrong:

- `Line.emitop` (`cocotools/lwasm_core.py`) splits opcodes `> 0x100`
  into two emitted bytes (high byte first), matching `lwasm_emitop`'s
  `OPLEN`/two-byte-opcode handling in the C source (`insn_gen.c`), and
  updates the cycle counter on first emit — out of scope for this
  package (it's a separate, already-audited function) but confirmed
  consistent with `insn_emit_rtor`'s use of it.
- `Line.emit` (`cocotools/lwasm_core.py`) appends to `cl.output` (the
  bytearray standing in for C's `unsigned char*`), matching
  `lwasm_emit`.

## Bugs fixed

None. No divergence was found, so no code fix was required.

## Test coverage added

Before this audit, `insn_emit_rtor`'s behavior was only checked
*indirectly*:
- Full byte-comparison fidelity tests for `TFR`/`EXG` against real
  lwasm (`TESTS`, lines ~213-221) — these do exercise emit, but a
  failure there wouldn't distinguish an `insn_parse_rtor` bug from an
  `insn_emit_rtor` bug.
- Structural tests `struct-tfr-d-x` / `struct-tfr-a-b` — these check
  `cl.pb`/`cl.len`/`cl.lint`, all of which are set at **parse** time,
  not emit time. They would pass even if `insn_emit_rtor` emitted
  nothing at all.
- No test exercised the two-byte-opcode branch (`ops[0] > 0xFF`) through
  `insn_emit_rtor` specifically — only single-byte-opcode instructions
  (TFR `0x1f`, EXG `0x1e`) had rtor-family coverage.

Three new tests added to `cocotools/test_fidelity.py`:

1. **`struct-tfr-d-x-output-bytes`** (structural test) — asserts
   `cl.output == bytearray([0x1f, 0x01])` after `TFR D,X`. Checks the
   actual bytes `insn_emit_rtor` writes, in order (opcode then
   postbyte), not just the pre-computed `cl.pb` value.

2. **`struct-exg-a-b-output-bytes`** (structural test) — asserts
   `cl.output == bytearray([0x1e, 0x89])` after `EXG A,B`. Same
   rationale, second instruction/opcode to rule out a test that only
   coincidentally passes for one specific opcode value.

3. **`rtor-two-byte-opcode-adcr-6309`** (behavioral, 6309-only,
   full byte comparison against real lwasm) — `ADCR A,B` assembles to
   `0x10 0x31 0x89` (opcode `0x1031` split into two bytes by
   `lwasm_emitop`, then postbyte `0x89`). Verified independently
   against `lwtools-4.24/lwasm/lwasm --6309`, which produced the
   identical `10 31 89` sequence. This is the only rtor-family
   instruction whose opcode exceeds one byte, so it's the only way to
   exercise that branch through `insn_emit_rtor`.

## Final test counts

```
Running 170 fidelity tests (6809 mode)...
Results: 170 passed, 0 failed out of 170 tests

Running 45 behavioral tests...
Behavioral results: 45 passed, 0 failed out of 45 tests

Running 5 behavioral (6309-only) tests...
Behavioral (6309-only) results: 5 passed, 0 failed out of 5 tests

Running 30 structural tests...
Structural results: 30 passed, 0 failed out of 30 tests

Running 8 expression-simplify tests...
Expression-simplify results: 8 passed, 0 failed out of 8 tests

Running 4 unit tests...
Unit results: 4 passed, 0 failed out of 4 tests
```

All 262 tests pass, 0 failed (259 pre-existing + 3 new). No regressions.

## Conclusion

`insn_emit_rtor` was already a faithful translation — a direct,
line-for-line match of the 5-line C function with no logic to diverge
on. This audit's value was in closing a test-coverage gap (emit-time
`cl.output` bytes were previously unchecked, and the two-byte-opcode
branch was previously unexercised through this function), not in fixing
a bug.
