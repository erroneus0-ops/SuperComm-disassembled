# Pre-Translation Checklist: `insn_emit_rtor`

Metrics: 5 lines, 0 branches, 0 gotos

## 1. Integer width at assignment sites
Check every assignment destination type.
Bit mask operations found (may need `c_uint8` etc.):
  None. The function makes no assignments -- it only reads
  `instab[l->insn].ops[0]` and `l->pb` and passes them, unmodified,
  to `lwasm_emitop` / `lwasm_emit`. Any width truncation needed for
  those values happens inside `lwasm_emitop`/`lwasm_emit` themselves
  (out of scope for this function), not here.

## 2. Division / modulo
Not found.

## 3. char ** pointer parameters
Not found. `insn_emit_rtor` takes no operand-string cursor.

## 4. goto statements
  None.
Classify each: A=exit (return), B=shared code (helper fn), C=alternate parse (call fn).

## 5. char signedness
Low risk. No char comparisons in this function.

## 6. Argument evaluation order
Check for `(*p)++` in function argument position.
Not applicable -- both calls (`lwasm_emitop`, `lwasm_emit`) take a single
value argument each, no compound/incrementing expressions.

## 7. Integer promotion
Check compound expressions. Add mask only where C destination type truncates.
Not applicable -- no compound expressions, no arithmetic.

## 8. Bitwise complement
Not found.

## 9. Register lookup advancement
N/A. Register parsing happens in `insn_parse_rtor`, not here; by the
time `insn_emit_rtor` runs, `l->pb` already holds the packed register
pair computed at parse time.

## Character classification
N/A.

## Interaction risks identified
- `instab[l->insn].ops[0]` (Python: `_ops(cl)[0]`) can be a two-byte
  opcode (> 0xFF) for the 6309-only rtor-family instructions (ADCR,
  ADDR, ANDR, CMPR, EORR, ORR, SBCR, SUBR -- opcodes 0x1030-0x1037),
  as opposed to TFR/EXG (0x1f/0x1e) which are single-byte. This drives
  a branch inside `lwasm_emitop`/`cl.emitop()` (emit high byte first,
  then low byte) that isn't visible in `insn_emit_rtor`'s own source
  but is a real behavioral path this function triggers. No existing
  test exercised this path through `insn_emit_rtor` before this audit.
- `cl.pb` must already be fully resolved (both register nibbles packed)
  by the time emit runs -- `insn_resolve_rtor` is a no-op (`pass`), so
  `cl.pb` is whatever `insn_parse_rtor` set it to. There's no
  resolve-time recomputation to get wrong, but it does mean emit-time
  correctness depends entirely on parse-time correctness -- an emit-only
  test can look right for the wrong reason if a parse bug happened to
  produce a plausible-but-wrong `cl.pb`. Mitigated by testing against
  real lwasm 4.24 byte-for-byte, not just checking `cl.pb`'s value.

## Mitigations applied
- None needed in `insn_emit_rtor` itself -- it is a direct, unconditional
  two-call pass-through with no arithmetic, no branches, and no width-
  sensitive assignments.
- Added test coverage (see SUMMARY.md) for the two-byte-opcode emit path
  and for `cl.output` bytes directly, since prior tests only checked
  `cl.pb`/`cl.len`/`cl.lint` (parse-time state) and never asserted on
  the actual emitted bytes that this specific function produces.
