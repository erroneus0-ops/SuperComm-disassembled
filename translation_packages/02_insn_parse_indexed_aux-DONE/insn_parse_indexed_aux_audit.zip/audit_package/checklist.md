# Pre-Translation Checklist: `insn_parse_indexed_aux`

Metrics: 426 lines, 97 branches, 0 gotos

STATUS: COMPLETE. Translated 2026-07-17. All fidelity-harness tests pass
(230/230: 166 opcode-matrix + 33 behavioral + 3 behavioral-6309-only +
20 structural + 8 expression-simplify), in both --6809 and --6309 modes.

## 1. Integer width at assignment sites
Check every assignment destination type.
Bit mask operations found (may need `c_uint8` etc.):
  None. Confirmed during translation: every value constructed in this
  function is a postbyte fragment or a small pass-forward integer
  (0-0xFF range), safe by construction per the "Known Safe Patterns"
  table in TRANSLATION_GUIDE.md. No c_uint8/c_int8 etc. needed.

## 2. Division / modulo
**FOUND** -- use `c_trunc_div()` / `c_trunc_mod()` for signed operands.
Not applicable: no `/` or `%` operator appears anywhere in this
function's C source. (The checklist template's boilerplate line above
was pre-filled for the whole guide, not verified against this specific
function -- confirmed by direct inspection of source.c.)

## 3. char ** pointer parameters
**FOUND** -- pass the same `Ptr` instance through all callers. Do NOT
create new Ptr from `p.remaining()`.
Applies to the main `p` parameter (shared with both call sites, which
already hold the correct Ptr instance across the parse chain).
**Additional wrinkle found during translation**: the C source also
contains a *second*, deliberately-NOT-shared pointer idiom:
`tstr = *p + 1; lwasm_skip_to_next_token(l, &tstr); if (*tstr == ',') ...`
This creates an independent local cursor for one-token lookahead, and
only copies its advanced position back into `*p` if the lookahead
actually matches. This appears twice (accumulator-offset detection, and
the "does this expression start with a literal 0" check). Mitigation:
construct a **fresh** `Ptr(p.s, p.pos + 1)` for each such lookahead;
never reuse or alias `p` itself for these two spots.

## 4. goto statements
  None.
Confirmed: 0 gotos in this function (matches the file header metrics).

## 5. char signedness
Low risk -- check comparisons of `*p` > 127.
No such comparisons in this function. All character comparisons are
against ASCII register-name letters and punctuation.

## 6. Argument evaluation order
Check for `(*p)++` in function argument position.
None found in this function.

## 7. Integer promotion
Check compound expressions. Add mask only where C destination type
truncates.
None needed -- all postbyte-construction expressions stay within 8 bits
by construction (verified against every branch during translation).

## 8. Bitwise complement
Not found.

## 9. Register lookup advancement
**Check** lookupreg2/3 calls share Ptr correctly.
`AsmState.lookupreg3(reglist, p)` is called once, for the "expr,REG"
form only -- this is the only place in the function that accepts the
full register list (X/Y/U/S/W/PCR/PC). The two other in-function
register matches (immediately after a leading comma, and after an
accumulator-offset letter) are hand-rolled switch statements in the C
itself (not calls to lwasm_lookupreg2/3) and intentionally accept a
*smaller* register set (no PC/PCR) -- translated as direct Python
if/elif chains matching the C switch exactly, not routed through
lookupreg3.

## Character classification
`toupper` found -- use `c.upper()` or `c_toupper(c)`
Used once, for the accumulator-letter check (`i = toupper(**p)`).
Translated as `p.peek().upper()`. The two register-letter switches use
raw (non-uppercased) comparisons against both-case tuples (`c in ('x',
'X')`), matching the C switch's explicit dual case labels exactly.

## Interaction risks identified

1. **Pre-set `l->lint = -1` requirement.** Both real C call sites
   (`insn_gen.c`'s `goto indexed:` block, and `insn_indexed.c`'s
   `PARSEFUNC(insn_parse_indexed)`) set `l->lint = -1` immediately
   before calling this function. This function reads `l->lint` in
   several branches (to decide whether a preceding `<`/`<<`/`>` prefix
   already fixed the offset size). If a Python caller does not also
   preset `cl.lint = -1` first, those branches will read a stale value.

2. **Marker byte contract with `insn_resolve_indexed_aux`.** When the
   offset size cannot be decided during parsing (no forcing prefix, and
   -- unlike a hand-rolled ad hoc implementation might assume -- this
   function does *not* try to shortcut the decision even when the
   expression is already a resolved constant), this function writes a
   *marker* into `cl.pb`, not a final postbyte: register field
   unshifted in bits 0-2 (values 0-6 for X/Y/U/S/W/PCR/PC), indirect
   flag at bit 7 (0x80, not 0x10), and an "explicit zero was written"
   flag at bit 6 (0x40). `cl.lint` is left at -1. Only
   `insn_resolve_indexed_aux` decodes this marker. Any code that reads
   `cl.pb` between parse and resolve must not mistake it for a real
   postbyte.

3. **The previously-existing ad hoc translation in this codebase
   (`_parse_indexed_mode` / old `_insn_resolve_indexed_aux`) used a
   DIFFERENT, incompatible marker layout** (register pre-shifted into
   bits 5-6, indirect at bit 4), because its parser never actually
   deferred the size decision -- it always decided immediately,
   guessing 16-bit pessimistically for any not-yet-constant forward
   reference. Swapping in a faithful parser without also fixing the
   resolve-side decoder would silently corrupt every indexed operand
   whose size could not be decided at parse time. See SUMMARY.md for
   the full account of this coupling and how it was resolved in this
   session.

## Mitigations applied

- Fresh (non-shared) `Ptr` for both one-token lookaheads (accumulator
  detection, and the "starts with literal 0" f0 check), copying the
  advanced position back into the real `p` only when the lookahead
  actually matches -- see risk #1 above.
- Both call sites in `cocotools/insn_funcs.py`
  (`_insn_parse_gen_aux`'s three indexed-mode branches, and the
  `insn_parse_indexed` LEA wrapper) now explicitly set `cl.lint = -1`
  before invoking `insn_parse_indexed_aux`, matching both real C call
  sites -- see risk #2 above.
- `_insn_resolve_indexed_aux` (the module-private resolve helper) was
  re-translated in the same session, directly from
  `insn_resolve_indexed_aux` in `insn_indexed.c`, to decode the marker
  layout this function actually produces. This was necessary glue, not
  optional polish: without it, every indexed operand whose size
  couldn't be decided at parse time (the overwhelming majority of real
  assembly -- any plain `n,X` with no `<`/`>` prefix) would silently
  break. See SUMMARY.md for full details and the discovered latent bug
  in `_insn_resolve_gen_aux` that this uncovered.
- `insn_parse_indexed` and `insn_resolve_indexed` (the LEA-instruction
  wrapper functions) were corrected to match the real C control flow
  exactly (in particular, `insn_parse_indexed` no longer sets
  `cl.minlen`/`cl.maxlen`, which the real C never does for the LEA
  path -- confirmed harmless by grep: nothing in `passes.py` or
  `pass1.py` reads those fields).
