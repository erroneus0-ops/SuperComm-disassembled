# Translation Audit Summary: `insn_parse_indexed_aux`

Session date: 2026-07-17
Package: `translation_packages/02_insn_parse_indexed_aux/`

## What I read, in order

1. `brief.md` — the task definition.
2. `translation_packages/02_insn_parse_indexed_aux/source.c` — the C
   function (`insn_parse_indexed_aux`, lwtools-4.24/lwasm/insn_indexed.c
   lines 39-464). Read in full before writing any Python.
3. `translation_packages/02_insn_parse_indexed_aux/checklist.md` — the
   pre-filled risk-category checklist.
4. `cocotools/TRANSLATION_GUIDE.md` — the full checklist definitions and
   risk catalog (integer width, division, `char **p`, goto patterns,
   char signedness, argument order, promotion, complement, register
   lookup).
5. `cocotools/DATA_STRUCTURE_AUDIT.md` — shared `line_t`/`asmstate_t`
   field reference, in particular the semantics of `pb`, `lint`, `lint2`
   as pass-forward integers (not fixed-width byte fields).
6. `cocotools/c_compat.py` — available compatibility primitives
   (`c_uint8`/`c_int8`/etc., `c_trunc_div`/`c_trunc_mod`, `Ptr`,
   `c_isspace`/`c_toupper`).
7. `translation_packages/02_insn_parse_indexed_aux/existing.py` — this
   said the function was "not yet located in cocotools/insn_funcs.py."
   True as far as it went (no function of that exact name existed), but
   I also independently found that a **functionally equivalent, hand-
   rolled implementation already existed** under different names
   (`_parse_indexed_mode` + `_get_idx_reg_bits`) inside `insn_funcs.py`,
   which the packaging tool's simple grep-by-function-name approach
   missed. This mattered a great deal — see "Divergences" below.
8. The full current `cocotools/insn_funcs.py` (1280 lines, read in
   full) to understand the existing module's conventions, the shared
   helpers it already has (`Ptr`, `curpragma`, `AsmState.lookupreg2/3`,
   `Line.save_expr`/`fetch_expr`, `Expr.special`/`oper`), and exactly
   where the ad hoc indexed-mode code lived and was called from.
9. `cocotools/lwasm_core.py` (in full) — `Line` field definitions,
   `curpragma`, `AsmState.parse_expr`/`reduce_expr`,
   `AsmState.lookupreg2`/`lookupreg3`, `register_error`/`register_error2`.
10. `cocotools/lw_expr.py` (relevant sections) — `Expr` type constants,
    `Expr.special`/`Expr.oper`/`Expr.copy`, confirmed `Ptr` actually
    lives in `c_compat.py` (re-exported through `lw_expr.py`).
11. `cocotools/test_fidelity.py` (in full) — how the fidelity harness
    actually works: it assembles with **cocotools** and compares against
    a **real, locally-built `lwasm` 4.24 binary** byte-for-byte (not
    `asm6809`, which is used only as a secondary/behavioral reference in
    a couple of specific spots). This is the authoritative arbiter.
12. The real C source directly from the cloned repository, beyond just
    the extracted `source.c` snippet, specifically:
    - `lwtools-4.24/lwasm/insn_indexed.c` in full (834 lines) — including
      the `insn_parse_indexed` (LEA) wrapper, `insn_resolve_indexed_aux`,
      `insn_resolve_indexed`, and `insn_emit_indexed_aux` that follow the
      audited function and are directly coupled to it.
    - `lwtools-4.24/lwasm/insn_gen.c` — the general-addressing-mode
      caller (`insn_parse_gen_aux`, `insn_resolve_gen_aux`), to see
      exactly how and where `insn_parse_indexed_aux` gets called from
      the LDA/STA/etc. path (the `goto indexed:` block), and to check
      `l->lint = -1` is set at every real call site.
    - `lwtools-4.24/lwasm/lwasm.c` — the definition of
      `lwasm_skip_to_next_token`, which is called directly (not just via
      `parse_expr`) throughout the audited function.

## Environment setup

- Cloned the full repository (`git clone` — `github.com` and
  `codeload.github.com` are allow-listed) to get every file under
  `cocotools/`, `lwtools-4.24/`, and `translation_packages/`, rather
  than working from the four files linked in the brief alone.
- Built the real `lwasm` 4.24 binary from the included
  `lwtools-4.24` source tree (`make` in that directory; the `lwasm`
  target links successfully even though the unrelated `lwcc` target
  fails on a missing `lex.o` rule — irrelevant to this task). This is
  the binary `cocotools/test_fidelity.py` uses as its reference when
  present, and is what "byte-for-byte faithful to lwasm 4.24" is
  actually checked against.
- Confirmed the pre-existing baseline (before any of my changes): 166 +
  27 + 18 + 8 = 219 tests, all passing.

## Pre-translation checklist

Completed in full; see the accompanying `checklist.md`. Highlights:

- **No integer-width, division, complement, or promotion risks** — every
  value this function builds is a postbyte fragment or small
  pass-forward integer, safe by construction.
- **`char **p`**: the main parameter is a shared `Ptr`, as usual — but
  the C source *also* contains two places where it deliberately uses a
  **separate, unshared** local pointer for one-token lookahead
  (`tstr = *p + 1; ...; if (*tstr == ',') *p = tstr + 1;`), only
  committing the advance if the lookahead matches. This is the mirror
  image of the usual "always share the Ptr" rule, and getting it wrong
  in either direction (sharing when C doesn't, or not sharing when it's
  supposed to look ahead and conditionally commit) changes behavior.
- **Register lookup**: `AsmState.lookupreg3` is used for exactly one of
  the three register-matching sites in this function (the "expr,REG"
  form, which is the only one that accepts PC/PCR). The other two are
  hand-rolled in the C itself (accepting a smaller X/Y/U/S(/W) set) and
  were translated as direct if/elif chains, not routed through
  `lookupreg3`.
- **No gotos, no char-signedness risk** (ASCII-only source text).

## Divergences found between the prior code and the C source

The prior code had **no function named `insn_parse_indexed_aux`**, but
did have equivalent logic under different names. I compared that logic
against the real C line-by-line. Every difference below is a bug in the
prior ad hoc code, confirmed against the C:

1. **Offset-size decision timing.** The ad hoc `_parse_indexed_mode`
   decided the final offset size (5-bit / 8-bit / 16-bit) **immediately
   at parse time** whenever the expression was already a resolved
   constant, and defaulted forward references pessimistically to
   16-bit. The real C **never** makes this decision at parse time
   unless a `<`/`<<`/`>` prefix forces it — it always defers to
   `insn_resolve_indexed_aux`, writing an intermediate marker byte
   instead. This is not a cosmetic difference: it changes which
   function is actually responsible for size selection, and (as
   discovered mid-session — see "Necessary coupled changes" below) the
   codebase's resolve-side logic hadn't actually been being exercised
   for this decision at all until this session.

2. **Missing "explicit zero" (`f0`) flag.** The C tracks whether the
   offset expression's source text literally began with the digit `0`
   (e.g. `0,X` as opposed to `,X`). This flag prevents an explicitly
   written `0,X` from collapsing into the dedicated no-offset opcode
   (`0x84`), instead forcing the plain 5-bit encoding with the offset
   literally `0` (`0x00`). Confirmed against a locally-built real
   `lwasm` 4.24: `0,X` assembles to `A6 00`, while `,X` assembles to
   `A6 84` — genuinely different bytes. The prior ad hoc code had no
   concept of this flag at all and would have produced the same bytes
   for both (I did not test this specific case against the ad hoc code
   since it had already been removed by the time I verified this, but
   its logic contains no equivalent bit anywhere, so it cannot have
   produced `0x00` for `0,X`).

3. **PC vs. PCR conflation.** The ad hoc code had no separate handling
   for plain `,PC` (register-style indexing using the PC register as an
   ordinary index, no relative-offset adjustment) versus `,PCR` (true
   PC-relative addressing, which rewrites the offset expression as
   `target - (addr + linelen)`). The real C treats these as genuinely
   different: `rn == 5` (PCR) or `rn == 6 with PRAGMA_PCASPCR` gets the
   relative-expression rewrite; plain `rn == 6` without that pragma does
   not. Confirmed against real lwasm: `LDA 10,PCR` → `A6 8D C1 06`
   (relative, 16-bit); `LDA 10,PC` → `A6 8C 0A` (literal 10, 8-bit,
   register-style). New tests added for both.

4. **No 6309 `W`-register support.** The ad hoc parser's register-letter
   switches and its `_IDX_REG_BITS` table only knew about X/Y/U/S. The
   real C has a wholly separate branch for `rn == 4` (W), with its own
   fixed opcodes (`0x8F`/`0xCF`/`0xEF` direct, `0x90`/`0xD0`/`0xF0`
   indirect) that are **not** derived by shifting a register number —
   unlike X/Y/U/S, which do use `rn << 5`. This also includes W-specific
   error rules (`n,W` cannot be forced to 8-bit — `E_NW_8` — since W has
   only a 0-bit or 16-bit form).

5. **No `[<<n,X]` illegal-combination check.** The real C rejects
   forcing 5-bit offset (`<<`) together with indirect addressing
   (`E_ILL5`), checked immediately when the second `<` is consumed. The
   ad hoc code had no equivalent check.

6. **Pre-decrement/post-increment indirect restrictions**: the ad hoc
   code did implement `[,-R]`/`[,R+]` rejection, but via separately
   duplicated logic rather than following the C's actual branch
   structure — this one turned out to already be behaviorally correct
   (existing tests for these cases already passed), so no bug here, but
   it's now expressed as a literal transliteration of the same C
   branches rather than independently-derived logic, which reduces the
   chance of it silently drifting from the real semantics on a future
   lwasm update.

Each of these was confirmed against the actual C source, and where
practical, against a locally-built real `lwasm` 4.24 binary (not just
"this looks right" — the C's own comments and the fidelity harness's
authoritative reference were both checked). New tests were added to the
harness for #1, #2, #3, and #4 (see "New tests" below); #5 and #6 were
verified interactively and are implicitly covered by the existing
"error-indirect-predec1" / "error-indirect-postinc1" tests plus a new
`indexed-illegal-5bit-indirect` test for #5.

## Necessary coupled changes (and why they were unavoidable)

`insn_parse_indexed_aux` does not operate alone. When the offset size
can't be decided at parse time, it writes a **marker byte** into
`cl.pb` for a separate function, `insn_resolve_indexed_aux`, to decode
later. This marker's bit layout is dictated entirely by the parse
function (register field in bits 0-2, indirect at bit 7, the `f0` flag
at bit 6) — it is not a free choice; a resolve function must decode
whatever layout the paired parse function actually emits.

The codebase's pre-existing ad hoc resolve helper
(`_insn_resolve_indexed_aux`) decoded a **different, incompatible**
layout (register pre-shifted into bits 5-6, indirect at bit 4) — because
it was written to pair with the ad hoc parser, which (per divergence #1
above) almost never actually left a marker for it to decode; it decided
sizes eagerly instead. Plugging a faithful `insn_parse_indexed_aux` in
without also fixing the resolve-side decoder would have silently
corrupted the postbyte for every indexed operand whose size isn't fixed
by a `<`/`<<`/`>` prefix — which is the common case (plain `n,X`).

This is why, in addition to `insn_parse_indexed_aux` itself, this
session also:

- **Re-translated `_insn_resolve_indexed_aux`** directly from
  `insn_resolve_indexed_aux` in `insn_indexed.c`, faithfully, to decode
  the marker layout the new parser actually produces. This function is
  the subject of a **separate** translation package
  (`03_insn_resolve_indexed_aux`) and has not been through that
  package's own independent audit process (its own checklist, its own
  from-scratch translation compared against the C, its own dedicated
  test additions) — it was translated here as required integration
  glue, transliterated as faithfully as I could manage from the C
  within this session, but I recommend it still go through the full
  package-03 audit process rather than being considered "done."

- **Found and fixed a latent bug in `_insn_resolve_gen_aux`** (the
  general LDA/STA/etc. resolve path, in `insn_gen.c` terms
  `insn_resolve_gen_aux`): its `cl.lint2 == 1` (indexed) branch called
  the indexed resolve helper and then returned immediately, **never
  computing `cl.len`** afterward. The real C's `insn_resolve_gen_aux`
  funnels every branch through a shared `out:` label that computes
  `l->len` from whatever `l->lint2`/`l->lint` ended up as — including
  the indexed branch. This bug was invisible before this session because
  the ad hoc parser almost always decided the size (and therefore
  `cl.len`) eagerly at parse time, so the resolve path's indexed branch
  was nearly always a no-op by the time it ran. Once the faithful parser
  started genuinely deferring undecided sizes to resolve (matching real
  lwasm), this latent gap immediately caused every plain `n,X` operand
  with `elen == 0` to fail with "Cannot resolve line address." Fixed by
  calling the existing `_set_len_from_lint2` helper (which already
  implements exactly the C's `out:` block logic) after the indexed
  resolve call, mirroring the C's `goto out;`.

- **Corrected the `insn_parse_indexed` / `insn_resolve_indexed` LEA
  wrapper functions** to match the real C control flow exactly:
  - `insn_parse_indexed` (`PARSEFUNC(insn_parse_indexed)` in C) no
    longer sets `cl.minlen`/`cl.maxlen` — the real C never does this for
    the LEA path (only the general `insn_parse_gen_aux` indexed branch
    does). Confirmed harmless: `grep -n "minlen\|maxlen"` across
    `passes.py` and `pass1.py` returns nothing — no code in this
    codebase reads those fields, so this is a pure fidelity correction
    with zero behavioral risk.
  - `insn_resolve_indexed` (`RESOLVEFUNC(insn_resolve_indexed)` in C)
    now matches the C's explicit `if (l->lint == -1) ... ; if (l->lint
    != -1 && l->pb != -1) { ...len... }` structure, rather than
    unconditionally delegating.

I want to be transparent that this is more surface area than the
package strictly asked for. I judged this necessary rather than
optional because the alternative — plugging in a correct
`insn_parse_indexed_aux` while leaving its only consumer decoding the
wrong bit layout — would not have been a faithful translation in any
meaningful sense; it would have been a change that looks correct in
isolation and is silently wrong the moment real code exercises it,
which is exactly the failure mode this whole audit process exists to
prevent.

## A known, deliberately-not-fixed divergence (documented, not silently left in)

While verifying forward-reference behavior, I found that a **forward
reference to an EQU'd label** (label used before its `EQU` line) that
would ultimately resolve to a small, 8-bit-range value is encoded by
real lwasm 4.24 as **16-bit** (conservative), not 8-bit — even though
`insn_resolve_indexed_aux`'s own logic, read in isolation, appears to
attempt an 8-bit selection whenever its speculative reduction succeeds.
I traced one concrete case (`LDA FWDLABEL,X` / `FWDLABEL EQU $50`,
defined after use) where real lwasm keeps 16-bit (`A6 89 00 50`), while
my faithful translation of just these two functions produces 8-bit (`A6
88 50`) for the same input.

This is very likely a property of the **multi-pass driver**
(`passes.py`/`pass1.py`), not of `insn_parse_indexed_aux` or
`insn_resolve_indexed_aux` themselves — specifically, of exactly when
in the pass sequence the `EQU` symbol becomes resolved relative to when
`cl.len` first gets locked in for the referencing instruction (once
`cl.len != -1`, the resolve function's own top-line guard prevents it
from ever reconsidering). I did not attempt to fix this, because:

- It sits outside this package's declared scope (this package is titled
  `insn_parse_indexed_aux`, not the pass driver), and both functions I
  did translate/re-translate match their C sources line-for-line as
  far as I can verify in isolation.
- A fix would require changing the shared multi-pass architecture used
  by every instruction type, which carries real regression risk to
  unrelated code far outside this audit's tested surface.
- I did **not** add a test asserting the wrong (8-bit) behavior, and I
  did **not** add a test asserting a byte sequence I could not verify
  against the real reference implementation for this specific
  input shape. The one forward-reference test I did add
  (`indexed-fwdref-16bit`) uses a label value large enough (`$1234`)
  that both the real assembler and my translation agree on 16-bit,
  so it is a safe, currently-passing regression test — I confirmed
  this is not a case that happens to paper over the divergence, since
  the divergence is specifically about a value *small enough* to become
  8-bit-eligible once resolved.

I'm flagging this explicitly rather than silently shipping a smaller
generated instruction than real lwasm would, or silently working around
it, so a future session (very possibly the `03_insn_resolve_indexed_aux`
package, since the pass-timing question is closest to that function's
domain) can investigate with full context.

## Every bug fixed

### 1. `insn_parse_indexed_aux` did not exist — added

**C** (lines 39-464 of `insn_indexed.c`, in full — too long to quote
here in full per the copyright/quoting limits on this summary; see
`source.c` in this package for the complete text). Structurally: parses
`[`, then either a leading-comma form (pre-dec/post-inc/zero-offset,
X/Y/U/S/W only), an accumulator-offset form (A/B/D/E/F/W,REG), or falls
through to a general expression followed by `,REG` (X/Y/U/S/W/PCR/PC),
with `<`/`<<`/`>` prefixes forcing 8-bit/5-bit/16-bit respectively.

**Old Python**: none under this name; ad hoc equivalent
`_parse_indexed_mode`/`_get_idx_reg_bits` existed with the divergences
listed above.

**New Python**: `insn_parse_indexed_aux(as_, cl, p)` in `insn_funcs.py`
— a line-by-line transliteration, including the fresh-`Ptr` lookahead
pattern, the `f0` flag, the W-register branch, the PC/PCR distinction,
the `E_ILL5`/`E_NW_8` error paths, and the deliberate no-`return`
fallthrough for `rn <= 3` with `lint == 3` (the C itself has no return
there either — the 5-bit value gets merged into `cl.pb` later, at emit
time).

**Verification**: 166 opcode-matrix tests (byte-for-byte against real
lwasm 4.24) + 33 general behavioral tests + 3 6309-only behavioral tests
+ 20 structural tests, all passing, in both `--6809` and `--6309` modes.

### 2. `_insn_resolve_indexed_aux` decoded the wrong marker layout — re-translated

See "Necessary coupled changes" above for the full account.
**Old Python** (removed):
```python
def _insn_resolve_indexed_aux(as_, cl, force, elen=0):
    e = cl.fetch_expr(0)
    if not e: return
    if cl.lint != -1: return
    as_.reduce_expr(e)
    if e.istype(TYPE_INT):
        v = e.intval()
        reg_base = cl.pb & 0x60           # WRONG layout (post-ad-hoc-parser)
        indirect = cl.pb & 0x10           # WRONG layout
        ...
```
**New Python**: full re-translation from `insn_resolve_indexed_aux` in
`insn_indexed.c`, decoding `cl.pb & 0x07` (register), `cl.pb & 0x80`
(indirect), `cl.pb & 0x40` (f0), matching the marker
`insn_parse_indexed_aux` now actually writes.

**Verification**: same 230-test suite; specifically the structural
tests `struct-indexed-8bit-offset`, `struct-indexed-16bit-offset`, and
`struct-indexed-5bit-neg-offset` (which exercise this exact function)
now pass with correct `pb`/`lint`/`len` values.

### 3. `_insn_resolve_gen_aux` never set `cl.len` for the indexed branch — fixed

**C** (`insn_gen.c`, `insn_resolve_gen_aux`): every branch, including the
indexed one, funnels through a shared `out:` label that computes
`l->len`.

**Old Python**:
```python
def _insn_resolve_gen_aux(as_, cl, force, elen=0):
    ops = _ops(cl)
    if cl.lint2 == 1:
        _insn_resolve_indexed_aux(as_, cl, force, elen); return   # BUG: no len computed
    ...
```

**New Python**:
```python
def _insn_resolve_gen_aux(as_, cl, force, elen=0):
    ops = _ops(cl)
    if cl.lint2 == 1:
        _insn_resolve_indexed_aux(as_, cl, force, elen)
        _set_len_from_lint2(cl, ops, elen)
        return
    ...
```

**Verification**: without this fix, every plain `n,X`-style operand
with no forcing prefix failed to assemble at all ("Cannot resolve line
address"). All 166 opcode-matrix tests (which include many such
operands: `100,X`, `1000,X`, `LABEL,X`, `-5,X`, etc.) now pass.

### 4. LEA wrapper functions (`insn_parse_indexed`/`insn_resolve_indexed`) — corrected to match C

See "Necessary coupled changes" above for the diffs and rationale.

**Verification**: existing LEA tests (`LEAX`, `LEAY`, `LEAU`, `LEAS` —
zero-offset, forced offset, PCR) continue to pass byte-for-byte against
real lwasm.

## New tests added

Added to `cocotools/test_fidelity.py`:

**`BEHAVIOR_TESTS`** (byte-for-byte against real lwasm 4.24, 6809 mode):
- `indexed-fwdref-16bit` — forward-referenced label (defined after use)
  resolving to a 16-bit-range value; exercises the deferred-resolve
  marker path end-to-end.
- `indexed-pcr-relative` — `10,PCR`, confirms the relative-offset
  expression rewrite and resulting bytes.
- `indexed-pc-plain-register` — `10,PC` (no R), confirms this is
  *not* treated as relative addressing.
- `indexed-illegal-5bit-indirect` — `[<<5,X]`, confirms `E_ILL5`.
- `indexed-explicit-zero-offset` / `indexed-collapsed-zero-offset` — a
  matched pair (`0,X` vs `,X`) confirming these produce genuinely
  different bytes (the `f0` flag).

**`BEHAVIOR_TESTS_6309`** (new list, always assembled in `--6309` mode
regardless of the harness's CLI flag, since the existing harness
assembles its whole `BEHAVIOR_TESTS`/`TESTS` lists in one single mode
per run and W is invalid input under the default `PRAGMA_6809`):
- `indexed-w-register-forms-6309` — `,W` / `,W++` / `,--W` / `[,W]` /
  `[,W++]`, confirms the W-specific fixed opcodes.
- `indexed-w-forced-8bit-illegal-6309` — `<5,W`, confirms `E_NW_8`.
- `indexed-w-16bit-6309` — `1000,W`, confirms the W-specific 16-bit
  opcodes (`0xAF`/`0xB0`), not the shifted X/Y/U/S-style ones.

**`STRUCTURAL_TESTS`** (internal `cl.pb`/`cl.lint`/`cl.len` state):
- `struct-indexed-explicit-zero-f0` — confirms `0,X` resolves to
  `pb=0x00, lint=0`, distinct from the existing `,X` test's `pb=0x84`.
- `struct-indexed-pc-plain-register` — confirms `10,PC` resolves to
  `pb=0x8C, lint=1, len=3` (not the PCR relative-adjusted value).

`run_behavior_tests` was generalized to accept an explicit test list and
label (previously hardcoded to always use `BEHAVIOR_TESTS`), and
`__main__` now always runs both the mode-following `BEHAVIOR_TESTS` and
the always-6309 `BEHAVIOR_TESTS_6309`, regardless of the `--6309` CLI
flag.

## Final test counts

Running `python3 cocotools/test_fidelity.py` (default, 6809 mode):
```
Running 166 fidelity tests (6809 mode)...
Results: 166 passed, 0 failed out of 166 tests

Running 33 behavioral tests...
Behavioral results: 33 passed, 0 failed out of 33 tests

Running 3 behavioral (6309-only) tests...
Behavioral (6309-only) results: 3 passed, 0 failed out of 3 tests

Running 20 structural tests...
Structural results: 20 passed, 0 failed out of 20 tests

Running 8 expression-simplify tests...
Expression-simplify results: 8 passed, 0 failed out of 8 tests
```
**Total: 230 passed, 0 failed.**

Running `python3 cocotools/test_fidelity.py --6309` (full suite in
6309 mode): all 230 also pass (166+33+3+20+8, same breakdown).

Baseline before this session: 219 passed, 0 failed (166+27+18+8) — the
27 "behavioral" and 18 "structural" counts each grew by 6 and 2
respectively from the new tests above (net +11 across those two
categories, consistent with 6 new BEHAVIOR_TESTS + 2 new STRUCTURAL
entries + the pre-existing... note the exact pre/post arithmetic:
27→33 is +6 BEHAVIOR_TESTS entries; 18→20 is +2 STRUCTURAL_TESTS
entries; the 3 BEHAVIOR_TESTS_6309 entries are an entirely new category
that didn't exist before, run unconditionally in addition to the four
pre-existing categories).

## Files changed

- `cocotools/insn_funcs.py` — added `insn_parse_indexed_aux`; removed
  `_parse_indexed_mode`/`_get_idx_reg_bits`/`_IDX_REG_BITS`/
  `_IDX_ACC_BITS`; re-translated `_insn_resolve_indexed_aux`; fixed
  `_insn_resolve_gen_aux`; corrected `insn_parse_indexed`/
  `insn_resolve_indexed`; updated the three indexed-mode call sites in
  `_insn_parse_gen_aux` to set `cl.lint = -1` before calling the new
  function; added `PRAGMA_PCASPCR`, `PRAGMA_NOINDEX0TONONE`, `E_ILL5`,
  `E_NW_8` to the module's imports from `lwasm_types`.
- `cocotools/test_fidelity.py` — added the new tests described above;
  generalized `run_behavior_tests` to accept an explicit test list and
  label; added the `BEHAVIOR_TESTS_6309` list and wired it into
  `__main__`.
