# Current Python translation of insn_parse_indexed_aux
# cocotools/insn_funcs.py
#
# STATUS AS OF THIS SESSION (2026-07-17): TRANSLATED.
#
# insn_parse_indexed_aux now exists in cocotools/insn_funcs.py as a
# faithful, line-by-line translation of lwtools-4.24/lwasm/insn_indexed.c
# lines 39-464. See SUMMARY.md in this package for the full audit trail:
# what was read, the pre-translation checklist, every divergence found
# against the previous ad hoc implementation, and how each was resolved.
#
# Before this session, this function did not exist under this name
# anywhere in the codebase. A functionally-similar but non-faithful
# hand-rolled implementation existed as `_parse_indexed_mode` (plus a
# `_get_idx_reg_bits` helper), which has now been removed entirely and
# replaced by this translation and its call sites updated accordingly.
#
# The full translated source is in the accompanying insn_funcs.py in
# this package (search for `def insn_parse_indexed_aux`). It is not
# duplicated in this file to avoid the two copies drifting out of sync;
# insn_funcs.py is the single source of truth going forward.
#
# Directly coupled function also touched in this session (see
# SUMMARY.md "Necessary coupled changes" section for why):
#   - _insn_resolve_indexed_aux  (module-private; C: insn_resolve_indexed_aux)
#   - _insn_resolve_gen_aux      (latent missing cl.len computation fixed)
#   - insn_parse_indexed / insn_resolve_indexed (LEA wrapper functions)
