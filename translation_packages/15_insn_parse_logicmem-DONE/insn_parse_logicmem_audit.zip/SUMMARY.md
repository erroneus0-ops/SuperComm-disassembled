# Audit Summary: `insn_parse_logicmem` (translation_packages/15)

## What I read, in order

1. `translation_packages/15_insn_parse_logicmem/source.c` — diffed against
   the live tarball at `lwtools-4.24/lwasm/insn_logicmem.c` lines 37-64
   (byte-identical to the real source).
2. `translation_packages/15_insn_parse_logicmem/checklist.md` (pre-filled,
   then completed as part of this session)
3. `cocotools/TRANSLATION_GUIDE.md` / `cocotools/DATA_STRUCTURE_AUDIT.md` /
   `cocotools/c_compat.py` (re-read from the earlier package-14 session;
   no changes since)
4. `translation_packages/15_insn_parse_logicmem/existing.py`
5. `cocotools/insn_funcs.py` — focused on `insn_parse_logicmem` and its
   siblings, plus `_insn_parse_gen_aux` and `_skip_to_next_token`
6. `lwtools-4.24/lwasm/insn_logicmem.c` (full file) — this incidentally
   also contains `insn_resolve_logicmem` and `insn_emit_logicmem` (the
   latter is package 16), so I verified all three functions in this file
   while I had it open, though this package's scope is `insn_parse_logicmem`.
7. `translation_packages/13_insn_parse_bitbit/insn_parse_bitbit_audit.zip`
   (`SUMMARY.md` inside it) — checked precedent, since the bug found here
   turned out to be the same class of bug found and fixed in that package.

## Pre-translation checklist

See the completed `checklist.md`. Short version: of the 9 categories,
only #3 (`char **p`, trivially satisfied — one `Ptr` shared throughout)
applies at all. The real finding is the missing `lwasm_skip_to_next_token`
calls, which isn't one of the 9 checklist categories but is exactly the
kind of "interaction risk" the guide's own template asks for.

## Independent translation vs. `existing.py`

I translated `source.c` independently first. My draft included both
`lwasm_skip_to_next_token(l, p)` calls exactly where the C has them;
`existing.py` had neither.

**Divergence found — bug in existing.py, confirmed and fixed:**

```c
lwasm_save_expr(l, 100, s);
lwasm_skip_to_next_token(l, p);          // <- missing in existing.py
if (**p != ',' && **p != ';')
{
    lwasm_register_error(as, l, E_OPERAND_BAD);
    return;
}

(*p)++;
lwasm_skip_to_next_token(l, p);          // <- missing in existing.py
// now we have a general addressing mode - call for it
insn_parse_gen_aux(as, l, p, 1);
```

`lwasm_skip_to_next_token` is a no-op unless `PRAGMA_NEWSOURCE` is active
(`lwasm.c`: `if (CURPRAGMA(cl, PRAGMA_NEWSOURCE)) { for (; **p && isspace(**p); (*p)++) ; }`),
so this bug is silent under the default/compatibility source format and
only surfaces for source written with `pragma newsource` in effect and
whitespace around the comma — e.g. `AIM #$0F , $20`. I confirmed with a
from-source build of lwasm 4.24 that real lwasm accepts this and produces
`02 0F 20`.

This is the same bug class, in an adjacent instruction family, as the one
found and fixed in `insn_parse_bitbit` (translation_packages/13) — that
package's own summary documents an identical pair of missing
`skip_to_next_token` calls at analogous positions (after a register/value
is captured, before a comma check; and after the comma, before the next
parse step).

**Fix applied:** added `_skip_to_next_token(cl, p)` at both call sites,
using the helper already present in `insn_funcs.py` (the same one used by
the package-13 fix).

Everything else in `existing.py` matched the C exactly: the `#` prefix
skip, the expr-parse-and-save-at-id-100 sequence, the comma/semicolon
check, and the delegation to `_insn_parse_gen_aux(as_, cl, p, 1)`.

I also independently verified `insn_resolve_logicmem` (not part of this
package's own scope, but in the same C file) — it matches the C exactly
(`if (l->len != -1) return; insn_resolve_gen_aux(as, l, force, 1);` vs.
`if cl.len != -1: return; _insn_resolve_gen_aux(as_, cl, force, 1)`).
No bug there.

## A finding outside this package's scope, flagged rather than fixed

Verifying the fix through the *full* assembly pipeline (forcing
`PRAGMA_NEWSOURCE` on and running a complete source file through
`do_pass1`...`do_pass7`) hangs. Tracing it: `AsmState.parse_expr`
branches to `lw_parse_expr` (the "full" expression parser) instead of
`lw_parse_expr_compact` whenever `PRAGMA_NEWSOURCE` is set, and
`lw_parse_expr` does not appear to be implemented anywhere in
`cocotools/` — grepping the whole package for its definition finds
nothing. This is a pre-existing gap in a different subsystem
(expression parsing under the "new source" format), not something
`insn_parse_logicmem` touches or that this package's fix could have
caused. I'm flagging it here for whoever coordinates the remaining
packages rather than attempting to fix it — it's a substantially larger
piece of work than a single function, and patching it without the
actual C reference to diff against (`lw_expr.c`'s full-format parser,
if that's even the right file) would be a guess, not a translation.

I also note in passing: `pseudo_parse_pragma` in `pseudo.py` is
currently a stub (`_stub_parse`), so `pragma` directives written in
source are silently no-ops in cocotools today regardless of the above —
another piece of the same gap, also out of scope here.

## Verification method

Since the full pipeline can't safely exercise `PRAGMA_NEWSOURCE` (see
above), I verified the fix with a small local unit harness that calls
`insn_parse_logicmem` directly, with minimal stand-ins for `as_`/`cl` and
the downstream (unrelated, unchanged) `_insn_parse_gen_aux` stubbed out —
this isolates exactly the code this package touches from the broader,
separately-flagged gap.

```
=== default (no NEWSOURCE) -- must behave exactly as before the fix ===
tight operand '#$0F,$20'      : (errors=[], saved=[100], gen_aux_saw=['$20'])
space before comma            : (errors=[E_OPERAND_BAD], saved=[100], gen_aux_saw=[])

=== NEWSOURCE on -- whitespace around the comma must now be tolerated ===
space before AND after comma  : (errors=[], saved=[100], gen_aux_saw=['$20'])
space after comma only        : (errors=[], saved=[100], gen_aux_saw=['$20'])
tight operand still works     : (errors=[], saved=[100], gen_aux_saw=['$20'])
```

This confirms: (a) no regression under the default format — whitespace
before the comma still correctly errors, matching pre-fix behavior and
real lwasm's compact-format behavior; (b) under NEWSOURCE, whitespace is
now tolerated in exactly the two places the C allows it, and the operand
handed to the downstream general-addressing parser is correctly
positioned (`'$20'`, not `' $20'` or similar).

I also ran the full project fidelity harness (`test_fidelity.py`, default
6809/6309 modes — not NEWSOURCE) before and after the fix to confirm zero
regressions, since the fix is a no-op outside `PRAGMA_NEWSOURCE`:

```
Before fix: 170 + 53 + 16 + 30 + 8 + 4 + 10 = 291 passed, 0 failed
After fix:  170 + 53 + 16 + 30 + 8 + 4 + 10 = 291 passed, 0 failed
```

(The jump to 296 total happens in package 16's summary, once the new
logicmem-specific `BEHAVIOR_TESTS_6309` entries — which exercise both
packages 15's parse path and 16's emit path together, since they're the
same instructions — are added.)

## Final test counts

No new entries were added to `test_fidelity.py` under this package
specifically (the NEWSOURCE-dependent bug can't safely be tested through
that harness for the reasons above); its fix is verified by the local
stub harness shown above instead. The new `logicmem-*` entries added to
`BEHAVIOR_TESTS_6309` (5 tests, covering direct/extended/indexed-5-bit/
indexed-indirect addressing and the unresolved-immediate error path) are
documented under package 16's SUMMARY.md, since they exercise
`insn_emit_logicmem` most directly, but they also exercise this
package's `insn_parse_logicmem` (every logicmem instruction has to parse
correctly before it can emit). All pass — see package 16's summary for
the full count.
