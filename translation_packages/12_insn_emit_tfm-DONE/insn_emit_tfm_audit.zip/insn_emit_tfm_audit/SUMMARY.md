# Audit Summary: `insn_emit_tfm` (package 12 of 16)

## What I read, in order

1. `translation_packages/12_insn_emit_tfm/source.c` -- the 5-line C target
2. `translation_packages/12_insn_emit_tfm/checklist.md` -- pre-filled skeleton
3. `cocotools/TRANSLATION_GUIDE.md` -- full risk catalog and process
4. `cocotools/DATA_STRUCTURE_AUDIT.md` -- `line_t` field reference, in
   particular the `pb`/`lint` width notes and the cross-function field
   usage map
5. `cocotools/c_compat.py` -- compat primitives (none turned out to be
   needed for this function)
6. `translation_packages/12_insn_emit_tfm/existing.py` -- the package's
   suspect copy of the translation
7. `cocotools/insn_funcs.py` -- the real, current translation target,
   including the already-translated `insn_parse_tfm` immediately above it
   (needed for context: what `cl.lint` and `cl.pb` actually hold when
   `insn_emit_tfm` runs)

I also read the actual C definitions of `lwasm_emitop` and `lwasm_emit`
(`lwtools-4.24/lwasm/lwasm.c` lines 452-505) and the TFM opcode table row
in `instab.c` (line 630: opcodes `0x1138/0x1139/0x113a/0x113b`, flagged
`lwasm_insn_is6309` -- 6309-only), since the checklist item on integer
width required knowing what `l->lint` is actually holding at this call
site, not just its declared C type.

## Pre-translation checklist

Completed in full; see the updated `checklist.md` in this directory for
all 9 categories plus "Interaction risks" and "Mitigations applied".
Short version: this function has no arithmetic, no branches, no pointer
parameters, and no character handling of its own -- it is two calls to
already-translated, already-verified helpers (`cl.emitop`, `cl.emit`).
The only non-trivial finding was that `l->lint` here is overloaded to mean
"the opcode for this TFM variant" rather than its more common meaning
elsewhere ("count of extra bytes"), which is worth flagging for future
readers even though it required no code change.

## Divergences between `existing.py` and the C source

**None.** I translated the function independently from `source.c` before
opening `existing.py`, arrived at:

```python
def insn_emit_tfm(as_, cl):
    cl.emitop(cl.lint)
    cl.emit(cl.pb)
```

and then compared against both `existing.py` and the live
`cocotools/insn_funcs.py`. All three were identical. `l->lint` maps to
`cl.lint` (passed as the opcode to `emitop`), `l->pb` maps to `cl.pb`
(passed as the single postbyte to `emit`), in the same order as the C
source. No bug in `existing.py`, no mistake in my independent translation
to reconcile.

This is consistent with the function's own metrics (5 lines, 0 branches,
0 gotos) -- there was very little surface area for a divergence to hide
in.

## Bugs fixed

None. No changes were made to `cocotools/insn_funcs.py` -- the existing
`insn_emit_tfm` (lines 1515-1517) was already correct and required no
edits.

## New tests added

Added 5 tests to `BEHAVIOR_TESTS_6309` in `cocotools/test_fidelity.py`
(TFM is a 6309-only instruction per `instab.c`'s `lwasm_insn_is6309`
flag, so it must run under `--6309`):

| Test | Source | Purpose |
|---|---|---|
| `tfm-postinc-both-6309` | `TFM D+,X+` | opcode `0x1138` (tfm==5 branch in `insn_parse_tfm`) |
| `tfm-postdec-both-6309` | `TFM X-,Y-` | opcode `0x1139` (tfm==10 branch) |
| `tfm-r0-only-6309` | `TFM Y+,U` | opcode `0x113a` (tfm==1 branch) |
| `tfm-r1-only-6309` | `TFM S,D+` | opcode `0x113b` (tfm==4 branch) |
| `tfm-illegal-register-6309` | `TFM A,X+` | confirms `insn_emit_tfm` is never reached when `insn_parse_tfm` registers `E_REGISTER_BAD` (A/B/E/F are valid for TFR/EXG-family `rtor` instructions but not for TFM, which only accepts D/X/Y/U/S) |

Together these four legal-operand tests cover all four values `cl.lint`
can take (all four entries of the `ops[]` array for this instruction),
and confirm the two-byte opcode split in `emitop` fires correctly for
each one -- verified with `-v`:

```
tfm-postinc-both-6309  = 113801
tfm-postdec-both-6309  = 113912
tfm-r0-only-6309       = 113A23
tfm-r1-only-6309       = 113B40
tfm-illegal-register-6309 -- both error as expected
```

These byte sequences were hand-derived (`opcode_hi opcode_lo pb`, with
`pb = (r0<<4)|r1`) before running the harness and matched exactly.

## Verification method

- Built `lwasm` from the included C source (`lwtools-4.24`) myself via
  `make`, rather than running the prebuilt binary shipped in the repo,
  as the reference implementation for the fidelity harness. (For the
  record: the from-source build's ELF Build ID matched the prebuilt
  binary's exactly, confirming they're the same code -- but I used my
  own build regardless.)
- Ran `python cocotools/test_fidelity.py` (default, 6809 mode) before and
  after: 170 + 53 + 30 + 8 + 4 + 10 = 275 tests, all passing, unaffected.
- Ran `python cocotools/test_fidelity.py --6309`: same 170/53/30/8/4 plus
  10 behavioral-6309 tests (5 pre-existing + 5 new), all passing.
- Ran with `-v` to inspect the actual emitted byte sequences for the new
  tests and confirm they matched hand-derived expected values (see above).

## Final test counts

- Default (6809) mode: **275 passed, 0 failed**
- `--6309` mode: **280 passed, 0 failed** (275 + 5 new TFM tests)

## Bottom line

`insn_emit_tfm` was already a faithful, verified translation. This audit
confirmed that independently, filled in the previously-empty checklist,
documented an easy-to-miss semantic note about `cl.lint`'s meaning for
this instruction family, and closed a real test-coverage gap (TFM had
zero dedicated tests before this package). No production code changed.
