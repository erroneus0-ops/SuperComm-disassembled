# Pre-Translation Checklist: `insn_emit_tfm`

Metrics: 5 lines, 0 branches, 0 gotos

## 1. Integer width at assignment sites
No assignments in this function -- it only calls `lwasm_emitop`/`lwasm_emit`.
`l->lint` here is repurposed (per DATA_STRUCTURE_AUDIT.md's field-usage map)
to hold the two-byte TFM opcode selected in `insn_parse_tfm` (0x1138/0x1139/
0x113a/0x113b), not a small pass-forward int as in other instructions.
`l->pb` holds the register postbyte, `(r0<<4)|r1`, which by construction
(r0,r1 in 0..4) stays within 0x00-0x44 -- well inside 8 bits.
Bit mask operations found: None. No `c_uint8`/`c_int8` etc. needed here --
masking already happens inside `emitop`/`emit` (already-translated helpers).

## 2. Division / modulo
Not found.

## 3. char ** pointer parameters
Not found -- this function takes no operand string, only `(as_, cl)`.

## 4. goto statements
None. `lwasm.h` even `#define`s `insn_resolve_tfm NULL`, confirming this
instruction family has no branching resolve/emit logic at all.

## 5. char signedness
N/A -- no character comparisons in this function.

## 6. Argument evaluation order
N/A -- no function-call arguments read-and-advance a cursor; the two
statements are independent, order-fixed by the C source's own statement
order (emitop first, then emit), which Python preserves identically as
two sequential statements.

## 7. Integer promotion
Safe -- `l->lint` and `l->pb` are passed through unmodified to already-
translated helpers (`cl.emitop`, `cl.emit`) that own all necessary masking
(e.g. `emitop`'s `opc > 0x100` two-byte split, `emit`'s `byte & 0xff`).
This function performs no arithmetic of its own.

## 8. Bitwise complement
Not found.

## 9. Register lookup advancement
N/A -- no register-list scanning in the emit function itself (that happens
upstream in `insn_parse_tfm` / `_tfm_reg`, outside this package's scope).

## Character classification
N/A.

## Interaction risks identified
- `l->lint` is overloaded to carry the selected *opcode* for TFM (not the
  more common "byte-count" meaning documented for other instructions in
  DATA_STRUCTURE_AUDIT.md). Anyone editing this function later without
  checking `insn_parse_tfm` first could assume `cl.lint` here means "extra
  byte count" and try to derive the opcode from an `ops[]` table lookup
  instead of using `cl.lint` directly -- that would be wrong for this
  specific instruction family.
- All four TFM opcodes (0x1138-0x113b) are > 0xFF, exercising `emitop`'s
  two-byte-opcode split path (high byte, then low byte) on every single
  use of this instruction -- there is no one-byte-opcode case for TFM.
  Confirmed this path is covered by new tests below (previously the only
  two-byte-opcode coverage was via `insn_emit_rtor`/ADCR, a different
  call site).

## Mitigations applied
None needed -- the existing translation already calls the shared,
already-verified `cl.emitop` / `cl.emit` helpers with the correct
arguments in the correct order. No new compat primitives required.
