# Translation Delta: lwtools 4.24 → 4.25

Verified by direct `diff` against the fetched 4.24/4.25 source pairs
(see `full_diff.txt` in this package for the raw unified diff of all
five files). Every claim below is backed by a specific line in that
diff, not by the brief's predictions alone — the brief's three known
items turned out to be accurate as far as they went, but incomplete.

---

## 1. `insn_indexed.c` — PCR/PC-relative addressing now honors PHASE

**C change** (one line, in the PCR branch of `insn_parse_indexed_aux`):

```c
- e2 = lw_expr_build(..., lw_expr_oper_minus, e1, l -> addr);
+ e2 = lw_expr_build(..., lw_expr_oper_minus, e1, l -> phase ? l -> phase : l -> addr);
```

**What it does:** for `n,PCR` / `n,PC` operands, the offset is computed
as `target - (addr + linelen)`. If the line is inside a `PHASE` block,
4.25 now subtracts the *phased* (assumed) address instead of the line's
real address — the correct behavior, since PC-relative math needs to
match what the CPU will actually see at runtime under the phase
assumption, not where the bytes physically end up in the output file.
4.24 always used the real address, which is wrong for phased code.

**Python:** fixed in `insn_funcs.py`, `insn_parse_indexed_aux`, PCR
branch. Mirrors the exact ternary: `cl.phase if cl.phase else cl.addr`.

**Assumption / question for you:** this assumes `cl.phase` already
exists as an attribute on your line object (matching the `phase` field
that's already present in `lwasm.h`'s `line_s` struct in *both* 4.24 and
4.25 — this isn't a new field, just a new *use* of an existing one). I
didn't have `lwasm_core.py`, so I couldn't confirm the attribute exists
under that exact name. If it doesn't, or is named differently, that's a
one-line fix in the code I've handed back — flag it and I'll adjust.

**Also worth noting:** `insn_gen.c`'s emit-time BSR/BRA-shortening check
(in `insn_emit_gen_aux`) does the identical `target - (addr + linelen)`
calculation and *still* uses `l -> addr` unconditionally in **both**
4.24 and 4.25 — untouched by this release. I left the Python for that
path (`_insn_emit_gen_aux`) as-is, matching the C. Whether that's an
intentional asymmetry in lwasm itself or a separate latent bug upstream
isn't something I can resolve without asking William — not a
translation issue on our end either way.

---

## 2. `insn_gen.c` — uninitialized-variable bug fixed (no Python change needed)

**C change:** the asxxxx-compatibility `*` branch in
`insn_parse_gen_aux` had no `else`:

```c
else if (**p == '*') {
    tv = *(*p + 1);
    if (isdigit(tv) || ... ) { l -> lint2 = 0; (*p)++; }
    // (nothing else — l->lint2 left as whatever garbage was on the stack)
}
```

4.25 adds `else { l -> lint2 = -1; }`.

**Checked against the Python and no fix was needed:** `_insn_parse_gen_aux`
already pre-initializes `force_size = -1` before this if/elif chain runs,
so the non-matching `'*'` case already falls through with the same value
4.25's fix produces. This was never a live bug in the Python (it can't
have C's kind of uninitialized-stack-garbage problem in the first
place) — I added a comment at the site recording that this was checked,
so it isn't mistaken for a missed fix in a future audit.

---

## 3. `lw_expr.c` / `lw_expr.h` — substantially larger than the brief said

The brief flagged "shift operators added" as a known gap. That part was
correct, but incomplete — 4.25 also adds a byte-paste operator, a new
unary-complement spelling, and **renumbers precedence for six existing
operators**. All of the below is implemented in `lw_expr.py` and was
verified by direct execution (see "Testing" below), not just read
through.

### 3a. New `<<` / `>>` (bit-shift) operators
- New `OPER_LSHIFT` / `OPER_RSHIFT`, values 22/23 (matching the C enum's
  new entries, which come after `ge` = 20 and the new `bytepaste` = 21).
- New table entries at precedence 150 (same tier as `*`/`/`), placed
  **before** the single-char `<`/`>` entries — this ordering is load-
  bearing (see 3d below).
- New `_compute()` cases: plain `<<`/`>>`, no masking (consistent with
  how `+`/`-`/`*` are also left unmasked elsewhere in this file).
  Python's `>>` on negative ints is arithmetic (sign-extending), matching
  the behavior of every mainstream C compiler lwasm actually ships on;
  C's right-shift-of-negative is technically implementation-defined, but
  there's no real divergence in practice here.
- New print-name entries (`<< `, `>> `) in `Expr.__repr__`.

### 3b. New `::` byte-paste operator — expanded at *build* time, never a real node
This one is subtle enough to be worth stating plainly: in the C source,
`lw_expr_build_aux` special-cases `lw_expr_oper_bytepaste` **before**
constructing a normal operator node — it immediately rewrites it into
`((te1 & 0xff) * 0x100) + (te2 & 0xff)` and returns *that* tree instead.
A bytepaste node is never actually attached anywhere; this matches the
`lw_expr.h` comment ("operators below here will not be emitted in the
actual expression") — which, note, is only true for `bytepaste`, *not*
for `lshift`/`rshift` right below it in that same header (those two get
real compute-switch and print-switch cases in the C, so they plainly do
survive as ordinary tree nodes — the comment's placement is a little
misleading if read as applying to all three).

Implemented by special-casing `OPER_BYTEPASTE` inside `Expr.oper()`
itself (not just at the `::` parse site), since *any* caller of the
build function gets this treatment in C, not only the parser.

### 3c. New unary `!` (complement) prefix
4.25 adds `!` as a third spelling for unary complement, alongside the
existing `^`/`~` — guarded so `!=` is never mis-consumed (checks that the
next character isn't `=` before treating `!` as a prefix operator).
This is a real accommodation for the "TSC assembler" family of syntax
(the C's own comment mentions `&!511` for alignment idioms). The infix
use of `!` as a `|` synonym is untouched and doesn't conflict, because
it's matched in a completely separate code path (`_parse_expr`'s
operator table, only after a term has already been parsed) — same
relationship `^` already had between unary-complement and binary-XOR.

### 3d. Precedence renumbering (and: shadowing bug preserved, not fixed)
4.25 renumbers: `&&` 25→26, `&` 50→51 (both explicitly commented in the
C as "and above or, since and behaves like multiplication and or like
addition"), and **all six** comparison operators (`==`,`!=`,`<>`,`<`,
`<=`,`>`,`>=`) from 55/60 down to a flat **30**.

Critically, this renumbering does **not** fix the pre-existing shadowing
bug this file already documented for 4.24: `<`, `>`, and `!` (as the `|`
alias) are still declared *before* `<=`, `>=`, and `!=` respectively, and
since the C matcher takes the first entry whose string fully prefixes
the input (not the longest match), `<=`/`>=`/`!=` remain **permanently
unreachable** in 4.25 too — only their listed precedence number changed,
not their reachability. I verified this by hand-tracing the prefix scan
and then by direct execution (`5<=3` and `5!=3` both still produce a
parse failure; `5<>3` — NE's alternate, *not*-shadowed spelling — still
works). The existing code comments explaining this were kept and
extended rather than rewritten, since the underlying behavior (and the
reason for it) is unchanged, just renumbered.

`<<`/`>>` are **not** subject to this shadowing, because they're
declared *before* the single-char `<`/`>` entries and their full two-
character string matches before the single-char fallback is ever tried
— traced by hand and confirmed by direct execution (`1<<2<3` parses and
evaluates correctly as `(1<<2) < 3`).

---

## 4. `lwasm.h` / `lw_expr.h` — header-only changes, no Python action taken

These are real 4.25 additions, but nothing in the five files this
package covers *consumes* any of them — they're declarations only, with
the actual logic presumably living in C files this package doesn't
include (`main.c`, an output-format writer, listing/error-reporting
code). Recording them here so they're not lost, and so a future
translation package knows to look for them:

- `OUTPUT_FLEX` — new output format enum value, inserted **before**
  `OUTPUT_OS9` in the enum list. This shifts every enum value from
  `OUTPUT_OS9` onward up by one relative to 4.24. **If `cocotools`
  hardcodes any of these numeric output-format values anywhere**
  (rather than importing a shared constant), that's a silent
  compatibility break waiting to happen — worth an explicit check even
  though it's outside this package's diff.
- `PRAGMA_ASM09` (`1 << 30`) — new pragma bit, commented as enabling
  "Motorola ASM09 compatibility (IFC/IFNC, EXIT/EXITM, paren-grouped
  macro args)". No consuming logic in any of the five files fetched.
- `line_s.hasoperand` — new field, "set during parsing if line has an
  operand." Not referenced in `insn_indexed.c`, `insn_gen.c`, or
  `lw_expr.c`.
- `ERROR_FORMAT_LWASM/GCC/VS` enum + `asmstate_s.error_format` — new
  diagnostic-format selector (GCC-style vs. Visual Studio–style vs.
  lwasm's own). Purely a message-formatting concern; not part of
  assembly semantics.
- `asmstate_s.listcol[4]` — new column-formatted-listing field.

None of these need a `cocotools` change *for this package's scope*
(instruction parsing / expression evaluation). Flagging them so they
aren't mistaken for "fully audited, nothing else changed in 4.25."

---

## 5. Unrelated bug found and fixed while testing: `_skip_ws` infinite loop

Not part of the 4.24→4.25 delta — pre-existing in `lw_expr.py` before
any of my edits, confirmed against the file exactly as currently on
`main`. Found because I actually executed the parser to verify the new
operators, rather than only reading the diff.

`_skip_ws`'s old end-of-input check was:
```python
while p.peek() not in ('\0',) and p.peek() in ' \t\r\n':
```
`Ptr.peek()` returns `''` (empty string) at end-of-input, never `'\0'`
— so the first half of that condition is always `True` there. The
second half, `'' in ' \t\r\n'`, is **also always `True`** in Python,
because the empty string is a substring of every string. The net effect:
once the cursor ran off the end of the input, this loop never
terminated — it called `p.advance()` forever. In practice this means
the parser as shipped could not successfully finish parsing **any**
expression that doesn't happen to end in trailing whitespace before
EOF — which is to say, essentially never, for real assembly source.

Fixed to check for end-of-input explicitly:
```python
while p.peek() != '' and p.peek() in ' \t\r\n':
```

I fixed this because leaving a confirmed infinite loop in place felt
worse than leaving it out of scope, but flagging clearly: **this is not
a 4.25 compatibility issue** — it would have hung identically against
4.24 semantics too. Worth figuring out how this passed whatever testing
was run on the prior packages; possibly the test harness itself never
routes a real expression through the non-compact parser path, or always
supplies trailing whitespace.

---

## Testing performed

I don't have your full `lwasm_core.py` / `lwasm_types.py` / `instab.py`,
so I couldn't exercise `insn_funcs.py` end-to-end. `lw_expr.py` has no
such dependency (only `c_compat.py`), so I loaded it standalone with a
minimal digit-only term parser and confirmed by direct execution:

| Expression | Result | Expected |
|---|---|---|
| `1+2` | 3 | 3 (baseline, post-`_skip_ws`-fix) |
| `1<<4` | 16 | 16 |
| `256>>4` | 16 | 16 |
| `5::10` | 1290 | `(5&0xff)*256 + (10&0xff)` = 1290 |
| `!0` | -1 | unary complement of 0 |
| `~5` | -6 | (unchanged, sanity check) |
| `1&&0` | 0 | (unchanged, sanity check) |
| `3\|4` | 7 | (unchanged, sanity check) |
| `-8>>2` | -2 | arithmetic right shift |
| `5<=3` | syntax error (`None`) | shadowed by `<`, matches 4.24 behavior |
| `5!=3` | syntax error (`None`) | shadowed by `!`, matches 4.24 behavior |
| `5<>3` | 1 (true) | NE's un-shadowed alternate spelling |
| `1<<2<3` | 0 (false) | `(1<<2)=4`, then `4<3` is false |

All matched expected values on the first run after the `_skip_ws` fix.

---

## Files in this package

- `SUMMARY.md` — this file
- `full_diff.txt` — raw unified diff of all five C/H file pairs, for
  your own reference/audit
- `insn_funcs.py` — updated (PCR/phase fix; comment added at the `*`
  branch confirming no change needed there)
- `lw_expr.py` — updated (shift ops, byte-paste, unary `!`, precedence
  renumbering, `_skip_ws` bug fix)
- `c_compat.py` — **unchanged**, included only for convenience since
  `lw_expr.py` imports from it

`insn_gen.c`'s only change required no Python edit (see §2), so
`insn_gen.py`-equivalent logic (inside `insn_funcs.py`) needed only a
documentation comment, not a behavior change.

## Open questions for you

1. Does your line object actually expose `cl.phase`? (See §1.)
2. Do you want the `insn_gen.c` BSR/BRA-shortening asymmetry (§1, "Also
   worth noting") raised with William, or left alone as out of scope?
3. Any of the header-only additions in §4 on your roadmap? If so, which
   C file implements them, so I can pull it for the next package.
4. Want me to double-check whether `cocotools` hardcodes numeric
   `OUTPUT_*` values anywhere, given `OUTPUT_FLEX`'s insertion shifts
   everything from `OUTPUT_OS9` onward?

---

## Proposal: move long rationale comments out of the source, leave an anchor behind

**The problem.** This package's own comments are a data point: the
inline write-ups in `insn_funcs.py` and `lw_expr.py` (the `strchr`/NUL
UB note on `insn_parse_tfm`, the shadowing-bug trace in `lw_expr.py`'s
operator table, this package's PCR/phase fix, etc.) are genuinely useful
— they're the reasoning trail that stops a future editor from "fixing"
something that looks wrong but is actually a verified, deliberate match
to the real C behavior. But they're also long enough, and numerous
enough across packages, that inlining all of them will keep growing
every file's size indefinitely, with most of any given comment being
irrelevant to whoever's reading that function on a given day.

**The idea, refined.** Don't move the reasoning out wholesale — split
it:

- **Leave a one-line anchor comment in the code**, at the exact
  function/block the reasoning is about:
  ```python
  def insn_parse_tfm(as_, cl, operand):
      # NOTE: see notes.jsonl["insn_parse_tfm"] -- strchr/NUL-terminator
      # UB, PRAGMA_NEWSOURCE skip_token gap. Read before editing.
      ...
  ```
  This is the piece that makes the scheme actually work: the anchor is
  *unmissable at the moment someone is about to change that code*,
  which is exactly when the full reasoning matters most and is most
  easily forgotten if it lives somewhere else entirely.
- **Move the full essay-length rationale to an external file**, keyed
  by function name (and file/package/date), so it doesn't bloat the
  script but is still one lookup away.

**Format recommendation: JSON Lines (`notes.jsonl`), not one big JSON
file, and not comments-in-JSON.** Reasoning:
- A single nested JSON document means every new note touches one giant
  file — noisy diffs, easy merge conflicts, and JSON's own syntax
  (commas, brace nesting) makes hand-editing error-prone for something
  meant to accumulate indefinitely across packages.
- JSON also can't hold comments about itself and escapes multi-line
  prose/code snippets awkwardly (`\n` everywhere).
- JSON Lines — one JSON object per line, strictly append-only for new
  entries — solves the diff/merge problem (new notes just add a line;
  nothing else in the file moves) while staying fully machine-queryable
  (`grep`, `jq`, a future Claude just reading the file top to bottom).
  Example line:
  ```json
  {"function": "insn_parse_tfm", "file": "insn_funcs.py", "package": 15, "date": "2026-07-18", "note": "..."}
  ```
- The alternative worth naming: per-function Markdown files
  (`notes/insn_parse_tfm.md`), grouped by source file or package. Reads
  better for a human browsing casually, at the cost of many small files
  instead of one growing one. Either is workable; JSONL is the better
  default if the primary future reader is another Claude instance doing
  a targeted lookup rather than a human skimming.

**The convention needs to be stated once, prominently**, or the anchor
comments themselves won't reliably get created going forward — e.g., a
line at the top of every `cocotools/*.py` file:
> *Detailed rationale for non-obvious translation decisions lives in
> `notes.jsonl`, keyed by function name — check there before changing
> behavior, not just this file's inline comments.*

**Not yet done in this package:** migrating the existing long comments
in `insn_funcs.py`/`lw_expr.py` into this scheme, and adding the anchor
lines in their place. That's a mechanical follow-up once you've picked
a format — happy to do it as a small dedicated pass so it's easy to
review on its own, separate from this package's actual behavioral diff.

